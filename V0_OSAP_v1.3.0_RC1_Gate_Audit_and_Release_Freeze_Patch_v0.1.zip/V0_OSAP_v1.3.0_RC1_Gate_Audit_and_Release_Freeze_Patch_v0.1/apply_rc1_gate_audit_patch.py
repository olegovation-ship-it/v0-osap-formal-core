
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

PATCH_ID = "V0_OSAP_v1.3.0_RC1_Gate_Audit_and_Release_Freeze_Patch_v0.1"
BASELINE_COMMIT = "29201b4937cef220ef0933d852250b021f3f44d4"
TARGET_BRANCH = "v1.3.0-development"
IMMUTABLE_TAG = "v1.2.0"
IMMUTABLE_DOI = "10.5281/zenodo.21306969"
PAYLOAD = Path(__file__).resolve().parent / "payload"

README_MARKER = "<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->"
CHANGELOG_MARKER = "<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->"
STATUS_MARKER = "<!-- V0_OSAP_RC1_STATUS_BEGIN -->"

README_BLOCK = """{marker}
> **V0 OSAP v1.3.0 RC1 GATE AUDIT AND RELEASE FREEZE - RC1_AUDIT_READY / CI_PENDING / NO RELEASE TAG**

The accepted development corpus T121-T156 is frozen for release-candidate gate
auditing. This patch adds the consolidated theorem inventory, claim matrix,
structural-record parity audit, negative release-gate fixtures, validator
evidence contract, release manifest, and clean-room replay protocol.

Baseline closure merge commit: `29201b4937cef220ef0933d852250b021f3f44d4`. Historical tag `v1.2.0`
and DOI `10.5281/zenodo.21306969` remain immutable. This is not a `v1.3.0-rc1` or
`v1.3.0` release. T150 and T156 remain conditional.

See `release/v1.3.0/RC1_GATE_AUDIT_AND_RELEASE_FREEZE_SPECIFICATION.md` and
`release/v1.3.0/RC1_ACCEPTANCE_GATES.md`.
<!-- V0_OSAP_RC1_GATE_AUDIT_END -->
""".format(marker=README_MARKER)

CHANGELOG_BLOCK = """{marker}
## [Unreleased] - v1.3.0 RC1 gate audit and release freeze

- Froze candidate theorem scope T121-T156 without adding theorem IDs or semantic rules.
- Added a generated consolidated theorem inventory and one-owner collision audit.
- Added the claim-classification matrix and retained T140, T150, and T156 conditionality.
- Added structural-record parity evidence for Lean, Coq, fixtures, and canonical RC1 hashes.
- Added twelve negative release-gate mutants and a dedicated gate verifier.
- Added validator/evidence interchange contract, release manifest, known limitations, and clean-room replay protocol.
- Preserved immutable tag `v1.2.0` and DOI `10.5281/zenodo.21306969`.
- State: `RC1_AUDIT_READY / CI_PENDING / NO_RELEASE_TAG`.
<!-- V0_OSAP_RC1_CHANGELOG_END -->
""".format(marker=CHANGELOG_MARKER)

STATUS_BLOCK = """{marker}
## v1.3.0 RC1 gate audit and release freeze

- Candidate scope: T121-T156.
- Status: `RC1_AUDIT_READY / CI_PENDING / NO RELEASE TAG`.
- Baseline closure merge commit: `29201b4937cef220ef0933d852250b021f3f44d4`.
- Checker development version remains `0.7.0.dev1`.
- No theorem ID, claim kind, executable rule, Lean theorem, Coq theorem, or checker version is added.
- T121-T150 remain the normative v1.1 range.
- T151-T156 remain explicit post-v1.1 development extensions.
- T140, T150, and T156 remain conditional.
- Structural-record parity is not proof-term identity or unrestricted semantic equivalence.
- Immutable tag `v1.2.0` and DOI `10.5281/zenodo.21306969` remain unchanged.
- No RC1 tag, final tag, GitHub Release, Zenodo version, or DOI is created by this patch.
<!-- V0_OSAP_RC1_STATUS_END -->
""".format(marker=STATUS_MARKER)


def run(args: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=cwd,
        check=check,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def insert_after(text: str, anchor: str, block: str, marker: str) -> str:
    if marker in text:
        return text
    idx = text.find(anchor)
    if idx < 0:
        raise SystemExit(f"Required anchor not found: {anchor}")
    end = idx + len(anchor)
    return text[:end] + "\n\n" + block.strip() + "\n" + text[end:]


def copy_payload(root: Path) -> None:
    for src in PAYLOAD.rglob("*"):
        if src.is_dir():
            continue
        rel = src.relative_to(PAYLOAD)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_docs(root: Path) -> None:
    readme = root / "README.md"
    changelog = root / "CHANGELOG.md"
    status = root / "docs/status_and_nonclaims.md"
    workflow = root / ".github/workflows/release-readiness.yml"

    readme_text = readme.read_text(encoding="utf-8")
    readme.write_text(
        insert_after(
            readme_text,
            "## v1.3.0 development status",
            README_BLOCK,
            README_MARKER,
        ),
        encoding="utf-8",
    )

    changelog_text = changelog.read_text(encoding="utf-8")
    changelog.write_text(
        insert_after(changelog_text, "# Changelog", CHANGELOG_BLOCK, CHANGELOG_MARKER),
        encoding="utf-8",
    )

    status_text = status.read_text(encoding="utf-8")
    status.write_text(
        insert_after(
            status_text,
            "# Status and non-claims",
            STATUS_BLOCK,
            STATUS_MARKER,
        ),
        encoding="utf-8",
    )

    workflow_text = workflow.read_text(encoding="utf-8")
    anchor = "      - run: python scripts/verify_phase6_ci_closure.py"
    required_lines = [
        "      - run: python scripts/build_rc1_release_inventory.py",
        "      - run: python scripts/verify_rc1_statement_parity.py",
        "      - run: python scripts/verify_rc1_gate_audit.py",
    ]
    if not all(line in workflow_text for line in required_lines):
        if anchor not in workflow_text:
            raise SystemExit("Phase 6 closure command not found in release-readiness workflow.")
        insertion = anchor + "\n" + "\n".join(required_lines)
        workflow_text = workflow_text.replace(anchor, insertion, 1)
        workflow.write_text(workflow_text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", nargs="?", default=".")
    parser.add_argument("--skip-baseline-check", action="store_true")
    parser.add_argument("--skip-branch-check", action="store_true")
    parser.add_argument("--commit", action="store_true")
    parser.add_argument("--push", action="store_true")
    args = parser.parse_args()

    root = Path(args.repository).resolve()
    required = [
        root / ".git",
        root / "README.md",
        root / "CHANGELOG.md",
        root / "docs/status_and_nonclaims.md",
        root / ".github/workflows/release-readiness.yml",
        root / "release/v1.3.0/PHASE6_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise SystemExit("Not a compatible V0 OSAP repository:\n- " + "\n- ".join(missing))

    if not args.skip_branch_check:
        branch = run(["git", "branch", "--show-current"], root).stdout.strip()
        if branch != TARGET_BRANCH:
            raise SystemExit(
                f"Expected branch {TARGET_BRANCH}, found {branch}. "
                "Switch branches before applying."
            )

    if not args.skip_baseline_check:
        result = run(
            ["git", "merge-base", "--is-ancestor", BASELINE_COMMIT, "HEAD"],
            root,
            check=False,
        )
        if result.returncode != 0:
            raise SystemExit(
                f"Baseline closure commit {BASELINE_COMMIT} is not an ancestor of HEAD."
            )

    copy_payload(root)
    patch_docs(root)

    for command in [
        [sys.executable, "scripts/build_rc1_release_inventory.py"],
        [sys.executable, "scripts/verify_rc1_statement_parity.py"],
        [sys.executable, "scripts/verify_rc1_gate_audit.py"],
    ]:
        completed = run(command, root)
        print(completed.stdout, end="")

    completed = run(["git", "diff", "--check"], root, check=False)
    if completed.returncode != 0:
        raise SystemExit("git diff --check failed:\n" + completed.stdout)

    if args.commit or args.push:
        run(["git", "add", "-A"], root)
        run(["git", "diff", "--cached", "--check"], root)
        changed = run(["git", "diff", "--cached", "--quiet"], root, check=False)
        if changed.returncode != 0:
            run(
                ["git", "commit", "-m", "Stage V0 OSAP v1.3.0 RC1 gate audit and release freeze"],
                root,
            )
        if args.push:
            run(["git", "push", "origin", TARGET_BRANCH], root)

    print(f"Applied {PATCH_ID}.")
    print("Recorded state: RC1_AUDIT_READY / CI_PENDING / NO_RELEASE_TAG.")
    print("No tag, GitHub Release, Zenodo version, or DOI was created.")
    print("Run the complete local validation matrix before opening the draft PR.")


if __name__ == "__main__":
    main()
