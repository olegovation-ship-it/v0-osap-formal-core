
# Apply Instructions

## 1. Synchronize the development branch

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git fetch origin
git pull --ff-only origin v1.3.0-development
```

The baseline closure commit `29201b4937cef220ef0933d852250b021f3f44d4` must be an ancestor of `HEAD`.

## 2. Extract the uploaded package

```bash
ZIP="V0_OSAP_v1.3.0_RC1_Gate_Audit_and_Release_Freeze_Patch_v0.1.zip"
TMP="/tmp/v0-osap-rc1-gate-audit"
rm -rf "$TMP"
mkdir -p "$TMP"
python -m zipfile -e "$ZIP" "$TMP"
APPLY_SCRIPT="$(find "$TMP" -name apply_rc1_gate_audit_patch.py -print -quit)"
test -n "$APPLY_SCRIPT"
python "$APPLY_SCRIPT" /workspaces/v0-osap-formal-core
```

## 3. Run the complete local matrix

```bash
cd /workspaces/v0-osap-formal-core
python -m pip install -e '.[dev]'
python scripts/build_rc1_release_inventory.py
python scripts/verify_rc1_statement_parity.py
python scripts/verify_rc1_gate_audit.py
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
python scripts/verify_phase6_expansion.py
python scripts/verify_phase6_ci_closure.py
(cd lean && lake build)
(cd coq && make)
rm -f coq/Makefile.coq.d coq/Makefile.coq.conf
git diff --check
```

Expected Python regression total after applying this patch: **16 tests**.

## 4. Commit and push

```bash
git status --short
git add -A
git diff --cached --check
git commit -m "Stage V0 OSAP v1.3.0 RC1 gate audit and release freeze"
git push origin v1.3.0-development
```

## 5. Open a draft PR

Suggested title:

`V0 OSAP v1.3.0 RC1: gate audit and release freeze T121-T156`

Use `PR_DESCRIPTION.md` as the description.

## Hold

Do not create `v1.3.0-rc1`, `v1.3.0`, a GitHub Release, a Zenodo version,
or a DOI during this patch. Tagging requires a separate post-merge closure
decision and clean-room replay.
