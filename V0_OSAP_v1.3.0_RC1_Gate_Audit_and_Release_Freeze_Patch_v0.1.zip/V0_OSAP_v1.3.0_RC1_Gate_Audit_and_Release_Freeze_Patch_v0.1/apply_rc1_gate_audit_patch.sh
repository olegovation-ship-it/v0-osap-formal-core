#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-/workspaces/v0-osap-formal-core}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

python "$SCRIPT_DIR/apply_rc1_gate_audit_patch.py" "$REPO"
