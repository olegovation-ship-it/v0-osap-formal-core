# Phase 4 closure baseline evidence

Repository: `olegovation-ship-it/v0-osap-formal-core`
Development branch: `v1.3.0-development`
Phase 4 implementation PR: `#6`
Implementation baseline merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`
Implementation head commit: `9cec516c8ab026ce8d63fd2303f72ec5c1d36351`
Implementation merge commit: `417866ec94fb24891c00bdfc2e522095777532bf`
Merged at UTC: `2026-07-12T11:04:10Z`
PR checks: `8/8 PASS`
Changed files: `53`
Additions: `2481`
Deletions: `25`
Immutable release tag: `v1.2.0`
Immutable release DOI: `10.5281/zenodo.21306969`

Successful workflow runs:

- Release readiness: `29190051466` / run 40
- Python checker: `29190051514` / run 22
- Lean 4: `29190051463` / run 22
- Schema validation: `29190051457` / run 22
- Coq: `29190051493` / run 22

The closure package requires `417866ec94fb24891c00bdfc2e522095777532bf` to be an ancestor of the development-branch HEAD.
