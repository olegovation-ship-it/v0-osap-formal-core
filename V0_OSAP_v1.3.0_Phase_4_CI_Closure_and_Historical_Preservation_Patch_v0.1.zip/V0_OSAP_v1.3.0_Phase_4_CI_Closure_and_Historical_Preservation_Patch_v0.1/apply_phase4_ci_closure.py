#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path

EXPECTED_BRANCH = "v1.3.0-development"
EXPECTED_BASELINE = "417866ec94fb24891c00bdfc2e522095777532bf"
EXPECTED_IMPLEMENTATION_BASELINE = "24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30"
EXPECTED_HEAD = "9cec516c8ab026ce8d63fd2303f72ec5c1d36351"
EXPECTED_DOI = "10.5281/zenodo.21306969"

PAYLOAD_FILES = [
    "release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md",
    "release/v1.3.0/PHASE4_BUILD_SPECIFICATION.md",
    "release/v1.3.0/PHASE4_IMPLEMENTATION_REPORT.md",
    "release/v1.3.0/PHASE4_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
    "release/v1.3.0/PHASE4_CI_CLOSURE_EVIDENCE.json",
    "scripts/verify_phase4_ci_closure.py",
]


def git(repo: Path, *args: str, check: bool = True) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if check and result.returncode != 0:
        raise SystemExit(result.stdout.strip())
    return result.stdout.strip()


def replace_once(path: Path, old: str, new: str) -> None:
    body = path.read_text(encoding="utf-8")
    if new in body:
        return
    if old not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {old[:120]!r}")
    path.write_text(body.replace(old, new, 1), encoding="utf-8")


def insert_after(path: Path, anchor: str, insertion: str) -> None:
    body = path.read_text(encoding="utf-8")
    if insertion.strip() in body:
        return
    if anchor not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {anchor[:120]!r}")
    path.write_text(body.replace(anchor, anchor + insertion, 1), encoding="utf-8")


def validate_repository(repo: Path, force: bool) -> None:
    required = [
        "release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md",
        "release/v1.3.0/PHASE4_BUILD_SPECIFICATION.md",
        "release/v1.3.0/PHASE4_IMPLEMENTATION_REPORT.md",
        "release/v1.3.0/theorem_crosswalk_phase4.json",
        "scripts/verify_phase4_expansion.py",
        "scripts/verify_phase3_ci_closure.py",
        ".github/workflows/release-readiness.yml",
    ]
    missing = [rel for rel in required if not (repo / rel).exists()]
    if missing:
        raise SystemExit("Incompatible repository; missing: " + ", ".join(missing))

    branch = git(repo, "branch", "--show-current", check=False)
    if branch and branch != EXPECTED_BRANCH and not force:
        raise SystemExit(
            f"Expected branch {EXPECTED_BRANCH!r}, found {branch!r}. "
            "Checkout the development branch or use --force after manual review."
        )

    ancestor = subprocess.run(
        ["git", "merge-base", "--is-ancestor", EXPECTED_BASELINE, "HEAD"],
        cwd=repo,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0
    if not ancestor and not force:
        head = git(repo, "rev-parse", "HEAD", check=False)
        raise SystemExit(
            f"Expected Phase 4 merge commit {EXPECTED_BASELINE} to be an ancestor "
            f"of HEAD {head}. Synchronize origin/main into {EXPECTED_BRANCH} first."
        )

    status = git(repo, "status", "--porcelain", check=False)
    if status and not force:
        raise SystemExit(
            "Working tree is not clean. Commit the staged package and synchronize "
            "the branch before applying, or use --force after manual review."
        )


def copy_payload(repo: Path, package: Path) -> None:
    payload = package / "payload"
    for rel in PAYLOAD_FILES:
        src = payload / rel
        if not src.exists():
            raise SystemExit(f"Package payload missing: {rel}")
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def update_crosswalk(repo: Path) -> None:
    path = repo / "release/v1.3.0/theorem_crosswalk_phase4.json"
    data = json.loads(path.read_text(encoding="utf-8"))

    assert data["baseline_merge_commit"] == EXPECTED_IMPLEMENTATION_BASELINE
    assert data["theorem_range"] == "T139-T144"

    data["phase4_status"] = "ACCEPTED_CI_PASS_MERGED"
    data["pull_request"] = 6
    data["head_commit"] = EXPECTED_HEAD
    data["merge_commit"] = EXPECTED_BASELINE
    data["merged_at_utc"] = "2026-07-12T11:04:10Z"
    data["github_pr_checks"] = 8
    data["python_tests"] = 113
    data["historical_preservation"] = "PASS"
    data["closure_evidence"] = (
        "release/v1.3.0/PHASE4_CI_CLOSURE_EVIDENCE.json"
    )

    for row in data["records"]:
        row["parity_status"] = "ACCEPTED_CI_PASS"

    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def update_readme(repo: Path) -> None:
    path = repo / "README.md"
    old = """> **PHASE 4 T139-T144 ARCHIVE, BRANCH, CARDINALITY, AND DIAGNOSTIC EXPANSION - BUILD READY / CI PENDING**

Phase 4 adds archive non-guard export, independent-witness conditional sufficiency,
the no-container and branch-label firewalls, non-finite cardinality licensing, and
finite diagnostic-precedence totality. Checker version: `0.5.0.dev1`.

The patch includes twelve paired fixtures, Lean 4 and Coq Phase 4 modules, and a
canonical statement-hash crosswalk. Baseline merge commit:
`24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.

This is a build-ready v1.3.0 development patch, not an accepted Phase 4 state and
not a v1.3.0 release. See `release/v1.3.0/PHASE4_BUILD_SPECIFICATION.md` and
`release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md`.
"""
    new = """> **PHASE 4 T139-T144 ARCHIVE, BRANCH, CARDINALITY, AND DIAGNOSTIC EXPANSION - ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED**

Phase 4 adds archive non-guard export, independent-witness conditional sufficiency,
the no-container and branch-label firewalls, non-finite cardinality licensing, and
finite diagnostic-precedence totality. Checker version: `0.5.0.dev1`.

PR #6 passed 8/8 checks and merged head commit
`9cec516c8ab026ce8d63fd2303f72ec5c1d36351` into `main` as
`417866ec94fb24891c00bdfc2e522095777532bf`. The regression suite recorded
113 passing tests, and both Lean 4 and Coq builds passed.

The implementation was built from the preserved Phase 3 closure baseline
`24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`. The patch includes twelve paired fixtures,
Lean 4 and Coq Phase 4 modules, and a canonical statement-hash crosswalk.
This is an accepted v1.3.0 development state, not a v1.3.0 release. See
`release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md` and
`release/v1.3.0/PHASE4_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md`.
"""
    replace_once(path, old, new)
    insert_after(
        path,
        "python scripts/verify_phase4_expansion.py\n",
        "python scripts/verify_phase4_ci_closure.py\n",
    )


def update_changelog(repo: Path) -> None:
    path = repo / "CHANGELOG.md"
    replace_once(
        path,
        "- Status is `BUILD_READY / CI_PENDING`; no Phase 4 acceptance or v1.3.0 release is claimed.",
        "- Status advanced to `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`; no v1.3.0 release is claimed.",
    )
    closure = """
### Phase 4 CI closure
- Recorded PR #6 with 8/8 successful checks.
- Recorded head commit `9cec516c8ab026ce8d63fd2303f72ec5c1d36351` and merge commit `417866ec94fb24891c00bdfc2e522095777532bf`.
- Recorded 113 passing Python tests, schema and fixture PASS, proof-hole PASS, Phase 1 preservation PASS, Phase 2 and Phase 3 expansion/closure PASS, Phase 4 verifier PASS, Lean 4 PASS, and Coq PASS.
- Advanced T139-T144 theorem-crosswalk parity from `PATCH_READY_CI_PENDING` to `ACCEPTED_CI_PASS`.
- Added a dedicated Phase 4 CI-closure and historical-preservation verifier.
- Preserved the immutable v1.2.0 manifest and closure jobs, tag, DOI, and Phase 1-3 closure history.
- Recorded the Phase 4 implementation merge baseline `417866ec94fb24891c00bdfc2e522095777532bf` for development-branch synchronization.
"""
    anchor = "- Status advanced to `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`; no v1.3.0 release is claimed.\n"
    insert_after(path, anchor, closure)
    replace_once(
        path,
        "- Phase 1, Phase 2, and Phase 3 acceptance, and the Phase 4 build-ready patch, are not a v1.3.0 release or an enlargement of the archived v1.2.0 compiler-passed claim.",
        "- Phase 1, Phase 2, Phase 3, and Phase 4 acceptance are not a v1.3.0 release or an enlargement of the archived v1.2.0 compiler-passed claim.",
    )


def update_status(repo: Path) -> None:
    path = repo / "docs/status_and_nonclaims.md"
    old = """## v1.3.0 Phase 4

- Scope: T139-T144.
- Status: `BUILD_READY / CI_PENDING`.
- Baseline merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.
- Checker development version: `0.5.0.dev1`.
- Twelve paired fixtures and Lean 4 / Coq modules are staged.
- Phase 1, Phase 2, and Phase 3 accepted states remain preserved.
- No Phase 4 acceptance, v1.3.0 release, theorem-completeness, proof-identity, checker-completeness, or empirical claim.
"""
    new = """## v1.3.0 Phase 4

- Scope: T139-T144.
- Status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.
- Implementation baseline merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.
- PR #6: 8/8 checks passed.
- Head commit: `9cec516c8ab026ce8d63fd2303f72ec5c1d36351`.
- Merge commit: `417866ec94fb24891c00bdfc2e522095777532bf`.
- Checker development version: `0.5.0.dev1`.
- Python suite: 113 tests passed.
- Twelve paired fixtures and Lean 4 / Coq modules are accepted in the development tree.
- Phase 1, Phase 2, and Phase 3 accepted states remain preserved.
- No v1.3.0 release, theorem-completeness, proof-identity, checker-completeness, or empirical claim.
"""
    replace_once(path, old, new)
    replace_once(
        path,
        "- The Phase 2 and Phase 3 closure packages are development-history patches and do not rewrite the archived release.",
        "- The Phase 2, Phase 3, and Phase 4 closure packages are development-history patches and do not rewrite the archived release.",
    )
    replace_once(
        path,
        "- Phase 4 status: `BUILD_READY / CI_PENDING`.",
        "- Phase 4 status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.",
    )
    replace_once(
        path,
        "- No accepted theorem IDs beyond T138 in the current v1.3.0 development state; T139-T144 are build-ready and CI-pending.",
        "- No accepted theorem IDs beyond T144 in the current v1.3.0 development state.",
    )


def update_register(repo: Path) -> None:
    path = repo / "docs/theorem_register.md"
    replace_once(
        path,
        "Phase 4 stages T139-T144 as build-ready and CI-pending from closure merge commit `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.",
        "Phase 4 adds the accepted development cluster T139-T144 under the same historical-preservation boundary from implementation baseline `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.",
    )
    replace_once(
        path,
        "Phase 4 baseline merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.\nPhase 4 patch status: `BUILD_READY / CI_PENDING`.",
        "Phase 4 implementation baseline merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`.\n"
        "Phase 4 head commit: `9cec516c8ab026ce8d63fd2303f72ec5c1d36351`.\n"
        "Phase 4 merge commit: `417866ec94fb24891c00bdfc2e522095777532bf`.\n"
        "Phase 4 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.",
    )
    body = path.read_text(encoding="utf-8")
    body = body.replace("build-ready; CI pending", "accepted; CI passed; merged")
    body = body.replace(
        "Phase 4 is not accepted or released until the complete local and GitHub Actions matrix passes. The immutable v1.2.0 tag and DOI `10.5281/zenodo.21306969` remain unchanged.",
        "Phase 4 acceptance is a v1.3.0 development result. It does not mutate the immutable v1.2.0 tag or DOI `10.5281/zenodo.21306969` and does not claim completion of T145-T150.",
    )
    path.write_text(body, encoding="utf-8")


def update_workflow(repo: Path) -> None:
    insert_after(
        repo / ".github/workflows/release-readiness.yml",
        "      - run: python scripts/verify_phase4_expansion.py\n",
        "      - run: python scripts/verify_phase4_ci_closure.py\n",
    )


def update_phase4_expansion_verifier(repo: Path) -> None:
    path = repo / "scripts/verify_phase4_expansion.py"
    body = path.read_text(encoding="utf-8")
    body = body.replace(
        'assert crosswalk["phase4_status"] == "BUILD_READY_CI_PENDING"',
        'assert crosswalk["phase4_status"] in {'
        '"BUILD_READY_CI_PENDING", "ACCEPTED_CI_PASS_MERGED"'
        '}',
    )
    body = body.replace(
        '    assert row["parity_status"] == "PATCH_READY_CI_PENDING"',
        '    assert row["parity_status"] in {'
        '"PATCH_READY_CI_PENDING", "ACCEPTED_CI_PASS"'
        '}',
    )
    body = body.replace(
        '    assert "BUILD_READY" in text or "BUILD READY" in text',
        '    assert any(marker in text for marker in ('
        '"BUILD_READY", "BUILD READY", "ACCEPTED / CI PASS"'
        '))',
    )
    body = body.replace(
        'assert "No accepted theorem IDs beyond T138" in status',
        'assert any(marker in status for marker in ('
        '"No accepted theorem IDs beyond T138", '
        '"No accepted theorem IDs beyond T144"'
        '))',
    )
    if "python scripts/verify_phase4_ci_closure.py" not in body:
        body = body.replace(
            '    "python scripts/verify_phase4_expansion.py",\n',
            '    "python scripts/verify_phase4_expansion.py",\n'
            '    "python scripts/verify_phase4_ci_closure.py",\n',
        )
    path.write_text(body, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".", help="Repository root")
    parser.add_argument(
        "--force",
        action="store_true",
        help="Apply despite branch, baseline, or worktree mismatch after manual review",
    )
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    package = Path(__file__).resolve().parent

    validate_repository(repo, args.force)
    copy_payload(repo, package)
    update_crosswalk(repo)
    update_readme(repo)
    update_changelog(repo)
    update_status(repo)
    update_register(repo)
    update_workflow(repo)
    update_phase4_expansion_verifier(repo)

    print("Applied V0 OSAP v1.3.0 Phase 4 CI closure and historical-preservation patch.")
    print("Phase 4 implementation merge commit:", EXPECTED_BASELINE)
    print("Recorded state: ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED")
    print("Expected pytest total: 113 passed.")
    print("Run the complete local validation matrix before committing.")


if __name__ == "__main__":
    main()
