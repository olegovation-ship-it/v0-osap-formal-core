# Apply V0 OSAP v1.3.0 Phase 4 CI Closure Patch

## Recorded implementation baseline

- Repository: `olegovation-ship-it/v0-osap-formal-core`
- Development branch: `v1.3.0-development`
- Phase 4 implementation PR: `#6`
- Phase 4 implementation head: `9cec516c8ab026ce8d63fd2303f72ec5c1d36351`
- Phase 4 implementation merge commit: `417866ec94fb24891c00bdfc2e522095777532bf`
- Implementation PR checks: `8/8 PASS`
- Immutable release: `v1.2.0`
- Immutable release DOI: `10.5281/zenodo.21306969`

## 1. Stage the package

Upload the ZIP to `v1.3.0-development` with commit message:

```text
Stage V0 OSAP v1.3.0 Phase 4 CI closure patch
```

Commit directly to `v1.3.0-development`.

## 2. Synchronize the implementation merge baseline

After the package is staged, open Codespaces and run:

```bash
cd /workspaces/v0-osap-formal-core
git checkout v1.3.0-development
git fetch origin
git pull --ff-only origin v1.3.0-development
git merge --no-edit origin/main
git push origin v1.3.0-development

git status --short
git log --oneline --decorate -5
```

The Phase 4 merge commit `417866ec94fb24891c00bdfc2e522095777532bf` must be an ancestor of the development-branch HEAD before the closure patch is applied.

## 3. Extract and apply

```bash
cd /workspaces/v0-osap-formal-core

rm -rf /tmp/phase4-ci-closure
mkdir -p /tmp/phase4-ci-closure

PHASE4_CLOSURE_ZIP=$(find . -maxdepth 1   -name 'V0_OSAP_v1.3.0_Phase_4_CI_Closure_and_Historical_Preservation_Patch_v0.1*.zip'   -print -quit)

test -n "$PHASE4_CLOSURE_ZIP" && echo "$PHASE4_CLOSURE_ZIP"

python -m zipfile -e   "$PHASE4_CLOSURE_ZIP"   /tmp/phase4-ci-closure

python   /tmp/phase4-ci-closure/V0_OSAP_v1.3.0_Phase_4_CI_Closure_and_Historical_Preservation_Patch_v0.1/apply_phase4_ci_closure.py   .
```

Expected apply result:

```text
Applied V0 OSAP v1.3.0 Phase 4 CI closure and historical-preservation patch.
Phase 4 implementation merge commit: 417866ec94fb24891c00bdfc2e522095777532bf
Recorded state: ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED
Expected pytest total: 113 passed.
```

## 4. Validate

```bash
python -m pip install -e '.[dev]'

pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures

python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py

export PATH="$HOME/.elan/bin:$PATH"
(cd lean && lake build)
(cd coq && make)

rm -f coq/.Makefile.coq.d coq/Makefile.coq.d

git diff --check
git status --short
```

Expected Python result:

```text
113 passed
```

Expected closure verifier result:

```text
PASS: V0 OSAP v1.3.0 Phase 4 CI closure, merge evidence, and v1.2.0 historical preservation verified.
```

## 5. Commit and push

```bash
git add -A
git diff --cached --check

git commit -m "Close V0 OSAP v1.3.0 Phase 4 CI and preserve history"
git push origin v1.3.0-development
```

Do not use `--no-verify`, squash, rebase, or force-push.

## 6. Create the closure PR

Create a Draft PR:

- base: `main`
- compare: `v1.3.0-development`
- title: use `PR_TITLE.txt`
- description: use `PR_BODY.md`

Wait for the complete GitHub Actions matrix. When all 8 checks pass, mark the PR ready for review and merge with a normal merge commit. Do not delete `v1.3.0-development`.
