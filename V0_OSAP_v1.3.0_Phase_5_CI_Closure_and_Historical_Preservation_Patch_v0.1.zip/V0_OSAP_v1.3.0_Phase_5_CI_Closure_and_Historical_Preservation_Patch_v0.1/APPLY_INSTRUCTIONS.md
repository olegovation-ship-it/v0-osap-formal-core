# Apply Instructions

## Target

- Repository: `olegovation-ship-it/v0-osap-formal-core`
- Branch: `v1.3.0-development`
- Required synchronized implementation merge commit: `5c689de1a30104aa6c4e3860d5e7c26746e2d797`
- Phase 5 implementation baseline: `2a769d7723470cce59df81262b586abf19b9c750`
- Phase 5 implementation head: `977c5404ebc5cdef9495edd1c46b08d3b0452acb`

## Apply

From the repository root after synchronizing `v1.3.0-development` from `origin/main`:

```bash
rm -rf /tmp/phase5-ci-closure
mkdir -p /tmp/phase5-ci-closure

python -m zipfile -e \
  V0_OSAP_v1.3.0_Phase_5_CI_Closure_and_Historical_Preservation_Patch_v0.1.zip \
  /tmp/phase5-ci-closure

python \
  /tmp/phase5-ci-closure/V0_OSAP_v1.3.0_Phase_5_CI_Closure_and_Historical_Preservation_Patch_v0.1/apply_phase5_ci_closure.py \
  .
```

Expected final state:

```text
ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED
```

## Validation

```bash
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
export PATH="$HOME/.elan/bin:$PATH"
(cd lean && lake build)
(cd coq && make)
rm -f coq/.Makefile.coq.d coq/Makefile.coq.d
git diff --check
git status --short
```

Expected Python total: `14 passed`.

## Commit

```bash
git add -A
git diff --cached --check
git commit -m "Close V0 OSAP v1.3.0 Phase 5 CI and preserve history"
git push origin v1.3.0-development
```

The patch does not release v1.3.0, move or retag `v1.2.0`, or alter DOI `10.5281/zenodo.21306969`.
