from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
PAYLOAD = PACKAGE_ROOT / "payload"

BRANCH = "v1.3.0-development"
BASELINE = "2a769d7723470cce59df81262b586abf19b9c750"
HEAD = "977c5404ebc5cdef9495edd1c46b08d3b0452acb"
MERGE = "5c689de1a30104aa6c4e3860d5e7c26746e2d797"
MERGED_AT = "2026-07-12T19:11:41Z"
DOI = "10.5281/zenodo.21306969"


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read(path: Path) -> str:
    if not path.is_file():
        fail(f"required repository file is missing: {path}")
    return path.read_text(encoding="utf-8")


def write(path: Path, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body.rstrip() + "\n", encoding="utf-8")


def replace_exact(path: Path, old: str, new: str, *, required: bool = True) -> None:
    body = read(path)
    if new in body:
        return
    if old not in body:
        if required:
            fail(f"expected text not found in {path}: {old[:100]!r}")
        return
    write(path, body.replace(old, new, 1))


def replace_regex(path: Path, pattern: str, replacement: str, *, flags: int = 0) -> None:
    body = read(path)
    updated, count = re.subn(pattern, replacement, body, count=1, flags=flags)
    if count != 1:
        fail(f"expected exactly one regex match in {path}, found {count}")
    write(path, updated)


def copy_payload(repo: Path, rel: str) -> None:
    src = PAYLOAD / rel
    if not src.is_file():
        fail(f"package payload missing: {rel}")
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def git_output(repo: Path, *args: str) -> str:
    proc = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if proc.returncode != 0:
        fail(f"git {' '.join(args)} failed:\n{proc.stdout}")
    return proc.stdout.strip()


def verify_repository_state(repo: Path, force: bool) -> None:
    if not (repo / ".git").exists():
        if force:
            return
        fail("target is not a Git working tree; use --force only for controlled testing")

    branch = git_output(repo, "branch", "--show-current")
    if branch != BRANCH and not force:
        fail(f"expected branch {BRANCH}, found {branch}")

    proc = subprocess.run(
        ["git", "merge-base", "--is-ancestor", MERGE, "HEAD"],
        cwd=repo,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if proc.returncode != 0 and not force:
        fail(
            "Phase 5 implementation merge commit is not an ancestor of HEAD. "
            "Synchronize v1.3.0-development from origin/main first."
        )


def update_crosswalk(repo: Path) -> None:
    path = repo / "release/v1.3.0/theorem_crosswalk_phase5.json"
    data = json.loads(read(path))
    if data.get("baseline_merge_commit") != BASELINE:
        fail("unexpected Phase 5 implementation baseline in theorem crosswalk")
    if data.get("theorem_range") != "T145-T150":
        fail("unexpected Phase 5 theorem range")

    data["phase5_status"] = "ACCEPTED_CI_PASS_MERGED"
    data["closure_evidence"] = "release/v1.3.0/PHASE5_CI_CLOSURE_EVIDENCE.json"
    data["pull_request"] = 8
    data["head_commit"] = HEAD
    data["merge_commit"] = MERGE
    data["merged_at_utc"] = MERGED_AT
    data["github_pr_checks"] = 8
    data["python_tests"] = 14
    data["historical_preservation"] = "PASS"
    for row in data.get("records", []):
        row["parity_status"] = "ACCEPTED_CI_PASS"
    write(path, json.dumps(data, indent=2))


def update_readme(repo: Path) -> None:
    path = repo / "README.md"
    replacement = """> **PHASE 5 T145-T150 CANONICALIZATION, REPLAY, MIGRATION, CORRESPONDENCE, AND SOUNDNESS EXPANSION - ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED**

Phase 5 adds V0-OSAP-CJ-1 canonical serialization and round-trip audits, pinned replay determinism, explicit schema-migration visibility, backend statement-hash correspondence, and conditional accepted-fragment checker soundness. Checker version: `0.6.0.dev1`.

PR #8 passed 8/8 checks and merged head commit
`977c5404ebc5cdef9495edd1c46b08d3b0452acb` into `main` as
`5c689de1a30104aa6c4e3860d5e7c26746e2d797`. The regression suite recorded
14 passing tests, and both Lean 4 and Coq builds passed.

The implementation was built from the preserved Phase 4 closure baseline
`2a769d7723470cce59df81262b586abf19b9c750`. The patch includes twelve paired fixtures,
Lean 4 and Coq Phase 5 modules, and a canonical statement-hash crosswalk.
This is an accepted v1.3.0 development state, not a v1.3.0 release. T150
remains conditional on proved rule lemmas and implementation invariants. See
`release/v1.3.0/PHASE5_ACCEPTANCE_GATES.md` and
`release/v1.3.0/PHASE5_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md`.

### Phase 4 closed baseline"""
    replace_regex(
        path,
        r"> \*\*PHASE 5 T145-T150.*?\n\n### Phase 4 closed baseline",
        replacement,
        flags=re.DOTALL,
    )


def update_changelog(repo: Path) -> None:
    path = repo / "CHANGELOG.md"
    replace_exact(
        path,
        "- Status is `BUILD_READY / CI_PENDING`; no Phase 5 acceptance or v1.3.0 release is claimed.",
        "- Status advanced to `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`; no v1.3.0 release is claimed.",
    )
    body = read(path)
    heading = "### Phase 5 CI closure"
    if heading not in body:
        insertion = f"""### Phase 5 CI closure
- Recorded PR #8 with 8/8 successful checks.
- Recorded head commit `977c5404ebc5cdef9495edd1c46b08d3b0452acb` and merge commit `5c689de1a30104aa6c4e3860d5e7c26746e2d797`.
- Recorded 14 passing Python tests, schema and fixture PASS, proof-hole PASS, Phase 1 preservation PASS, Phase 2-4 expansion/closure PASS, Phase 5 verifier PASS, Lean 4 PASS, and Coq PASS.
- Advanced T145-T150 theorem-crosswalk parity from `PATCH_READY_CI_PENDING` to `ACCEPTED_CI_PASS`.
- Added a dedicated Phase 5 CI-closure and historical-preservation verifier.
- Preserved the immutable v1.2.0 manifest and closure jobs, tag, DOI `10.5281/zenodo.21306969`, and Phase 1-4 closure history.
- Recorded the Phase 5 implementation merge baseline `5c689de1a30104aa6c4e3860d5e7c26746e2d797` for development-branch synchronization.

"""
        marker = "### Phase 4 theorem expansion T139-T144"
        if marker not in body:
            fail("Phase 4 changelog marker not found")
        write(path, body.replace(marker, insertion + marker, 1))


def update_status(repo: Path) -> None:
    path = repo / "docs/status_and_nonclaims.md"
    phase5 = f"""## v1.3.0 Phase 5

- Scope: T145-T150.
- Status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.
- Implementation baseline merge commit: `2a769d7723470cce59df81262b586abf19b9c750`.
- PR #8: 8/8 checks passed.
- Head commit: `977c5404ebc5cdef9495edd1c46b08d3b0452acb`.
- Merge commit: `5c689de1a30104aa6c4e3860d5e7c26746e2d797`.
- Merged at: `2026-07-12T19:11:41Z`.
- Checker development version: `0.6.0.dev1`.
- Python suite: 14 tests passed.
- Twelve paired fixtures and Lean 4 / Coq modules are accepted in the development tree.
- Phase 1 through Phase 4 accepted states remain preserved.
- T150 remains conditional on proved rule lemmas and implementation invariants.
- No v1.3.0 release, theorem-completeness, proof-identity, checker-completeness, unconditional global soundness, or empirical claim.

## v1.3.0 Phase 4"""
    replace_regex(
        path,
        r"## v1\.3\.0 Phase 5\n.*?\n## v1\.3\.0 Phase 4",
        phase5,
        flags=re.DOTALL,
    )
    replace_exact(
        path,
        "The Phase 2, Phase 3, and Phase 4 closure packages are development-history patches and do not rewrite the archived release.",
        "The Phase 2, Phase 3, Phase 4, and Phase 5 closure packages are development-history patches and do not rewrite the archived release.",
    )
    replace_exact(
        path,
        "- Phase 5 status: `BUILD_READY / CI PENDING`.",
        "- Phase 5 status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.",
    )
    replace_exact(
        path,
        "- No accepted theorem IDs beyond T144 in the current v1.3.0 development state; T145-T150 are build-ready and CI-pending.",
        "- No accepted theorem IDs beyond T150 in the current v1.3.0 development state.",
    )


def update_register(repo: Path) -> None:
    path = repo / "docs/theorem_register.md"
    replace_exact(
        path,
        f"Phase 5 stages the final reserved cluster T145-T150 from baseline `2a769d7723470cce59df81262b586abf19b9c750`.",
        f"Phase 5 adds the accepted final reserved cluster T145-T150 from implementation baseline `2a769d7723470cce59df81262b586abf19b9c750` and merge commit `5c689de1a30104aa6c4e3860d5e7c26746e2d797`.",
    )
    body = read(path)
    metadata = f"""Phase 5 implementation baseline merge commit: `2a769d7723470cce59df81262b586abf19b9c750`.
Phase 5 head commit: `977c5404ebc5cdef9495edd1c46b08d3b0452acb`.
Phase 5 merge commit: `5c689de1a30104aa6c4e3860d5e7c26746e2d797`.
Phase 5 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.
"""
    if "Phase 5 head commit:" not in body:
        marker = "Phase 4 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.\n"
        if marker not in body:
            fail("Phase 4 register status marker not found")
        write(path, body.replace(marker, marker + metadata, 1))

    replace_exact(
        path,
        f"Phase 5 baseline merge commit: `2a769d7723470cce59df81262b586abf19b9c750`.\nPhase 5 patch status: `BUILD_READY / CI PENDING`.",
        f"Phase 5 implementation baseline merge commit: `2a769d7723470cce59df81262b586abf19b9c750`.\nPhase 5 head commit: `977c5404ebc5cdef9495edd1c46b08d3b0452acb`.\nPhase 5 merge commit: `5c689de1a30104aa6c4e3860d5e7c26746e2d797`.\nPhase 5 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.",
    )
    body = read(path)
    body = body.replace("build-ready; CI pending", "accepted; CI passed; merged")
    body = body.replace(
        "Phase 5 is not accepted or released until the complete local and GitHub Actions matrix passes.",
        "Phase 5 is accepted, CI-passed, merged, and historically preserved as a v1.3.0 development state.",
    )
    if MERGE not in body:
        fail("Phase 5 merge commit was not recorded in theorem register")
    write(path, body)


def update_phase5_expansion_verifier(repo: Path) -> None:
    path = repo / "scripts/verify_phase5_expansion.py"
    replace_exact(
        path,
        'assert crosswalk["phase5_status"] == "BUILD_READY_CI_PENDING"',
        'assert crosswalk["phase5_status"] in {"BUILD_READY_CI_PENDING", "ACCEPTED_CI_PASS_MERGED"}',
    )
    replace_exact(
        path,
        '    assert row["parity_status"] == "PATCH_READY_CI_PENDING"',
        '    assert row["parity_status"] in {"PATCH_READY_CI_PENDING", "ACCEPTED_CI_PASS"}',
    )
    replace_exact(
        path,
        '    assert any(marker in text for marker in ("BUILD_READY", "BUILD READY"))',
        '    assert any(marker in text for marker in ("BUILD_READY", "BUILD READY", "ACCEPTED / CI PASS"))',
    )
    replace_exact(
        path,
        'assert "No accepted theorem IDs beyond T144" in status',
        'accepted_boundary = re.search(r"No accepted theorem IDs beyond T(\\d+)", status)\nassert accepted_boundary is not None\nassert int(accepted_boundary.group(1)) >= 144',
    )
    body = read(path)
    if "import re" not in body:
        body = body.replace("import json\n", "import json\nimport re\n", 1)
        write(path, body)


def update_workflow(repo: Path) -> None:
    path = repo / ".github/workflows/release-readiness.yml"
    body = read(path)
    command = "      - run: python scripts/verify_phase5_ci_closure.py"
    if command not in body:
        anchor = "      - run: python scripts/verify_phase5_expansion.py"
        if anchor not in body:
            fail("Phase 5 expansion workflow anchor not found")
        write(path, body.replace(anchor, anchor + "\n" + command, 1))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", nargs="?", default=".")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    repo = Path(args.repository).resolve()
    verify_repository_state(repo, args.force)

    for rel in [
        "release/v1.3.0/PHASE5_ACCEPTANCE_GATES.md",
        "release/v1.3.0/PHASE5_BUILD_SPECIFICATION.md",
        "release/v1.3.0/PHASE5_IMPLEMENTATION_REPORT.md",
        "release/v1.3.0/PHASE5_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
        "release/v1.3.0/PHASE5_CI_CLOSURE_EVIDENCE.json",
        "scripts/verify_phase5_ci_closure.py",
    ]:
        copy_payload(repo, rel)

    update_crosswalk(repo)
    update_readme(repo)
    update_changelog(repo)
    update_status(repo)
    update_register(repo)
    update_phase5_expansion_verifier(repo)
    update_workflow(repo)

    for rel in [
        "release/v1.3.0/PHASE5_CI_CLOSURE_EVIDENCE.json",
        "release/v1.3.0/theorem_crosswalk_phase5.json",
    ]:
        json.loads(read(repo / rel))

    print("Applied V0 OSAP v1.3.0 Phase 5 CI closure and historical-preservation patch.")
    print(f"Implementation baseline: {BASELINE}")
    print(f"Implementation head: {HEAD}")
    print(f"Merge commit: {MERGE}")
    print("Recorded state: ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED")
    print("Immutable v1.2.0 tag and DOI remain unchanged.")


if __name__ == "__main__":
    main()
