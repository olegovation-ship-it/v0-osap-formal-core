#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$PWD}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VALIDATED_COMMIT="48db564c085aec411552e78eef6c1740bd27a5ac"

cd "$REPO"

if [ ! -d .git ]; then
  echo "ERROR: $REPO is not a Git repository root." >&2
  exit 2
fi

if [ -f "$HOME/.elan/env" ]; then
  # shellcheck disable=SC1090
  source "$HOME/.elan/env"
fi

if ! command -v lake >/dev/null 2>&1; then
  curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y
  # shellcheck disable=SC1090
  source "$HOME/.elan/env"
fi

if ! command -v coqc >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y coq
fi

python -m pip install -e '.[dev]'

LEAN_VERSION="$(cd lean && lean --version | head -n 1)"
COQ_VERSION="$(coqc --version | head -n 1)"
PYTHON_VERSION="$(python --version 2>&1 | head -n 1)"
PATCH_BASE_COMMIT="$(git rev-parse HEAD)"
GENERATED_AT_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

printf 'Lean: %s
' "$LEAN_VERSION"
printf 'Coq: %s
' "$COQ_VERSION"
printf 'Python: %s
' "$PYTHON_VERSION"

(
  cd lean
  lake build
)

python scripts/check_no_proof_holes.py

make -C coq clean
make -C coq
make -C coq clean

pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures

python "$PATCH_DIR/apply_v1_2_0_closure.py"   --repo "$REPO"   --validated-commit "$VALIDATED_COMMIT"   --patch-base-commit "$PATCH_BASE_COMMIT"   --lean-version "$LEAN_VERSION"   --coq-version "$COQ_VERSION"   --python-version "$PYTHON_VERSION"   --generated-at-utc "$GENERATED_AT_UTC"

cat > release/closure_preflight.txt <<EOF
V0 OSAP v1.2.0 compiler-passed closure preflight
Generated UTC: $GENERATED_AT_UTC
Validated CI commit: $VALIDATED_COMMIT
Patch base commit: $PATCH_BASE_COMMIT
Lean: $LEAN_VERSION
Coq: $COQ_VERSION
Python: $PYTHON_VERSION
Lean build: PASS
Coq build: PASS
Proof-hole scan: PASS
Python tests: PASS
Schema bundle: PASS
Fixture replay: PASS
EOF

python scripts/build_manifest.py
python scripts/verify_manifest.py
python scripts/verify_closure.py

echo "V0 OSAP v1.2.0 closure patch applied successfully."
echo "Review git status, then commit and push."
