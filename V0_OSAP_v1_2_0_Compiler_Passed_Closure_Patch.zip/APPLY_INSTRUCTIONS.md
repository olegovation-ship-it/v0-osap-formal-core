# V0 OSAP v1.2.0 Compiler-Passed Closure Patch

This patch closes the repository bootstrap as a bounded, dual-backend compiler-passed FC-1 baseline.

## Evidence basis

The patch records GitHub Actions commit:

`48db564c085aec411552e78eef6c1740bd27a5ac`

At that commit the following workflows were observed as passing:

- Schema validation
- Python checker
- Lean 4
- Coq
- Release readiness

The patch does **not** claim mechanization of T1-T150, proof equivalence between Lean and Coq, empirical validation of V0, or a DOI before archival.

## Apply in Codespaces

First upload `V0_OSAP_v1_2_0_Compiler_Passed_Closure_Patch.zip` to the repository root as a temporary staging file and commit it.

Then paste this block into the Codespace terminal:

```bash
cd /workspaces/v0-osap-formal-core

git pull origin main

rm -rf /tmp/V0_OSAP_v1_2_0_Compiler_Passed_Closure_Patch
python -m zipfile -e \
  V0_OSAP_v1_2_0_Compiler_Passed_Closure_Patch.zip \
  /tmp/V0_OSAP_v1_2_0_Compiler_Passed_Closure_Patch

rm V0_OSAP_v1_2_0_Compiler_Passed_Closure_Patch.zip

bash /tmp/V0_OSAP_v1_2_0_Compiler_Passed_Closure_Patch/apply_v1_2_0_closure.sh \
  /workspaces/v0-osap-formal-core

git status --short
```

Expected final local messages include:

```text
Build completed successfully.
PASS: no prohibited proof-hole markers detected.
PASS: verified ... manifest entries.
PASS: v1.2.0 compiler-passed closure metadata verified.
```

Then commit and push:

```bash
git add -A
git commit -m "Close V0 OSAP v1.2.0 compiler-passed baseline"
git push origin main
```

Wait until all five GitHub Actions workflows are green. Only then create the tag:

```bash
git tag -a v1.2.0 -m "V0 OSAP Formal Core v1.2.0 — compiler-passed FC-1 baseline"
git push origin v1.2.0
```

Use `release/RELEASE_NOTES_v1.2.0.md` as the GitHub Release text. Connect Zenodo only after the tag and immutable GitHub Release exist.
