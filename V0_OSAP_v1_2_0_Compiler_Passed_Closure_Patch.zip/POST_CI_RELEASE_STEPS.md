# Post-CI release steps

Do not tag until the closure commit has five green workflows.

1. Confirm Schema validation, Python checker, Lean 4, Coq, and Release readiness are green on the closure commit.
2. Create annotated tag `v1.2.0`.
3. Push the tag.
4. Create GitHub Release titled `V0 OSAP Formal Core v1.2.0 — Compiler-Passed FC-1 Baseline`.
5. Paste `release/RELEASE_NOTES_v1.2.0.md` into the release description.
6. Archive through Zenodo and obtain the DOI.
7. Add the DOI to `CITATION.cff`, README, release notes, and repository About metadata in a later DOI/backlink patch.

The tag must point to a commit with all five workflows green.
