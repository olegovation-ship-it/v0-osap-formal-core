from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument('--repo', required=True)
    p.add_argument('--validated-commit', required=True)
    p.add_argument('--patch-base-commit', required=True)
    p.add_argument('--lean-version', required=True)
    p.add_argument('--coq-version', required=True)
    p.add_argument('--python-version', required=True)
    p.add_argument('--generated-at-utc', required=True)
    return p.parse_args()


def render(text: str, values: dict[str, str]) -> str:
    for key, value in values.items():
        text = text.replace('{{' + key + '}}', value)
    return text


def main() -> None:
    args = parse_args()
    repo = Path(args.repo).resolve()
    patch = Path(__file__).resolve().parent
    if not (repo / '.git').is_dir():
        raise SystemExit(f'Not a repository root: {repo}')

    values = {
        'VALIDATED_COMMIT': args.validated_commit,
        'PATCH_BASE_COMMIT': args.patch_base_commit,
        'LEAN_VERSION': args.lean_version,
        'COQ_VERSION': args.coq_version,
        'PYTHON_VERSION': args.python_version,
        'GENERATED_AT_UTC': args.generated_at_utc,
        'RELEASE_DATE': '2026-07-11',
    }

    static_root = patch / 'files'
    for src in sorted(static_root.rglob('*')):
        if not src.is_file():
            continue
        rel = src.relative_to(static_root)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    template_root = patch / 'templates'
    for src in sorted(template_root.rglob('*.tmpl')):
        rel = src.relative_to(template_root)
        rel = Path(str(rel)[:-5])
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(render(src.read_text(encoding='utf-8'), values), encoding='utf-8', newline='\n')

    versions = {
        'closure_version': 'v1.2.0',
        'validated_commit': args.validated_commit,
        'patch_base_commit': args.patch_base_commit,
        'generated_at_utc': args.generated_at_utc,
        'lean_version': args.lean_version,
        'coq_version': args.coq_version,
        'python_version': args.python_version,
        'checker_version': '0.1.0',
        'ci_status': {
            'schema_validation': 'PASS',
            'python_checker': 'PASS',
            'lean4': 'PASS',
            'coq': 'PASS',
            'release_readiness': 'PASS',
        },
        'scope': 'FC-1 initial mechanized subset T121-T126',
        'nonclaim': 'No completeness, cross-assistant equivalence, empirical V0, or DOI claim.',
    }
    out = repo / 'release' / 'compiler_versions.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(versions, indent=2, sort_keys=True) + '\n', encoding='utf-8')

    print('Rendered v1.2.0 closure files.')


if __name__ == '__main__':
    main()
