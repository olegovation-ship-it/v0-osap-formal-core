# Apply V0 OSAP v1.3.0 Phase 4

## Baseline

- Repository: `olegovation-ship-it/v0-osap-formal-core`
- Branch: `v1.3.0-development`
- Baseline merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`
- Phase 3 status: accepted, CI-closed, merged, and historically preserved
- Immutable release: `v1.2.0`, DOI `10.5281/zenodo.21306969`

## Stage the package

Upload the ZIP to `v1.3.0-development` with commit message:

```text
Stage V0 OSAP v1.3.0 Phase 4 build patch
```

## Apply in Codespaces

```bash
cd /workspaces/v0-osap-formal-core
git checkout v1.3.0-development
git pull --ff-only origin v1.3.0-development

rm -rf /tmp/phase4-build
mkdir -p /tmp/phase4-build

python -m zipfile -e \
  V0_OSAP_v1.3.0_Phase_4_Build_Specification_and_Implementation_Patch_v0.1*.zip \
  /tmp/phase4-build

python \
  /tmp/phase4-build/V0_OSAP_v1.3.0_Phase_4_Build_Specification_and_Implementation_Patch_v0.1/apply_phase4_patch.py \
  .
```

The apply script accepts a staging commit above the baseline because it verifies that `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30` is an ancestor of `HEAD`.

Expected apply message:

```text
Applied V0 OSAP v1.3.0 Phase 4 T139-T144 build patch.
```

## Validate

```bash
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
(cd lean && lake build)
(cd coq && make)
rm -f coq/.Makefile.coq.d coq/Makefile.coq.d
git diff --check
git status --short
```

Expected Python result:

```text
113 passed
```

## Commit and push

```bash
git add \
  .github/workflows/release-readiness.yml \
  CHANGELOG.md README.md pyproject.toml \
  checker/v0_osap_fc1/__init__.py checker/v0_osap_fc1/semantic.py \
  schemas/v1.1/registry_state.schema.json schemas/v1.1/ERRATA_PHASE4.md \
  fixtures/manifest.json fixtures/positive fixtures/negative \
  lean/V0OSAP.lean lean/V0OSAP/Theorems.lean lean/V0OSAP/Phase4.lean \
  coq/_CoqProject coq/theories/Theorems.v coq/theories/Phase4.v \
  docs/status_and_nonclaims.md docs/theorem_register.md \
  release/v1.3.0/PHASE4_BUILD_SPECIFICATION.md \
  release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md \
  release/v1.3.0/PHASE4_IMPLEMENTATION_REPORT.md \
  release/v1.3.0/theorem_crosswalk_phase4.json \
  scripts/verify_phase1_alignment.py \
  scripts/verify_phase2_expansion.py \
  scripts/verify_phase2_ci_closure.py \
  scripts/verify_phase3_expansion.py \
  scripts/verify_phase3_ci_closure.py \
  scripts/verify_phase4_expansion.py \
  tests/test_phase4_expansion.py

git commit -m "Build V0 OSAP v1.3.0 Phase 4 theorem expansion T139-T144"
git push origin v1.3.0-development
```

Create a Draft PR using `PR_TITLE.txt` and `PR_BODY.md`. Do not mark it ready or merge it until the complete GitHub Actions matrix is green.
