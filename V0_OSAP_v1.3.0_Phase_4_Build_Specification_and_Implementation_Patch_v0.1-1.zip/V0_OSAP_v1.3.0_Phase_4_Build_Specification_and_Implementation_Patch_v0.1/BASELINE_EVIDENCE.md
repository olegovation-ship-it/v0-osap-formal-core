# Phase 4 baseline evidence

Repository: `olegovation-ship-it/v0-osap-formal-core`  
Development branch: `v1.3.0-development`  
Phase 3 closure PR: `#5`  
Phase 3 closure head: `944943fa67eda45c071d190862f1d3af284ce377`  
Phase 3 closure merge commit: `24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`  
Phase 3 closure state: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`  
Immutable release tag: `v1.2.0`  
Immutable release DOI: `10.5281/zenodo.21306969`

The Phase 4 package uses the Phase 3 closure merge commit as its ancestry guard. A staging ZIP commit may be present above that baseline.
