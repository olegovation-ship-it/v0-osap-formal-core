#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path

EXPECTED_BASE = "24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30"
EXPECTED_BRANCH = "v1.3.0-development"
NEW_VERSION = "0.5.0.dev1"
NEW_FILES = ['coq/theories/Phase4.v', 'fixtures/negative/t139_archive_guard_export.fixture.json', 'fixtures/negative/t139_archive_guard_export.registry.json', 'fixtures/negative/t140_noncompliant_witness_certificate.fixture.json', 'fixtures/negative/t140_noncompliant_witness_certificate.registry.json', 'fixtures/negative/t141_v0_ordinary_contains_branch.fixture.json', 'fixtures/negative/t141_v0_ordinary_contains_branch.registry.json', 'fixtures/negative/t142_label_only_branch_distinctness.fixture.json', 'fixtures/negative/t142_label_only_branch_distinctness.registry.json', 'fixtures/negative/t143_nonfinite_cardinality_unlicensed.fixture.json', 'fixtures/negative/t143_nonfinite_cardinality_unlicensed.registry.json', 'fixtures/negative/t144_wrong_primary_status.fixture.json', 'fixtures/negative/t144_wrong_primary_status.registry.json', 'fixtures/positive/t139_archive_non_guard_export.fixture.json', 'fixtures/positive/t139_archive_non_guard_export.registry.json', 'fixtures/positive/t140_independent_witness_certificate.fixture.json', 'fixtures/positive/t140_independent_witness_certificate.registry.json', 'fixtures/positive/t141_no_container.fixture.json', 'fixtures/positive/t141_no_container.registry.json', 'fixtures/positive/t142_policy_based_branch_distinctness.fixture.json', 'fixtures/positive/t142_policy_based_branch_distinctness.registry.json', 'fixtures/positive/t143_countable_cardinality_licensed.fixture.json', 'fixtures/positive/t143_countable_cardinality_licensed.registry.json', 'fixtures/positive/t144_diagnostic_precedence_totality.fixture.json', 'fixtures/positive/t144_diagnostic_precedence_totality.registry.json', 'lean/V0OSAP/Phase4.lean', 'release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md', 'release/v1.3.0/PHASE4_BUILD_SPECIFICATION.md', 'release/v1.3.0/PHASE4_IMPLEMENTATION_REPORT.md', 'release/v1.3.0/theorem_crosswalk_phase4.json', 'schemas/v1.1/ERRATA_PHASE4.md', 'scripts/verify_phase4_expansion.py', 'tests/test_phase4_expansion.py']
PHASE4_FIXTURES = ['positive/t139_archive_non_guard_export.fixture.json', 'negative/t139_archive_guard_export.fixture.json', 'positive/t140_independent_witness_certificate.fixture.json', 'negative/t140_noncompliant_witness_certificate.fixture.json', 'positive/t141_no_container.fixture.json', 'negative/t141_v0_ordinary_contains_branch.fixture.json', 'positive/t142_policy_based_branch_distinctness.fixture.json', 'negative/t142_label_only_branch_distinctness.fixture.json', 'positive/t143_countable_cardinality_licensed.fixture.json', 'negative/t143_nonfinite_cardinality_unlicensed.fixture.json', 'positive/t144_diagnostic_precedence_totality.fixture.json', 'negative/t144_wrong_primary_status.fixture.json']
SEMANTIC_BLOCK = '\n    # Phase 4: T139-T144 archive, witness, branch, cardinality, and diagnostic precedence.\n    evidence_by_id = {\n        str(item.get("evidence_id")): item\n        for item in evidence\n        if isinstance(item, dict) and item.get("evidence_id")\n    }\n    for claim in claims:\n        if not isinstance(claim, dict):\n            continue\n        kind = claim.get("kind")\n        path = "/claims"\n\n        if kind == "archive_guard_export":\n            if claim.get("exports_current_guard") is True:\n                diagnostics.append(Diagnostic(\n                    "ARCHIVE_CANNOT_EXPORT_CURRENT_GUARD", "REJECT", 86,\n                    "An archive preserves evidence but cannot export a current observer guard.",\n                    path, tuple(str(x) for x in [\n                        claim.get("claim_id"), claim.get("archive_id"), claim.get("observer_id")\n                    ]),\n                ))\n\n        elif kind == "external_witness_certificate":\n            external = [str(item) for item in claim.get("external_evidence_ids", [])]\n            independence = [str(item) for item in claim.get("independence_group_ids", [])]\n            admissible = (\n                claim.get("policy_compliant") is True\n                and claim.get("non_circular") is True\n                and claim.get("identity_verified") is True\n                and claim.get("evidence_verified") is True\n                and bool(external)\n                and bool(independence)\n                and all(item in evidence_ids for item in external)\n            )\n            if not admissible:\n                diagnostics.append(Diagnostic(\n                    "INDEPENDENT_WITNESS_CERTIFICATE_UNSUPPORTED", "REJECT", 85,\n                    "An external witness certificate requires policy compliance, non-circularity, verified identity/evidence, external evidence, and an independence group.",\n                    path, tuple(str(x) for x in [\n                        claim.get("claim_id"), claim.get("observer_id"), claim.get("witness_id")\n                    ]), tuple(external),\n                ))\n\n        elif kind == "v0_branch_containment":\n            container = str(claim.get("container_id"))\n            branch = str(claim.get("contained_branch_id"))\n            if declaration_sorts.get(container) != "NullMark" or declaration_sorts.get(branch) != "Branch":\n                diagnostics.append(Diagnostic(\n                    "CONTAINMENT_REFERENCE_SORT_MISMATCH", "REJECT", 82,\n                    "V0 containment audit requires a NullMark container reference and a Branch target reference.",\n                    path, (str(claim.get("claim_id")), container, branch),\n                ))\n            elif claim.get("containment_mode") == "ordinary":\n                diagnostics.append(Diagnostic(\n                    "V0_ORDINARY_CONTAINS_FORBIDDEN", "REJECT", 81,\n                    "V0 has no ordinary Contains relation to a branch in FC-1.",\n                    path, (str(claim.get("claim_id")), container, branch),\n                ))\n\n        elif kind == "branch_distinctness":\n            basis = claim.get("distinctness_basis")\n            proof_evidence = [str(item) for item in claim.get("evidence_ids", [])]\n            if basis == "label_only":\n                diagnostics.append(Diagnostic(\n                    "BRANCH_LABELS_DO_NOT_PROVE_DISTINCTNESS", "REJECT", 80,\n                    "Different branch labels do not prove branch distinctness.",\n                    path, tuple(str(x) for x in [\n                        claim.get("claim_id"), claim.get("left_branch_id"),\n                        claim.get("right_branch_id"), claim.get("left_label"), claim.get("right_label")\n                    ]),\n                ))\n            elif not proof_evidence or not all(item in evidence_ids for item in proof_evidence):\n                diagnostics.append(Diagnostic(\n                    "BRANCH_DISTINCTNESS_EVIDENCE_REQUIRED", "DEFERRED", 79,\n                    "A non-label branch-distinctness basis requires resolved evidence.",\n                    path, tuple(str(x) for x in [\n                        claim.get("claim_id"), claim.get("left_branch_id"), claim.get("right_branch_id")\n                    ]), tuple(proof_evidence),\n                ))\n\n        elif kind == "branch_cardinality":\n            cardinality_kind = claim.get("cardinality_kind")\n            if cardinality_kind != "finite_enumerated":\n                meta_index_id = str(claim.get("meta_index_id") or "")\n                meta_index = evidence_by_id.get(meta_index_id)\n                proof_evidence = [str(item) for item in claim.get("evidence_ids", [])]\n                licensed = (\n                    meta_index is not None\n                    and meta_index.get("evidence_type") == "meta_index_certificate"\n                    and bool(proof_evidence)\n                    and all(item in evidence_ids for item in proof_evidence)\n                )\n                if not licensed:\n                    diagnostics.append(Diagnostic(\n                        "DEFERRED_CARDINALITY_CERT", "DEFERRED", 78,\n                        "A non-finite cardinality claim requires a typed meta-index and proof evidence.",\n                        path, tuple(str(x) for x in [\n                            claim.get("claim_id"), cardinality_kind, meta_index_id\n                        ]), tuple(proof_evidence),\n                    ))\n\n        elif kind == "diagnostic_precedence_audit":\n            statuses = [str(item) for item in claim.get("diagnostic_statuses", [])]\n            primary = max(statuses, key=lambda item: STATUS_RANK[item]) if statuses else "PASS"\n            if str(claim.get("expected_primary_status")) != primary:\n                diagnostics.append(Diagnostic(\n                    "DIAGNOSTIC_PRIMARY_STATUS_MISMATCH", "REJECT", 77,\n                    "The declared primary status disagrees with the fixed diagnostic precedence.",\n                    path, tuple(str(x) for x in [\n                        claim.get("claim_id"), claim.get("expected_primary_status"), primary\n                    ]),\n                ))\n\n'


def git(repo: Path, *args: str, check: bool = True) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if check and result.returncode != 0:
        raise SystemExit(result.stdout.strip())
    return result.stdout.strip()


def replace_once(path: Path, old: str, new: str) -> None:
    body = path.read_text(encoding="utf-8")
    if new in body:
        return
    if old not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {old[:100]!r}")
    path.write_text(body.replace(old, new, 1), encoding="utf-8")


def insert_after(path: Path, anchor: str, insertion: str) -> None:
    body = path.read_text(encoding="utf-8")
    if insertion.strip() in body:
        return
    if anchor not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {anchor[:100]!r}")
    path.write_text(body.replace(anchor, anchor + insertion, 1), encoding="utf-8")


def insert_before(path: Path, anchor: str, insertion: str) -> None:
    body = path.read_text(encoding="utf-8")
    if insertion.strip() in body:
        return
    if anchor not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {anchor[:100]!r}")
    path.write_text(body.replace(anchor, insertion + anchor, 1), encoding="utf-8")


def validate_base(repo: Path, force: bool) -> None:
    required = [
        "checker/v0_osap_fc1/semantic.py",
        "schemas/v1.1/registry_state.schema.json",
        "release/v1.3.0/PHASE3_CI_CLOSURE_EVIDENCE.json",
        "scripts/verify_phase3_ci_closure.py",
    ]
    missing = [rel for rel in required if not (repo / rel).exists()]
    if missing:
        raise SystemExit("Incompatible repository; missing: " + ", ".join(missing))

    branch = git(repo, "branch", "--show-current", check=False)
    if branch and branch != EXPECTED_BRANCH and not force:
        raise SystemExit(
            f"Expected branch {EXPECTED_BRANCH!r}, found {branch!r}. "
            "Checkout the development branch or use --force after review."
        )

    ancestor = subprocess.run(
        ["git", "merge-base", "--is-ancestor", EXPECTED_BASE, "HEAD"],
        cwd=repo,
    ).returncode == 0
    if not ancestor and not force:
        head = git(repo, "rev-parse", "HEAD", check=False)
        raise SystemExit(
            f"Expected baseline merge commit {EXPECTED_BASE} to be an ancestor of HEAD {head}. "
            "Synchronize the branch or use --force after review."
        )


def copy_payload(repo: Path, package: Path) -> None:
    payload = package / "payload"
    for rel in NEW_FILES:
        src = payload / rel
        if not src.exists():
            raise SystemExit(f"Package payload missing: {rel}")
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def id_schema() -> dict:
    return {
        "type": "string",
        "pattern": "^[A-Za-z][A-Za-z0-9_.:-]{0,127}$",
    }


def id_list_schema() -> dict:
    return {
        "type": "array",
        "items": id_schema(),
        "uniqueItems": True,
    }


def update_schema(repo: Path) -> None:
    path = repo / "schemas/v1.1/registry_state.schema.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    claim = data["properties"]["claims"]["items"]
    props = claim["properties"]

    additions = {
        "archive_id": id_schema(),
        "observer_id": id_schema(),
        "witness_id": id_schema(),
        "exports_current_guard": {"type": "boolean"},
        "policy_compliant": {"type": "boolean"},
        "non_circular": {"type": "boolean"},
        "identity_verified": {"type": "boolean"},
        "evidence_verified": {"type": "boolean"},
        "container_id": id_schema(),
        "contained_branch_id": id_schema(),
        "containment_mode": {"enum": ["none", "ordinary", "typed_meta"]},
        "left_branch_id": id_schema(),
        "right_branch_id": id_schema(),
        "left_label": {"type": "string"},
        "right_label": {"type": "string"},
        "distinctness_basis": {
            "enum": [
                "label_only",
                "non_isomorphism",
                "incompatible_profile",
                "observational_separation",
                "registered_policy",
            ]
        },
        "evidence_ids": id_list_schema(),
        "branch_ids": id_list_schema(),
        "cardinality_kind": {
            "enum": ["finite_enumerated", "countable", "uncountable", "proper_class"]
        },
        "meta_index_id": id_schema(),
        "diagnostic_statuses": {
            "type": "array",
            "items": {
                "enum": ["PASS", "OUT-OF-SCOPE", "INDETERMINATE", "DEFERRED", "REJECT"]
            },
        },
        "expected_primary_status": {
            "enum": ["PASS", "OUT-OF-SCOPE", "INDETERMINATE", "DEFERRED", "REJECT"]
        },
    }
    props.update(additions)

    requirements = {
        "archive_guard_export": [
            "claim_id",
            "kind",
            "archive_id",
            "observer_id",
            "register_id",
            "context_id",
            "exports_current_guard",
        ],
        "external_witness_certificate": [
            "claim_id",
            "kind",
            "observer_id",
            "witness_id",
            "policy_compliant",
            "non_circular",
            "identity_verified",
            "evidence_verified",
            "external_evidence_ids",
            "independence_group_ids",
        ],
        "v0_branch_containment": [
            "claim_id",
            "kind",
            "container_id",
            "contained_branch_id",
            "containment_mode",
        ],
        "branch_distinctness": [
            "claim_id",
            "kind",
            "left_branch_id",
            "right_branch_id",
            "left_label",
            "right_label",
            "distinctness_basis",
            "evidence_ids",
        ],
        "branch_cardinality": [
            "claim_id",
            "kind",
            "cardinality_kind",
            "branch_ids",
        ],
        "diagnostic_precedence_audit": [
            "claim_id",
            "kind",
            "diagnostic_statuses",
            "expected_primary_status",
        ],
    }

    existing_kinds = set()
    for item in claim.get("allOf", []):
        try:
            existing_kinds.add(item["if"]["properties"]["kind"]["const"])
        except (KeyError, TypeError):
            pass

    for kind, required in requirements.items():
        if kind in existing_kinds:
            continue
        claim.setdefault("allOf", []).append(
            {
                "if": {
                    "properties": {"kind": {"const": kind}},
                    "required": ["kind"],
                },
                "then": {"required": required},
            }
        )

    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def update_manifest(repo: Path) -> None:
    path = repo / "fixtures/manifest.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    for rel in PHASE4_FIXTURES:
        if rel not in data["fixtures"]:
            data["fixtures"].append(rel)
    data["bundle_id"] = "V0_OSAP_v1_3_0_phase4_fixture_corpus"
    data["semantic_version"] = "FC-1-v1.1+phase4"
    data["status"] = "PHASE4_T139_T144_PATCH_ORACLE_SET"
    data["notes"] = [
        "Phase 1, Phase 2, and Phase 3 accepted mappings are preserved.",
        "T139-T144 each have a positive and decisive countermodel fixture.",
        "Phase 4 remains BUILD_READY / CI_PENDING until local and GitHub Actions closure.",
    ]
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def update_semantic(repo: Path) -> None:
    path = repo / "checker/v0_osap_fc1/semantic.py"
    body = path.read_text(encoding="utf-8")
    body = body.replace(
        "from .diagnostics import Diagnostic, aggregate_status, sort_diagnostics",
        "from .diagnostics import STATUS_RANK, Diagnostic, aggregate_status, sort_diagnostics",
    )

    marker = (
        '    claims_by_id = {c.get("claim_id"): c for c in claims '
        'if isinstance(c, dict) and c.get("claim_id")}'
    )
    if "# Phase 4: T139-T144" not in body:
        if marker not in body:
            raise SystemExit("Phase 4 semantic insertion anchor not found.")
        body = body.replace(marker, SEMANTIC_BLOCK + marker, 1)

    body = body.replace(
        '"implementation_version": "v0-osap-fc1/0.4.0.dev1"',
        f'"implementation_version": "v0-osap-fc1/{NEW_VERSION}"',
    )
    path.write_text(body, encoding="utf-8")


def update_forward_compatibility(repo: Path) -> None:
    path = repo / "scripts/verify_phase1_alignment.py"
    body = path.read_text(encoding="utf-8")
    anchor = '    \'"implementation_version": "v0-osap-fc1/0.4.0.dev1"\',\n'
    addition = anchor + '    \'"implementation_version": "v0-osap-fc1/0.5.0.dev1"\',\n'
    if '"implementation_version": "v0-osap-fc1/0.5.0.dev1"' not in body:
        if anchor not in body:
            raise SystemExit("Phase 1 version-compatibility anchor not found.")
        body = body.replace(anchor, addition, 1)
    path.write_text(body, encoding="utf-8")

    path = repo / "scripts/verify_phase2_expansion.py"
    body = path.read_text(encoding="utf-8")
    body = body.replace(
        '{"FC-1-v1.1+phase2", "FC-1-v1.1+phase3"}',
        '{"FC-1-v1.1+phase2", "FC-1-v1.1+phase3", "FC-1-v1.1+phase4"}',
    )
    body = body.replace(
        '(\'version = "0.3.0.dev1"\', \'version = "0.4.0.dev1"\')',
        '(\'version = "0.3.0.dev1"\', \'version = "0.4.0.dev1"\', \'version = "0.5.0.dev1"\')',
    )
    anchor = '    \'"implementation_version": "v0-osap-fc1/0.4.0.dev1"\',\n'
    addition = anchor + '    \'"implementation_version": "v0-osap-fc1/0.5.0.dev1"\',\n'
    if '"implementation_version": "v0-osap-fc1/0.5.0.dev1"' not in body:
        if anchor not in body:
            raise SystemExit("Phase 2 version-compatibility anchor not found.")
        body = body.replace(anchor, addition, 1)
    path.write_text(body, encoding="utf-8")

    path = repo / "scripts/verify_phase2_ci_closure.py"
    body = path.read_text(encoding="utf-8")
    body = body.replace(
        'assert "CI pending" not in register',
        'assert "Phase 2 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`." in register',
    )
    path.write_text(body, encoding="utf-8")

    path = repo / "scripts/verify_phase3_expansion.py"
    body = path.read_text(encoding="utf-8")
    body = body.replace(
        'assert manifest["semantic_version"] == "FC-1-v1.1+phase3"',
        'assert manifest["semantic_version"] in {"FC-1-v1.1+phase3", "FC-1-v1.1+phase4"}',
    )
    body = body.replace(
        'assert manifest["status"] == "PHASE3_T133_T138_PATCH_ORACLE_SET"',
        'assert manifest["status"] in {"PHASE3_T133_T138_PATCH_ORACLE_SET", "PHASE4_T139_T144_PATCH_ORACLE_SET"}',
    )
    body = body.replace(
        'assert \'version = "0.4.0.dev1"\' in (ROOT/"pyproject.toml").read_text(encoding="utf-8")',
        'assert any(version in (ROOT/"pyproject.toml").read_text(encoding="utf-8") for version in (\'version = "0.4.0.dev1"\', \'version = "0.5.0.dev1"\'))',
    )
    body = body.replace(
        'assert \'"implementation_version": "v0-osap-fc1/0.4.0.dev1"\' in semantic',
        'assert any(version in semantic for version in (\'"implementation_version": "v0-osap-fc1/0.4.0.dev1"\', \'"implementation_version": "v0-osap-fc1/0.5.0.dev1"\'))',
    )
    path.write_text(body, encoding="utf-8")

    path = repo / "scripts/verify_phase3_ci_closure.py"
    body = path.read_text(encoding="utf-8")
    body = body.replace(
        'assert "CI pending" not in register\nassert "Actions pending" not in register',
        'assert "Phase 3 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`." in register',
    )
    path.write_text(body, encoding="utf-8")


def update_build_files(repo: Path) -> None:
    replace_once(
        repo / "pyproject.toml",
        'version = "0.4.0.dev1"',
        f'version = "{NEW_VERSION}"',
    )
    replace_once(
        repo / "checker/v0_osap_fc1/__init__.py",
        '__version__ = "0.4.0.dev1"',
        f'__version__ = "{NEW_VERSION}"',
    )

    insert_before(
        repo / "lean/V0OSAP.lean",
        "import V0OSAP.Theorems",
        "import V0OSAP.Phase4\n",
    )
    insert_after(
        repo / "lean/V0OSAP/Theorems.lean",
        "import V0OSAP.Phase3\n",
        "import V0OSAP.Phase4\n",
    )
    insert_before(
        repo / "coq/_CoqProject",
        "theories/Theorems.v",
        "theories/Phase4.v\n",
    )
    replace_once(
        repo / "coq/theories/Theorems.v",
        "From V0OSAP Require Import BasicTypes Registry Guards Prerequisites DLE Residuals Observer Branches Expansion Phase3.",
        "From V0OSAP Require Import BasicTypes Registry Guards Prerequisites DLE Residuals Observer Branches Expansion Phase3 Phase4.",
    )
    replace_once(
        repo / "coq/theories/Theorems.v",
        "(* Aggregation module. T121-T138 are proved in their respective modules. *)",
        "(* Aggregation module. T121-T144 are proved in their respective modules. *)",
    )
    insert_after(
        repo / ".github/workflows/release-readiness.yml",
        "      - run: python scripts/verify_phase3_ci_closure.py\n",
        "      - run: python scripts/verify_phase4_expansion.py\n",
    )


def update_docs(repo: Path) -> None:
    phase4_readme = f'''> **PHASE 4 T139-T144 ARCHIVE, BRANCH, CARDINALITY, AND DIAGNOSTIC EXPANSION - BUILD READY / CI PENDING**

Phase 4 adds archive non-guard export, independent-witness conditional sufficiency,
the no-container and branch-label firewalls, non-finite cardinality licensing, and
finite diagnostic-precedence totality. Checker version: `{NEW_VERSION}`.

The patch includes twelve paired fixtures, Lean 4 and Coq Phase 4 modules, and a
canonical statement-hash crosswalk. Baseline merge commit:
`{EXPECTED_BASE}`.

This is a build-ready v1.3.0 development patch, not an accepted Phase 4 state and
not a v1.3.0 release. See `release/v1.3.0/PHASE4_BUILD_SPECIFICATION.md` and
`release/v1.3.0/PHASE4_ACCEPTANCE_GATES.md`.

### Phase 3 closed baseline

'''
    insert_after(
        repo / "README.md",
        "## v1.3.0 development status\n\n",
        phase4_readme,
    )
    insert_after(
        repo / "README.md",
        "python scripts/verify_phase3_ci_closure.py\n",
        "python scripts/verify_phase4_expansion.py\n",
    )

    phase4_changelog = f'''### Phase 4 theorem expansion T139-T144
- Added executable archive/witness, no-container, branch-distinctness, cardinality, and diagnostic-precedence rules.
- Added twelve paired fixtures and Lean 4 / Coq Phase 4 modules.
- Added a canonical statement-hash theorem crosswalk and Phase 4 verifier.
- Advanced the development checker to `{NEW_VERSION}`.
- Baseline merge commit is `{EXPECTED_BASE}`.
- Status is `BUILD_READY / CI_PENDING`; no Phase 4 acceptance or v1.3.0 release is claimed.

'''
    insert_after(
        repo / "CHANGELOG.md",
        "## [Unreleased]\n\n",
        phase4_changelog,
    )
    replace_once(
        repo / "CHANGELOG.md",
        "Phase 1, Phase 2, and Phase 3 acceptance are not a v1.3.0 release",
        "Phase 1, Phase 2, and Phase 3 acceptance, and the Phase 4 build-ready patch, are not a v1.3.0 release",
    )

    phase4_status = f'''## v1.3.0 Phase 4

- Scope: T139-T144.
- Status: `BUILD_READY / CI_PENDING`.
- Baseline merge commit: `{EXPECTED_BASE}`.
- Checker development version: `{NEW_VERSION}`.
- Twelve paired fixtures and Lean 4 / Coq modules are staged.
- Phase 1, Phase 2, and Phase 3 accepted states remain preserved.
- No Phase 4 acceptance, v1.3.0 release, theorem-completeness, proof-identity, checker-completeness, or empirical claim.

'''
    insert_before(
        repo / "docs/status_and_nonclaims.md",
        "## v1.3.0 Phase 3",
        phase4_status,
    )
    phase4_assertions = '''## v1.3.0 Phase 4 assertions

- T139 forbids archive evidence from exporting a current observer guard.
- T140 requires explicit policy-compliant independent witness support.
- T141 rejects ordinary V0-to-branch containment.
- T142 rejects label-only branch distinctness.
- T143 defers non-finite cardinality claims without typed meta-index and evidence.
- T144 computes one deterministic primary status for every finite closed-status list.

'''
    insert_before(
        repo / "docs/status_and_nonclaims.md",
        "## Acceptance state",
        phase4_assertions,
    )
    replace_once(
        repo / "docs/status_and_nonclaims.md",
        "- Phase 3 status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.\n",
        "- Phase 3 status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.\n"
        "- Phase 4 status: `BUILD_READY / CI_PENDING`.\n",
    )
    replace_once(
        repo / "docs/status_and_nonclaims.md",
        "- No accepted theorem IDs beyond T138 in the current v1.3.0 development state.",
        "- No accepted theorem IDs beyond T138 in the current v1.3.0 development state; T139-T144 are build-ready and CI-pending.",
    )

    path = repo / "docs/theorem_register.md"
    body = path.read_text(encoding="utf-8")
    old = (
        "Phase 3 adds the accepted development cluster T133-T138 under the "
        "same historical-preservation boundary."
    )
    new = (
        old
        + " Phase 4 stages T139-T144 as build-ready and CI-pending from "
        + f"closure merge commit `{EXPECTED_BASE}`."
    )
    if new not in body:
        if old not in body:
            raise SystemExit("Theorem-register Phase 3 scope anchor not found.")
        body = body.replace(old, new, 1)

    anchor = (
        "Phase 3 patch status: `ACCEPTED / CI PASS / MERGED / "
        "HISTORICALLY PRESERVED`.\n"
    )
    addition = (
        f"Phase 4 baseline merge commit: `{EXPECTED_BASE}`.\n"
        "Phase 4 patch status: `BUILD_READY / CI_PENDING`.\n"
    )
    if addition.strip() not in body:
        if anchor not in body:
            raise SystemExit("Theorem-register status anchor not found.")
        body = body.replace(anchor, anchor + addition, 1)

    if "## Phase 4 theorem expansion" not in body:
        body = body.rstrip() + f'''

## Phase 4 theorem expansion

| ID | Canonical name | Python | Lean 4 | Coq | Status |
|---|---|---|---|---|---|
| T139 | Archive non-guard-export | archive current-guard export audit | T139_archive_non_guard_export | T139_archive_non_guard_export | build-ready; CI pending |
| T140 | Independent-witness conditional sufficiency | witness policy/independence audit | T140_independent_witness_conditional_sufficiency | T140_independent_witness_conditional_sufficiency | build-ready; CI pending |
| T141 | No-container | NullMark ordinary-containment firewall | T141_no_container | T141_no_container | build-ready; CI pending |
| T142 | Branch-label insufficiency | distinctness-basis audit | T142_branch_label_insufficiency | T142_branch_label_insufficiency | build-ready; CI pending |
| T143 | Cardinality licensing | typed meta-index/evidence audit | T143_cardinality_licensing | T143_cardinality_licensing | build-ready; CI pending |
| T144 | Diagnostic precedence totality | finite primary-status replay | T144_diagnostic_precedence_totality | T144_diagnostic_precedence_totality | build-ready; CI pending |

Phase 4 is not accepted or released until the complete local and GitHub Actions matrix passes. The immutable v1.2.0 tag and DOI `10.5281/zenodo.21306969` remain unchanged.
'''
    path.write_text(body.rstrip() + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".", help="Repository root")
    parser.add_argument(
        "--force",
        action="store_true",
        help="Apply despite branch/baseline mismatch after manual review",
    )
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    package = Path(__file__).resolve().parent

    validate_base(repo, args.force)
    copy_payload(repo, package)
    update_schema(repo)
    update_manifest(repo)
    update_semantic(repo)
    update_forward_compatibility(repo)
    update_build_files(repo)
    update_docs(repo)

    print("Applied V0 OSAP v1.3.0 Phase 4 T139-T144 build patch.")
    print("Baseline merge commit:", EXPECTED_BASE)
    print("Expected pytest total: 113 passed.")
    print("Run the complete local validation matrix before committing.")


if __name__ == "__main__":
    main()
