from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

REQUIRED_CLOSURE_MERGE = "cf9a05b46b9b6f29cd85942f99155f89a49817a7"
BRANCH = "v1.3.0-development"
CANDIDATE_TAGS = ("v1.3.0-rc1", "v1.3.0")

README_BLOCK = """<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->
> **V0 OSAP v1.3.0 RC1 TAG AUTHORIZATION AND GITHUB PRERELEASE PREPARATION - RC1_TAG_AUTHORIZED / TAG_NOT_CREATED / PRERELEASE_NOT_CREATED**

PR #13 completed the RC1 release-closure stage and merged as
`cf9a05b46b9b6f29cd85942f99155f89a49817a7`. Post-merge GitHub Actions checks for Python, schema validation,
RC1 gate audit, release readiness, clean-room release replay, Lean 4, and Coq
were observed successful on `main`; the corresponding synchronized development
checks also passed.

This patch separately authorizes `cf9a05b46b9b6f29cd85942f99155f89a49817a7` as the only permitted target for the
annotated tag `v1.3.0-rc1`. It installs a final tag message, target-specific
authorization record, GitHub pre-release metadata and notes, deterministic
authorization manifest, validation-only CI workflow, and explicit dry-run-first
creation scripts.

Applying or merging this patch creates no tag and no GitHub Release. After the
authorization PR itself passes CI and is merged, the annotated tag and pre-release
must be created by separate explicit commands and then recorded by a subsequent
evidence-closure patch.

Historical tag `v1.2.0`, target `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`, and DOI `10.5281/zenodo.21306969` remain
immutable. T140, T150, and T156 remain conditional. The final tag `v1.3.0`,
Zenodo publication, and DOI mutation remain unauthorized.

See `release/v1.3.0/RC1_TAG_AUTHORIZATION_AND_GITHUB_PRERELEASE_SPECIFICATION.md`
and `release/v1.3.0/RC1_TAG_AUTHORIZATION_GATES.md`.
<!-- V0_OSAP_RC1_GATE_AUDIT_END -->"""

CHANGELOG_BLOCK = """<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->
## [Unreleased] - v1.3.0 RC1 tag authorization and GitHub pre-release preparation

- Recorded PR #13 closure merge commit `cf9a05b46b9b6f29cd85942f99155f89a49817a7`.
- Recorded successful post-merge CI for Python, schema, audit, readiness, clean-room replay, Lean 4, and Coq.
- Separately authorized `cf9a05b46b9b6f29cd85942f99155f89a49817a7` as the exact target of `v1.3.0-rc1`.
- Added final annotated-tag text, GitHub pre-release notes, and machine-readable metadata.
- Added deterministic tag-authorization manifest and verifier.
- Added dry-run-first scripts for annotated-tag and GitHub pre-release creation.
- Added a validation-only CI workflow containing no tag or release command.
- Preserved T140, T150, and T156 conditionality and all global non-claims.
- Preserved immutable tag `v1.2.0`, its target commit, and DOI `10.5281/zenodo.21306969`.
- Created no RC1 tag, final tag, GitHub Release, Zenodo version, or DOI change.
- State: `RC1_TAG_AUTHORIZED / TAG_NOT_CREATED / PRERELEASE_NOT_CREATED`.
<!-- V0_OSAP_RC1_CHANGELOG_END -->"""

STATUS_BLOCK = """<!-- V0_OSAP_RC1_STATUS_BEGIN -->
## v1.3.0 RC1 tag authorization and GitHub pre-release preparation

- Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.
- Status: `RC1_TAG_AUTHORIZED / TAG_NOT_CREATED / PRERELEASE_NOT_CREATED`.
- Gate-audit PR: #12; merge commit: `29f9ec108efbb419fd030573b33ef5d30486d2ab`.
- Release-closure PR: #13; merge commit and authorized tag target: `cf9a05b46b9b6f29cd85942f99155f89a49817a7`.
- Checker development version remains `0.7.0.dev1`.
- Candidate tag name: `v1.3.0-rc1`.
- Historical tag `v1.2.0` remains pinned to `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`.
- Historical DOI remains `10.5281/zenodo.21306969`.
- T121-T150 remain the normative v1.1 range; T151-T156 remain explicit post-v1.1 extensions.
- T140, T150, and T156 remain conditional.
- Tag-target authorization is complete; tag creation and GitHub pre-release publication are not yet complete.
- The final tag `v1.3.0`, Zenodo version creation, and DOI mutation remain unauthorized.
- No checker-completeness, unconditional global soundness, proof-term identity, global conservativity, empirical, physical, or cosmological claim is made.
<!-- V0_OSAP_RC1_STATUS_END -->"""


def run(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run([*args], cwd=root, text=True, capture_output=True, check=check)


def replace_marker_block(path: Path, start: str, end: str, replacement: str) -> None:
    text = path.read_text(encoding="utf-8")
    if text.count(start) != 1 or text.count(end) != 1:
        raise SystemExit(f"ERROR: marker cardinality mismatch in {path}")
    begin = text.index(start)
    finish = text.index(end, begin) + len(end)
    path.write_text(text[:begin] + replacement + text[finish:], encoding="utf-8", newline="\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.repository).resolve()
    package_root = Path(__file__).resolve().parent
    payload = package_root / "payload"

    required = [
        root / ".git",
        root / "pyproject.toml",
        root / "release/v1.3.0/RC1_RELEASE_CLOSURE_MANIFEST.json",
        root / "release/v1.3.0/RC1_TAG_PREPARATION_RECORD.json",
    ]
    if not all(path.exists() for path in required):
        raise SystemExit("ERROR: target is not the V0 OSAP formal-core repository root")

    branch = run(root, "git", "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    if branch != BRANCH:
        raise SystemExit(f"ERROR: expected branch {BRANCH}, found {branch}")

    ancestor = run(root, "git", "merge-base", "--is-ancestor", REQUIRED_CLOSURE_MERGE, "HEAD", check=False)
    if ancestor.returncode != 0:
        raise SystemExit(f"ERROR: required closure merge {REQUIRED_CLOSURE_MERGE} is not an ancestor of HEAD")

    if run(root, "git", "status", "--porcelain").stdout.strip():
        raise SystemExit("ERROR: worktree must be clean before patch application")

    for tag in CANDIDATE_TAGS:
        if run(root, "git", "tag", "--list", tag).stdout.strip():
            raise SystemExit(f"ERROR: release tag already exists: {tag}")

    for source in sorted(payload.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(payload)
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)

    replace_marker_block(
        root / "README.md",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_END -->",
        README_BLOCK,
    )
    replace_marker_block(
        root / "CHANGELOG.md",
        "<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->",
        "<!-- V0_OSAP_RC1_CHANGELOG_END -->",
        CHANGELOG_BLOCK,
    )
    replace_marker_block(
        root / "docs/status_and_nonclaims.md",
        "<!-- V0_OSAP_RC1_STATUS_BEGIN -->",
        "<!-- V0_OSAP_RC1_STATUS_END -->",
        STATUS_BLOCK,
    )

    run(root, sys.executable, "scripts/build_rc1_release_closure_manifest.py")
    run(root, sys.executable, "scripts/build_rc1_tag_authorization_manifest.py")
    closure = run(root, sys.executable, "scripts/verify_rc1_release_closure.py")
    authorization = run(root, sys.executable, "scripts/verify_rc1_tag_authorization.py")

    print(closure.stdout.strip())
    print(authorization.stdout.strip())
    print("Applied V0 OSAP v1.3.0 RC1 tag-authorization and GitHub pre-release patch v0.1.")
    print(f"Authorized tag target: {REQUIRED_CLOSURE_MERGE}")
    print("Recorded state: RC1_TAG_AUTHORIZED / TAG_NOT_CREATED / PRERELEASE_NOT_CREATED")
    print("No tag, GitHub Release, Zenodo version, or DOI action was executed.")
    print("Run the full local validation matrix before committing.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
