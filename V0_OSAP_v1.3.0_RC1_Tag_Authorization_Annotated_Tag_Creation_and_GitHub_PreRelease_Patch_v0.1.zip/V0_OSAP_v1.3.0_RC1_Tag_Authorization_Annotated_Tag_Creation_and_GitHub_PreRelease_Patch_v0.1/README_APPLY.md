# V0 OSAP v1.3.0 RC1 Tag Authorization, Annotated Tag Creation, and GitHub Pre-Release Patch v0.1

This package separately authorizes the exact commit `cf9a05b46b9b6f29cd85942f99155f89a49817a7` as the target of
the annotated tag `v1.3.0-rc1` and prepares the GitHub pre-release. Applying the
package does **not** create a tag or release.

## State after application

`RC1_TAG_AUTHORIZED / TAG_NOT_CREATED / PRERELEASE_NOT_CREATED`

## Apply

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git fetch origin
git pull --ff-only origin v1.3.0-development

ZIP="V0_OSAP_v1.3.0_RC1_Tag_Authorization_Annotated_Tag_Creation_and_GitHub_PreRelease_Patch_v0.1.zip"
TMP="/tmp/v0-osap-rc1-tag-authorization"
rm -rf "$TMP"
mkdir -p "$TMP"
python -m zipfile -e "$ZIP" "$TMP"

APPLY_SCRIPT="$(find "$TMP" -name apply_rc1_tag_authorization_prerelease_patch.py -print -quit)"
test -n "$APPLY_SCRIPT" || { echo "ERROR: apply script not found"; exit 1; }
python "$APPLY_SCRIPT" /workspaces/v0-osap-formal-core
```

## Local validation before commit

```bash
cd /workspaces/v0-osap-formal-core
python -m pip install -e '.[dev]'

python scripts/build_rc1_release_inventory.py
python scripts/verify_rc1_statement_parity.py
python scripts/verify_rc1_gate_audit.py
python scripts/build_rc1_release_closure_manifest.py
python scripts/verify_rc1_release_closure.py --require-tags
python scripts/build_rc1_tag_authorization_manifest.py
python scripts/verify_rc1_tag_authorization.py --require-tags

python -m pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py

python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
python scripts/verify_phase6_expansion.py
python scripts/verify_phase6_ci_closure.py

(cd lean && lake build)
(cd coq && make)

python scripts/create_rc1_annotated_tag.py
git diff --check
git status --short
```

The tag-creation script must print a dry run and must not create a tag.

## Commit and PR

```bash
git add -A
git diff --cached --check
git commit -m "Authorize V0 OSAP v1.3.0 RC1 tag target and prerelease"
git push origin v1.3.0-development
```

Open a draft PR against `main`. Merge only after all checks are green.

## Create the annotated tag after authorization PR merge

Synchronize `main` and `v1.3.0-development`, verify a clean worktree, then run:

```bash
python scripts/create_rc1_annotated_tag.py   --execute   --push   --confirm-target cf9a05b46b9b6f29cd85942f99155f89a49817a7
```

The script refuses any other target and verifies the pushed annotated tag.

## Create the GitHub pre-release

```bash
python scripts/create_rc1_github_prerelease.py   --execute   --confirm-tag v1.3.0-rc1
```

The script requires an authenticated GitHub CLI, an existing remote annotated
tag resolving exactly to `cf9a05b46b9b6f29cd85942f99155f89a49817a7`, and no pre-existing GitHub Release for the
tag.

After creation, retain `artifacts/rc1_github_prerelease_evidence.json` for the
subsequent RC1 evidence-closure and historical-preservation patch.

## Prohibited actions

Do not create or move `v1.3.0`, create a Zenodo version, alter DOI `10.5281/zenodo.21306969`, force
a tag, or mark the RC1 pre-release as the latest stable release.
