## Summary

Adds post-Zenodo historical lifecycle replay compatibility for V0 OSAP v1.3.0. The DOI-finalized successor state is accepted while the pre-Zenodo final-release evidence layer is replayed from frozen commit `7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8` and remains immutable.

## Preservation boundary

No tag, GitHub Release, Zenodo record, archive, DOI, checker version, or theorem claim is mutated.
