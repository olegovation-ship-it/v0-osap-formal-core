from __future__ import annotations

import json
import sys
from pathlib import Path
from textwrap import dedent

BASELINE = "8053709c73045f59358244ec58afc84cfd0deeb6"
HEAD = "dd1b234647a96b31719da0f3c5ad5e91b40144da"
MERGE = "306f80dd36a70211b04f9a64215cc8807cbce709"
MERGED_AT = "2026-07-12T21:09:06Z"
DOI = "10.5281/zenodo.21306969"
STATUS_MACHINE = "ACCEPTED_CI_PASS_MERGED_HISTORICALLY_PRESERVED"
STATUS_HUMAN = "ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED"


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read(path: Path) -> str:
    if not path.is_file():
        fail(f"required file not found: {path}")
    return path.read_text(encoding="utf-8")


def write(path: Path, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body.rstrip() + "\n", encoding="utf-8")


def replace_exact(path: Path, old: str, new: str) -> None:
    body = read(path)
    if new in body:
        return
    if old not in body:
        fail(f"expected source block not found in {path}")
    path.write_text(body.replace(old, new, 1), encoding="utf-8")


def replace_section(path: Path, start: str, end: str, replacement: str) -> None:
    body = read(path)
    a = body.find(start)
    if a < 0:
        fail(f"section start not found in {path}: {start!r}")
    b = body.find(end, a + len(start))
    if b < 0:
        fail(f"section end not found in {path}: {end!r}")
    updated = body[:a] + replacement.rstrip() + "\n\n" + body[b:]
    path.write_text(updated, encoding="utf-8")


def main() -> None:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    if not (root / ".git").exists():
        fail(f"not a Git repository: {root}")

    crosswalk_path = root / "release/v1.3.0/theorem_crosswalk_phase6.json"
    crosswalk = json.loads(read(crosswalk_path))
    if crosswalk.get("baseline_merge_commit") != BASELINE:
        fail("Phase 6 baseline merge commit does not match the expected accepted Phase 5 closure baseline")
    if crosswalk.get("theorem_range") != "T151-T156":
        fail("unexpected Phase 6 theorem range")
    if crosswalk.get("phase6_status") not in {
        "BUILD_READY_CI_PENDING",
        "ACCEPTED_CI_PASS_MERGED",
    }:
        fail(f"unexpected Phase 6 status: {crosswalk.get('phase6_status')!r}")

    # Accepted Phase 6 crosswalk state.
    crosswalk["phase6_status"] = "ACCEPTED_CI_PASS_MERGED"
    crosswalk["closure_evidence"] = "release/v1.3.0/PHASE6_CI_CLOSURE_EVIDENCE.json"
    crosswalk["pull_request"] = 10
    crosswalk["head_commit"] = HEAD
    crosswalk["merge_commit"] = MERGE
    crosswalk["merged_at_utc"] = MERGED_AT
    crosswalk["github_pr_checks"] = 8
    crosswalk["python_tests"] = 15
    crosswalk["historical_preservation"] = "PASS"
    for row in crosswalk["records"]:
        row["parity_status"] = "ACCEPTED_CI_PASS"
    write(crosswalk_path, json.dumps(crosswalk, indent=2, ensure_ascii=False))

    evidence = {
        "artifact_id": "V0_OSAP_v1_3_0_phase6_ci_closure_evidence",
        "artifact_version": "0.1",
        "date": "2026-07-12",
        "status": STATUS_MACHINE,
        "theorem_range": "T151-T156",
        "implementation_baseline_merge_commit": BASELINE,
        "pull_request": {
            "number": 10,
            "title": "V0 OSAP v1.3.0 Phase 6: provenance, vocabulary, diagnostics, evidence, version-lock, and non-interference T151-T156",
            "base": "main",
            "head": "v1.3.0-development",
            "head_sha": HEAD,
            "merge_commit_sha": MERGE,
            "merged_at_utc": MERGED_AT,
            "commits": 3,
            "changed_files": 53,
            "additions": 2141,
            "deletions": 25,
            "pr_check_total": 8,
            "pr_check_result": "PASS",
        },
        "workflow_runs": [
            {
                "name": "Release readiness",
                "run_id": 29208947111,
                "run_number": 64,
                "conclusion": "success",
                "jobs": [
                    "immutable-v1-2-baseline",
                    "v1-3-development-readiness",
                ],
            },
            {
                "name": "Python checker",
                "run_id": 29208947071,
                "run_number": 32,
                "conclusion": "success",
            },
            {
                "name": "Lean 4",
                "run_id": 29208947049,
                "run_number": 32,
                "conclusion": "success",
            },
            {
                "name": "Schema validation",
                "run_id": 29208947046,
                "run_number": 32,
                "conclusion": "success",
            },
            {
                "name": "Coq",
                "run_id": 29208947073,
                "run_number": 32,
                "conclusion": "success",
            },
        ],
        "local_validation": {
            "python_tests": 15,
            "schema_bundle": "PASS",
            "fixture_replay": "PASS",
            "proof_hole_scan": "PASS",
            "phase1_preservation": "PASS",
            "phase2_expansion": "PASS",
            "phase2_ci_closure": "PASS",
            "phase3_expansion": "PASS",
            "phase3_ci_closure": "PASS",
            "phase4_expansion": "PASS",
            "phase4_ci_closure": "PASS",
            "phase5_expansion": "PASS",
            "phase5_ci_closure": "PASS",
            "phase6_expansion": "PASS",
            "lean4_build": "PASS",
            "coq_build": "PASS",
            "diff_check": "PASS",
        },
        "historical_preservation": {
            "baseline_tag": "v1.2.0",
            "baseline_doi": DOI,
            "manifest_verifier_retained": True,
            "closure_verifier_retained": True,
            "phase1_record_retained": True,
            "phase2_record_retained": True,
            "phase3_record_retained": True,
            "phase4_record_retained": True,
            "phase5_record_retained": True,
            "branch_sync_to_merge_commit": True,
            "tag_moved_or_retagged": False,
            "new_doi_created": False,
        },
        "claim_boundary": {
            "v1_3_0_released": False,
            "t156_unconditional_global_conservativity_claimed": False,
            "theorem_completeness_claimed": False,
            "cross_assistant_proof_identity_claimed": False,
            "checker_completeness_claimed": False,
            "unconditional_global_checker_soundness_claimed": False,
            "empirical_or_physical_validation_claimed": False,
        },
    }
    write(
        root / "release/v1.3.0/PHASE6_CI_CLOSURE_EVIDENCE.json",
        json.dumps(evidence, indent=2, ensure_ascii=False),
    )

    report = dedent(f"""\
    # Phase 6 CI Closure and Historical-Preservation Report

    Status: `ACCEPTED / CI_PASS / MERGED / HISTORICALLY_PRESERVED`
    Date: 2026-07-12
    Theorem range: `T151-T156`
    Pull request: `#10`
    Development branch: `v1.3.0-development`
    Implementation baseline merge commit: `{BASELINE}`
    Head commit: `{HEAD}`
    Merge commit: `{MERGE}`
    Merged at: `{MERGED_AT}`
    Immutable baseline: `v1.2.0`
    Baseline DOI: `{DOI}`

    ## Closure result

    The Phase 6 extension-provenance, claim-vocabulary, diagnostic-envelope, evidence-provenance, version-lock, and conditional conservative-extension patch passed the complete pull-request validation matrix and was merged into `main` through PR #10.

    - Pull-request checks: 8/8 PASS.
    - Python regression suite: 15 tests PASS.
    - Schema validation: PASS.
    - Deterministic fixture replay: PASS.
    - Proof-hole scan: PASS.
    - Phase 1 preservation verifier: PASS.
    - Phase 2 expansion verifier: PASS.
    - Phase 2 CI-closure verifier: PASS.
    - Phase 3 expansion verifier: PASS.
    - Phase 3 CI-closure verifier: PASS.
    - Phase 4 expansion verifier: PASS.
    - Phase 4 CI-closure verifier: PASS.
    - Phase 5 expansion verifier: PASS.
    - Phase 5 CI-closure verifier: PASS.
    - Phase 6 expansion verifier: PASS.
    - Lean 4 build: PASS.
    - Coq build: PASS.
    - Release readiness: PASS.

    The accepted scope is the explicit post-v1.1 development-extension cluster T151-T156: extension provenance, declared claim-vocabulary closure, diagnostic-envelope determinism, finite evidence-provenance acyclicity, version-lock coherence, and conditional conservative-extension non-interference.

    ## GitHub evidence

    PR #10 merged three commits into `main`, changing 53 files with 2141 additions and 25 deletions. The implementation head is `{HEAD}` and the merge commit is `{MERGE}`.

    The successful workflow families were Schema validation, Python checker, Lean 4, Coq, and Release readiness. The Release readiness run retained both jobs: the immutable `v1.2.0` baseline audit and the v1.3.0 development audit.

    The recorded successful workflow runs are Release readiness `29208947111`, Python checker `29208947071`, Lean 4 `29208947049`, Schema validation `29208947046`, and Coq `29208947073`.

    ## Historical-preservation audit

    The closure audit confirms:

    1. The tag `v1.2.0` remains immutable and is not moved or retagged.
    2. DOI `{DOI}` remains bound to the archived v1.2.0 software record.
    3. The immutable-baseline readiness job retains `verify_manifest.py` and `verify_closure.py`.
    4. Phase 1, Phase 2, Phase 3, Phase 4, and Phase 5 accepted closure records remain preserved.
    5. The development branch is synchronized from the PR #10 merge baseline before this closure patch is applied.
    6. No new release tag, GitHub Release, or Zenodo version is created by this patch.

    ## Metadata and integrity repairs

    The post-merge closure patch removes stale Phase 6 `BUILD_READY / CI_PENDING` labels, advances the theorem crosswalk to accepted parity status, updates the theorem register, advances the explicit development acceptance boundary to T156, and integrates a dedicated Phase 6 closure verifier into Release readiness.

    The immutable v1.2.0 release claim remains bounded to T121-T126. T151-T156 remain explicit post-v1.1 development-extension identifiers rather than a retroactive amendment of the normative v1.1 reservation.

    ## Boundary

    This report closes Phase 6 only. It is not a v1.3.0 release record, does not move or retag `v1.2.0`, does not create a new DOI, and does not claim checker completeness, unconditional global checker soundness, global extension conservativity, proof-term identity or semantic equivalence among Python, Lean 4, and Coq, or empirical and physical truth of V0. T156 remains conditional on recorded handler-isolation and no-baseline-override premises.
    """)
    write(
        root / "release/v1.3.0/PHASE6_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
        report,
    )

    acceptance = dedent(f"""\
    # Phase 6 Acceptance Gates

    **Scope:** T151-T156
    **Implementation baseline merge commit:** `{BASELINE}`
    **Implementation head commit:** `{HEAD}`
    **Implementation merge commit:** `{MERGE}`
    **Current state:** `{STATUS_HUMAN}`

    ## Gate A — extension provenance

    - [x] T151 records the explicit post-v1.1 extension namespace and record.
    - [x] The normative v1.1 ceiling remains T150.
    - [x] T151-T156 are not described as inherited v1.1 targets.

    ## Gate B — executable parity

    - [x] Six Python rules are implemented.
    - [x] Twelve paired fixtures replay deterministically.
    - [x] JSON Schema validates all new claim forms.
    - [x] Canonical statement hashes match the crosswalk.

    ## Gate C — proof-assistant parity

    - [x] Lean 4 Phase 6 module builds.
    - [x] Coq Phase 6 module builds.
    - [x] Proof-hole scan passes.
    - [x] Backend symbols exist for T151-T156.

    ## Gate D — preservation

    - [x] Phase 1-5 verifiers remain green.
    - [x] `v1.2.0` tag remains immutable.
    - [x] DOI `{DOI}` remains unchanged.
    - [x] No v1.3.0 release is created by this patch.

    ## Gate E — closure evidence

    - [x] PR #10 passed 8/8 checks.
    - [x] Head commit `{HEAD}` merged into `main`.
    - [x] Merge commit `{MERGE}` is recorded.
    - [x] Fifteen Python regression tests passed.
    - [x] Phase 6 closure evidence and the historical-preservation report are machine-verified.

    Phase 6 is accepted, CI-passed, merged, and historically preserved as a v1.3.0 development state. T156 remains conditional on the recorded premises and implementation invariants.
    """)
    write(root / "release/v1.3.0/PHASE6_ACCEPTANCE_GATES.md", acceptance)

    build_spec = dedent(f"""\
    # V0 OSAP v1.3.0 Phase 6 Build Specification and Implementation Patch v0.1

    **Artifact ID:** `V0_OSAP_v1_3_0_PHASE6_T151_T156_EXTENSION`
    **Date:** 2026-07-12
    **Target branch:** `v1.3.0-development`
    **Baseline:** Phase 5 accepted, CI-closed, merged, and historically preserved
    **Baseline merge commit:** `{BASELINE}`
    **Implementation head commit:** `{HEAD}`
    **Implementation merge commit:** `{MERGE}`
    **Build state:** `{STATUS_HUMAN}`
    **Immutable release baseline:** tag `v1.2.0`, DOI `{DOI}`
    **Checker development version:** `0.7.0.dev1`
    **Author:** Dmytro Panasenko, Independent Researcher

    ## 1. Decision summary

    The normative v1.1 theorem-target register ends at T150. Phase 6 does **not** claim inherited v1.1 target status for T151-T156. It introduces an explicit, repository-local v1.3.0 development extension governed by T151 itself. The cluster hardens extension provenance, claim-vocabulary closure, deterministic diagnostic envelopes, finite evidence-provenance paths, compatibility version locks, and conditional conservative non-interference.

    | ID | Canonical theorem target | Executable obligation |
    |---|---|---|
    | T151 | Explicit extension provenance | A post-v1.1 target must name an extension record, namespace, base ceiling T150, and exact range T151-T156. |
    | T152 | Declared claim-vocabulary closure | Every observed Phase 6 claim kind must belong to the declared extension vocabulary. |
    | T153 | Diagnostic envelope determinism | Pinned diagnostic inputs and ruleset produce one canonical diagnostic envelope. |
    | T154 | Evidence provenance acyclicity | An explicit finite provenance path must contain no repeated evidence identifier. |
    | T155 | Version-lock coherence | Current schema, language, checker, and semantic versions must match the declared lock tuple. |
    | T156 | Conservative extension non-interference | Under isolation and no-override premises, baseline-only result hashes remain unchanged. |

    ## 2. Extension-governance boundary

    - T151-T156 are accepted v1.3.0 development-extension identifiers.
    - They do not amend, reinterpret, or enlarge the normative v1.1 reservation T121-T150.
    - They do not alter the immutable v1.2.0 release, tag, DOI, or archived theorem claim.
    - T156 is conditional on explicit extension-handler isolation and absence of baseline-rule override.
    - No global conservativity, checker completeness, proof-term identity, backend equivalence, or empirical claim is made.

    ## 3. Machine-readable extension

    New claim kinds:

    - `theorem_extension_provenance_audit`
    - `claim_vocabulary_closure_audit`
    - `diagnostic_envelope_determinism_audit`
    - `evidence_provenance_acyclicity_audit`
    - `version_lock_coherence_audit`
    - `conservative_extension_audit`

    ## 4. Diagnostics

    - `EXTENSION_PROVENANCE_RECORD_REQUIRED`
    - `EXTENSION_BASE_CEILING_MISMATCH`
    - `EXTENSION_THEOREM_RANGE_MISMATCH`
    - `UNDECLARED_EXTENSION_CLAIM_KIND`
    - `DIAGNOSTIC_REPLAY_INPUTS_NOT_PINNED`
    - `DIAGNOSTIC_ENVELOPE_NONDETERMINISTIC`
    - `EVIDENCE_PROVENANCE_CYCLE`
    - `VERSION_LOCK_RECORD_REQUIRED`
    - `VERSION_LOCK_TUPLE_MISMATCH`
    - `CONSERVATIVE_EXTENSION_PREMISES_UNPROVED`
    - `BASELINE_RESULT_CHANGED_BY_EXTENSION`

    ## 5. Proof-assistant implementation

    `V0OSAP.Phase6` and `Phase6.v` provide bounded formal encodings for T151-T156. T156 consumes a conservative-extension implication and explicit premises; compilation is evidence only for the encoded propositions. It is not a global theorem about arbitrary future code changes.

    ## 6. Fixture and crosswalk contract

    Each theorem target has one positive fixture and one decisive countermodel. The Phase 6 crosswalk records canonical statements, assumptions, conclusions, backend symbols, validator rules, diagnostics, fixture IDs, limitations, and SHA-256 statement hashes. Accepted parity status is `ACCEPTED_CI_PASS`.

    ## 7. Accepted validation matrix

    1. Baseline merge commit `{BASELINE}` preserved: PASS.
    2. PR #10 implementation head `{HEAD}` recorded: PASS.
    3. Merge commit `{MERGE}` recorded: PASS.
    4. Pull-request matrix 8/8: PASS.
    5. Python regression suite, 15 tests: PASS.
    6. Schema bundle and deterministic fixture replay: PASS.
    7. Proof-hole scan: PASS.
    8. Phase 1-5 preservation and closure verifiers: PASS.
    9. Phase 6 expansion verifier: PASS.
    10. Lean 4 and Coq builds: PASS.
    11. Historical-preservation audit: PASS.
    12. Dedicated Phase 6 CI-closure verifier integrated: PASS.

    ## 8. Claim boundary

    This is an accepted v1.3.0 development state, not a v1.3.0 release. It does not move or retag `v1.2.0`, alter DOI `{DOI}`, or make T156 unconditional. The closure evidence is recorded in `PHASE6_CI_CLOSURE_EVIDENCE.json` and `PHASE6_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md`.
    """)
    write(root / "release/v1.3.0/PHASE6_BUILD_SPECIFICATION.md", build_spec)

    implementation = dedent(f"""\
    # Phase 6 Implementation Report

    **Scope:** T151-T156
    **Extension class:** explicit post-v1.1 v1.3.0 development extension
    **Baseline merge commit:** `{BASELINE}`
    **Target branch:** `v1.3.0-development`
    **Implementation head commit:** `{HEAD}`
    **Implementation merge commit:** `{MERGE}`
    **State:** `{STATUS_HUMAN}`
    **Checker version:** `0.7.0.dev1`

    ## Implemented layers

    - executable T151-T156 extension-governance rules and deterministic diagnostics;
    - schema extensions for six Phase 6 claim kinds;
    - twelve paired positive/countermodel fixtures;
    - Lean 4 `V0OSAP.Phase6` formalization;
    - Coq `Phase6.v` formalization;
    - canonical theorem statement-hash crosswalk;
    - Phase 6 static verifier and fixture test;
    - forward-compatible Phase 1-5 verifier version/manifest boundaries;
    - README, changelog, theorem register, status, and Release readiness updates.

    ## Accepted validation matrix

    ```bash
    python -m pip install -e '.[dev]'
    pytest -q
    v0-osap-fc1 schema-bundle
    v0-osap-fc1 fixtures
    python scripts/check_no_proof_holes.py
    python scripts/verify_phase1_alignment.py
    python scripts/verify_phase2_expansion.py
    python scripts/verify_phase2_ci_closure.py
    python scripts/verify_phase3_expansion.py
    python scripts/verify_phase3_ci_closure.py
    python scripts/verify_phase4_expansion.py
    python scripts/verify_phase4_ci_closure.py
    python scripts/verify_phase5_expansion.py
    python scripts/verify_phase5_ci_closure.py
    python scripts/verify_phase6_expansion.py
    python scripts/verify_phase6_ci_closure.py
    (cd lean && lake build)
    (cd coq && make)
    git diff --check
    ```

    PR #10 passed 8/8 GitHub Actions checks. The Python regression suite recorded 15 passing tests. Schema validation, deterministic fixture replay, proof-hole scanning, Phases 1-5 preservation/closure, the Phase 6 verifier, Lean 4, Coq, and both Release readiness jobs passed.

    ## Soundness and conservativity boundary

    T156 is conditional. The executable audit distinguishes unsupported isolation premises (`DEFERRED`) from an actual baseline-result mutation under proved premises (`REJECT`). No global extension conservativity, checker completeness, proof-term identity, or semantic equivalence claim is made.

    ## Historical-preservation result

    The immutable v1.2.0 tag and DOI `{DOI}` remain unchanged. Phase 1-5 accepted records remain preserved. No new release tag, GitHub Release, Zenodo version, or DOI is created by this closure patch.

    ## Release boundary

    Phase 6 is accepted, CI-passed, merged, and historically preserved as a v1.3.0 development state. It is not a v1.3.0 release.
    """)
    write(root / "release/v1.3.0/PHASE6_IMPLEMENTATION_REPORT.md", implementation)

    # README Phase 6 status block.
    readme_block = dedent(f"""\
    ## v1.3.0 development status

    > **PHASE 6 T151-T156 EXTENSION PROVENANCE, VOCABULARY, DIAGNOSTIC, EVIDENCE, VERSION-LOCK, AND CONSERVATIVITY EXPANSION - {STATUS_HUMAN}**

    Phase 6 introduces an explicit post-v1.1 development extension for T151-T156. It adds extension provenance, declared claim-vocabulary closure, diagnostic-envelope determinism, finite evidence-provenance acyclicity, version-lock coherence, and conditional conservative non-interference. Checker version: `0.7.0.dev1`.

    PR #10 passed 8/8 checks and merged head commit
    `{HEAD}` into `main` as
    `{MERGE}`. The regression suite recorded
    15 passing tests, and both Lean 4 and Coq builds passed.

    The implementation was built from the preserved Phase 5 closure baseline
    `{BASELINE}`. The patch includes twelve paired fixtures,
    Lean 4 and Coq Phase 6 modules, and a canonical statement-hash crosswalk.
    This is an accepted v1.3.0 development state, not a v1.3.0 release.
    T151-T156 remain explicit extension IDs beyond the normative v1.1 ceiling T150,
    and T156 remains conditional. See
    `release/v1.3.0/PHASE6_ACCEPTANCE_GATES.md` and
    `release/v1.3.0/PHASE6_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md`.
    """)
    replace_section(
        root / "README.md",
        "## v1.3.0 development status",
        "### Phase 5 closed baseline",
        readme_block,
    )
    readme_path = root / "README.md"
    readme_body = read(readme_path)
    if "python scripts/verify_phase6_ci_closure.py" not in readme_body:
        old = "python scripts/verify_phase5_expansion.py\n"
        new = (
            "python scripts/verify_phase5_expansion.py\n"
            "python scripts/verify_phase5_ci_closure.py\n"
            "python scripts/verify_phase6_expansion.py\n"
            "python scripts/verify_phase6_ci_closure.py\n"
        )
        if old not in readme_body:
            fail("README local-check insertion point not found")
        readme_path.write_text(readme_body.replace(old, new, 1), encoding="utf-8")

    # Changelog Phase 6 top section.
    changelog_block = dedent(f"""\
    ## [Unreleased] — Phase 6 accepted development state

    - Accepted explicit post-v1.1 extension cluster T151-T156 after PR #10 passed 8/8 checks.
    - Recorded implementation baseline `{BASELINE}`, head `{HEAD}`, and merge commit `{MERGE}`.
    - Recorded 15 passing Python tests, schema and deterministic fixture replay PASS, proof-hole PASS, Phase 1-5 preservation/closure PASS, Phase 6 verifier PASS, Lean 4 PASS, and Coq PASS.
    - Advanced T151-T156 theorem-crosswalk parity from `PATCH_READY_CI_PENDING` to `ACCEPTED_CI_PASS`.
    - Added a dedicated Phase 6 CI-closure and historical-preservation verifier.
    - Preserved the immutable v1.2.0 manifest and closure jobs, tag, DOI `{DOI}`, and Phase 1-5 closure history.
    - State: `{STATUS_HUMAN}`.
    """)
    changelog_path = root / "CHANGELOG.md"
    changelog_body = read(changelog_path)
    if "## [Unreleased] — Phase 6 accepted development state" not in changelog_body:
        replace_section(
            changelog_path,
            "## [Unreleased] — Phase 6 build patch",
            "## [Unreleased]",
            changelog_block,
        )

    # Status document.
    status_block = dedent(f"""\
    ## v1.3.0 Phase 6

    - Scope: T151-T156 explicit post-v1.1 development extension.
    - Status: `{STATUS_HUMAN}`.
    - Implementation baseline merge commit: `{BASELINE}`.
    - PR #10: 8/8 checks passed.
    - Head commit: `{HEAD}`.
    - Merge commit: `{MERGE}`.
    - Merged at: `{MERGED_AT}`.
    - Checker development version: `0.7.0.dev1`.
    - Python suite: 15 tests passed.
    - Twelve paired fixtures and Lean 4 / Coq modules are accepted in the development tree.
    - Phase 1 through Phase 5 accepted states remain preserved.
    - T156 remains conditional on extension-handler isolation and no baseline-rule override.
    - No v1.3.0 release, normative-v1.1 amendment, global conservativity, checker-completeness, unconditional global checker-soundness, proof-identity, or empirical claim.
    """)
    replace_section(
        root / "docs/status_and_nonclaims.md",
        "## v1.3.0 Phase 6",
        "## v1.3.0 Phase 5",
        status_block,
    )
    status_path = root / "docs/status_and_nonclaims.md"
    status_body = read(status_path)
    status_body = status_body.replace(
        "- Phase 6 status: `BUILD_READY / CI PENDING`.",
        f"- Phase 6 status: `{STATUS_HUMAN}`.",
    )
    status_body = status_body.replace(
        "- No accepted theorem IDs beyond T150 in the current v1.3.0 development state.",
        "- No accepted theorem IDs beyond T156 in the current v1.3.0 development state.",
    )
    status_path.write_text(status_body, encoding="utf-8")

    # Theorem register metadata and Phase 6 table.
    register_path = root / "docs/theorem_register.md"
    register_body = read(register_path)
    register_body = register_body.replace(
        f"Phase 6 introduces T151-T156 as an explicit post-v1.1 v1.3.0 development extension from baseline merge commit `{BASELINE}`. These IDs are not part of the normative v1.1 reservation. They remain build-ready and CI-pending until dedicated closure.",
        f"Phase 6 adds the accepted explicit post-v1.1 v1.3.0 development-extension cluster T151-T156 from implementation baseline `{BASELINE}`, head `{HEAD}`, and merge commit `{MERGE}`. These IDs are not part of the normative v1.1 reservation and do not alter the immutable v1.2.0 release claim.",
    )
    register_body = register_body.replace(
        "Phase 5 patch status: `BUILD_READY / CI PENDING`.",
        "Phase 5 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.",
    )
    phase5_metadata = "Phase 5 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.\n"
    phase6_metadata = dedent(f"""\
    Phase 6 implementation baseline merge commit: `{BASELINE}`.
    Phase 6 head commit: `{HEAD}`.
    Phase 6 merge commit: `{MERGE}`.
    Phase 6 patch status: `{STATUS_HUMAN}`.
    """)
    if "Phase 6 head commit:" not in register_body:
        register_body = register_body.replace(
            phase5_metadata,
            phase5_metadata + phase6_metadata,
            1,
        )
    register_body = register_body.replace(
        "Phase 6 patch status: `BUILD_READY / CI PENDING`.",
        f"Phase 6 patch status: `{STATUS_HUMAN}`.",
    )
    for theorem_id in range(151, 157):
        register_body = register_body.replace(
            f"| T{theorem_id} |",
            f"| T{theorem_id} |",
        )
    register_body = register_body.replace(" | build ready; CI pending |", " | accepted; CI passed; merged |")
    register_body = register_body.replace(
        "T151-T156 are explicit extension identifiers and do not amend the normative v1.1 T121-T150 reservation. The immutable v1.2.0 tag and DOI remain unchanged.",
        f"T151-T156 are accepted explicit development-extension identifiers and do not amend the normative v1.1 T121-T150 reservation. PR #10 passed 8/8 checks and merged as `{MERGE}`. T156 remains conditional. The immutable v1.2.0 tag and DOI `{DOI}` remain unchanged.",
    )
    register_path.write_text(register_body, encoding="utf-8")

    # Release readiness integration.
    workflow_path = root / ".github/workflows/release-readiness.yml"
    workflow_body = read(workflow_path)
    if "python scripts/verify_phase6_ci_closure.py" not in workflow_body:
        needle = "      - run: python scripts/verify_phase5_ci_closure.py\n"
        if needle not in workflow_body:
            fail("Release readiness Phase 5 closure step not found")
        workflow_body = workflow_body.replace(
            needle,
            needle + "      - run: python scripts/verify_phase6_ci_closure.py\n",
            1,
        )
        workflow_path.write_text(workflow_body, encoding="utf-8")

    verifier = dedent(f"""\
    from __future__ import annotations

    import json
    import re
    from pathlib import Path

    ROOT = Path(__file__).resolve().parents[1]


    def text(path: str) -> str:
        return (ROOT / path).read_text(encoding="utf-8")


    def load(path: str) -> dict:
        return json.loads(text(path))


    evidence = load("release/v1.3.0/PHASE6_CI_CLOSURE_EVIDENCE.json")
    crosswalk = load("release/v1.3.0/theorem_crosswalk_phase6.json")
    report = text("release/v1.3.0/PHASE6_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md")
    acceptance = text("release/v1.3.0/PHASE6_ACCEPTANCE_GATES.md")
    build_spec = text("release/v1.3.0/PHASE6_BUILD_SPECIFICATION.md")
    implementation = text("release/v1.3.0/PHASE6_IMPLEMENTATION_REPORT.md")
    readme = text("README.md")
    changelog = text("CHANGELOG.md")
    status = text("docs/status_and_nonclaims.md")
    register = text("docs/theorem_register.md")
    workflow = text(".github/workflows/release-readiness.yml")

    EXPECTED_IMPLEMENTATION_BASELINE = "{BASELINE}"
    EXPECTED_HEAD = "{HEAD}"
    EXPECTED_MERGE = "{MERGE}"
    EXPECTED_MERGED_AT = "{MERGED_AT}"
    EXPECTED_DOI = "{DOI}"
    EXPECTED_STATUS = "ACCEPTED_CI_PASS_MERGED_HISTORICALLY_PRESERVED"

    assert evidence["status"] == EXPECTED_STATUS
    assert evidence["theorem_range"] == "T151-T156"
    assert evidence["implementation_baseline_merge_commit"] == EXPECTED_IMPLEMENTATION_BASELINE
    assert evidence["pull_request"]["number"] == 10
    assert evidence["pull_request"]["base"] == "main"
    assert evidence["pull_request"]["head"] == "v1.3.0-development"
    assert evidence["pull_request"]["head_sha"] == EXPECTED_HEAD
    assert evidence["pull_request"]["merge_commit_sha"] == EXPECTED_MERGE
    assert evidence["pull_request"]["merged_at_utc"] == EXPECTED_MERGED_AT
    assert evidence["pull_request"]["pr_check_total"] == 8
    assert evidence["pull_request"]["pr_check_result"] == "PASS"
    assert evidence["pull_request"]["commits"] == 3
    assert evidence["pull_request"]["changed_files"] == 53
    assert evidence["pull_request"]["additions"] == 2141
    assert evidence["pull_request"]["deletions"] == 25

    assert evidence["local_validation"]["python_tests"] == 15
    assert all(
        value == "PASS"
        for key, value in evidence["local_validation"].items()
        if key != "python_tests"
    )

    assert len(evidence["workflow_runs"]) == 5
    assert all(run["conclusion"] == "success" for run in evidence["workflow_runs"])
    release_run = next(run for run in evidence["workflow_runs"] if run["name"] == "Release readiness")
    assert release_run["run_id"] == 29208947111
    assert set(release_run["jobs"]) == {{
        "immutable-v1-2-baseline",
        "v1-3-development-readiness",
    }}

    historical = evidence["historical_preservation"]
    assert historical["baseline_tag"] == "v1.2.0"
    assert historical["baseline_doi"] == EXPECTED_DOI
    assert historical["manifest_verifier_retained"] is True
    assert historical["closure_verifier_retained"] is True
    for phase in range(1, 6):
        assert historical[f"phase{{phase}}_record_retained"] is True
    assert historical["branch_sync_to_merge_commit"] is True
    assert historical["tag_moved_or_retagged"] is False
    assert historical["new_doi_created"] is False

    assert crosswalk["baseline_merge_commit"] == EXPECTED_IMPLEMENTATION_BASELINE
    assert crosswalk["phase1_status"] == "ACCEPTED_CI_PASS"
    for phase in range(2, 6):
        assert crosswalk[f"phase{{phase}}_status"] == "ACCEPTED_CI_PASS_MERGED_HISTORICALLY_PRESERVED"
    assert crosswalk["phase6_status"] == "ACCEPTED_CI_PASS_MERGED"
    assert crosswalk["closure_evidence"] == "release/v1.3.0/PHASE6_CI_CLOSURE_EVIDENCE.json"
    assert crosswalk["pull_request"] == 10
    assert crosswalk["head_commit"] == EXPECTED_HEAD
    assert crosswalk["merge_commit"] == EXPECTED_MERGE
    assert crosswalk["merged_at_utc"] == EXPECTED_MERGED_AT
    assert crosswalk["github_pr_checks"] == 8
    assert crosswalk["python_tests"] == 15
    assert crosswalk["historical_preservation"] == "PASS"
    assert [row["theorem_id"] for row in crosswalk["records"]] == [f"T{{i}}" for i in range(151, 157)]
    assert all(row["parity_status"] == "ACCEPTED_CI_PASS" for row in crosswalk["records"])

    for required in [
        "ACCEPTED / CI_PASS / MERGED / HISTORICALLY_PRESERVED",
        EXPECTED_IMPLEMENTATION_BASELINE,
        EXPECTED_HEAD,
        EXPECTED_MERGE,
        EXPECTED_DOI,
        "15 tests PASS",
        "8/8 PASS",
    ]:
        assert required in report

    for document in [acceptance, build_spec, implementation, readme, changelog, status, register]:
        assert EXPECTED_MERGE in document
        assert EXPECTED_DOI in document

    assert "passed 8/8 checks" in readme
    assert "15 passing tests" in readme
    accepted_boundary = re.search(r"No accepted theorem IDs beyond T(\\d+)", status)
    assert accepted_boundary is not None
    assert int(accepted_boundary.group(1)) >= 156
    assert "Phase 6 patch status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`." in register

    for command in [
        "python scripts/verify_manifest.py",
        "python scripts/verify_closure.py",
        "python scripts/verify_phase1_alignment.py",
        "python scripts/verify_phase2_expansion.py",
        "python scripts/verify_phase2_ci_closure.py",
        "python scripts/verify_phase3_expansion.py",
        "python scripts/verify_phase3_ci_closure.py",
        "python scripts/verify_phase4_expansion.py",
        "python scripts/verify_phase4_ci_closure.py",
        "python scripts/verify_phase5_expansion.py",
        "python scripts/verify_phase5_ci_closure.py",
        "python scripts/verify_phase6_expansion.py",
        "python scripts/verify_phase6_ci_closure.py",
    ]:
        assert command in workflow

    for path in [
        "README.md",
        "docs/status_and_nonclaims.md",
        "docs/theorem_register.md",
        "release/v1.3.0/PHASE6_ACCEPTANCE_GATES.md",
        "release/v1.3.0/PHASE6_BUILD_SPECIFICATION.md",
        "release/v1.3.0/PHASE6_IMPLEMENTATION_REPORT.md",
        "release/v1.3.0/theorem_crosswalk_phase6.json",
    ]:
        body = text(path)
        assert "PHASE 6 T151-T156 EXTENSION PROVENANCE, VOCABULARY, DIAGNOSTIC, EVIDENCE, VERSION-LOCK, AND CONSERVATIVITY EXPANSION - BUILD READY / CI PENDING" not in body
        assert '"phase6_status": "BUILD_READY_CI_PENDING"' not in body
        assert '"parity_status": "PATCH_READY_CI_PENDING"' not in body
        assert "Phase 6 remains `BUILD_READY / CI PENDING`" not in body
        assert "Phase 6 patch status: `BUILD_READY / CI PENDING`" not in body

    print(
        "PASS: V0 OSAP v1.3.0 Phase 6 CI closure, merge evidence, "
        "and v1.2.0 historical preservation verified."
    )
    """)
    write(root / "scripts/verify_phase6_ci_closure.py", verifier)

    print("Applied V0 OSAP v1.3.0 Phase 6 CI closure and historical-preservation patch.")
    print(f"Implementation baseline: {BASELINE}")
    print(f"Implementation head: {HEAD}")
    print(f"Implementation merge: {MERGE}")
    print("Recorded state: ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED")
    print("Expected Python tests: 15")
    print("Run the full local validation matrix before committing.")


if __name__ == "__main__":
    main()
