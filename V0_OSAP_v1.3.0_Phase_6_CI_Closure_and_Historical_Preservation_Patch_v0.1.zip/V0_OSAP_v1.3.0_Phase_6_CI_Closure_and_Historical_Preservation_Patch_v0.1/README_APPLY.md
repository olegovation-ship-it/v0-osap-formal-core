# V0 OSAP v1.3.0 Phase 6 CI Closure and Historical-Preservation Patch v0.1

This package records the accepted Phase 6 implementation state for T151-T156 after PR #10 passed 8/8 GitHub Actions checks and merged into `main`.

## Recorded implementation evidence

- accepted implementation baseline: `8053709c73045f59358244ec58afc84cfd0deeb6`
- implementation head: `dd1b234647a96b31719da0f3c5ad5e91b40144da`
- implementation merge commit: `306f80dd36a70211b04f9a64215cc8807cbce709`
- merged at: `2026-07-12T21:09:06Z`
- Python regression suite: 15 tests
- immutable baseline: tag `v1.2.0`
- immutable baseline DOI: `10.5281/zenodo.21306969`

## Apply

Run from a Codespace after synchronizing `v1.3.0-development` with `main`:

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git fetch origin
git pull --ff-only origin v1.3.0-development
git merge --ff-only origin/main
git push origin v1.3.0-development
```

Extract this ZIP and run:

```bash
python /path/to/V0_OSAP_v1.3.0_Phase_6_CI_Closure_and_Historical_Preservation_Patch_v0.1/apply_phase6_ci_closure_patch.py   /workspaces/v0-osap-formal-core
```

## Required local validation

```bash
cd /workspaces/v0-osap-formal-core

python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
python scripts/verify_phase6_expansion.py
python scripts/verify_phase6_ci_closure.py
(cd lean && lake build)
(cd coq && make)
rm -f coq/Makefile.coq.d coq/Makefile.coq.conf
git diff --check
git status --short
```

## Commit and PR

```bash
git add -A
git diff --cached --check
git commit -m "Close V0 OSAP v1.3.0 Phase 6 CI and preserve history"
git push origin v1.3.0-development
```

Open a pull request from `v1.3.0-development` to `main`. The closure patch itself must pass the complete Actions matrix before merge.

## Boundary

This package does not release v1.3.0, move or retag `v1.2.0`, create a new DOI, or make unconditional checker-completeness, global checker-soundness, backend proof-term identity, or empirical/physical claims. T156 remains conditional on the recorded isolation premises and implementation invariants.
