#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${1:-$(git rev-parse --show-toplevel 2>/dev/null || true)}"
EXPECTED_BASE="f494cd9401e2b9ff91d87de77e11f4eb2468726c"
EXPECTED_BRANCH="v1.3.0-development"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

[[ -n "$REPO_ROOT" ]] || fail "Repository root could not be determined."
cd "$REPO_ROOT"

CURRENT_BRANCH="$(git branch --show-current)"
[[ "$CURRENT_BRANCH" == "$EXPECTED_BRANCH" ]] || \
  fail "Expected branch $EXPECTED_BRANCH, found ${CURRENT_BRANCH:-detached HEAD}."

git merge-base --is-ancestor "$EXPECTED_BASE" HEAD || \
  fail "Branch does not contain the Phase 2 merge commit $EXPECTED_BASE."

[[ -z "$(git status --porcelain)" ]] || \
  fail "Working tree is not clean before patch application."

cp -a "$SCRIPT_DIR/payload/." "$REPO_ROOT/"

if [[ -f "$HOME/.elan/env" ]]; then
  # shellcheck disable=SC1090
  source "$HOME/.elan/env"
fi
export PATH="$HOME/.elan/bin:$PATH"

python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
(
  cd lean
  lake build
)
(
  cd coq
  make
)
rm -f coq/.Makefile.coq.d

git diff --check

git add \
  .github/workflows/release-readiness.yml \
  CHANGELOG.md \
  README.md \
  docs/status_and_nonclaims.md \
  docs/theorem_register.md \
  release/v1.3.0/PHASE2_ACCEPTANCE_GATES.md \
  release/v1.3.0/PHASE2_BUILD_SPECIFICATION.md \
  release/v1.3.0/PHASE2_IMPLEMENTATION_REPORT.md \
  release/v1.3.0/PHASE2_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md \
  release/v1.3.0/PHASE2_CI_CLOSURE_EVIDENCE.json \
  release/v1.3.0/theorem_crosswalk_phase2.json \
  scripts/verify_phase2_expansion.py \
  scripts/verify_phase2_ci_closure.py

git diff --cached --check

if git diff --cached --quiet; then
  fail "No closure-patch changes were staged."
fi

if ! git diff --quiet; then
  echo "Unstaged tracked changes remain:" >&2
  git status --short >&2
  fail "Refusing to commit a mixed working tree."
fi

UNTRACKED="$(git ls-files --others --exclude-standard)"
if [[ -n "$UNTRACKED" ]]; then
  echo "Unexpected untracked files remain:" >&2
  printf '%s\n' "$UNTRACKED" >&2
  fail "Refusing to commit with unexpected untracked files."
fi

echo "=== STAGED PHASE 2 CLOSURE CHANGESET ==="
git status --short

git commit -m "Close V0 OSAP v1.3.0 Phase 2 CI and preserve v1.2.0 history"
git push origin "$EXPECTED_BRANCH"

echo
echo "PHASE 2 CI CLOSURE PATCH COMMITTED AND PUSHED"
