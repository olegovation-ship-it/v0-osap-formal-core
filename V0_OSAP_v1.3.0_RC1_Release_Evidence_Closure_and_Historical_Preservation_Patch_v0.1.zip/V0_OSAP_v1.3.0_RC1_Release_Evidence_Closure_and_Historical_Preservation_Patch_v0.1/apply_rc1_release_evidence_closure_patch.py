from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
TEMPLATES = PACKAGE_ROOT / "templates"

REPOSITORY = "olegovation-ship-it/v0-osap-formal-core"
AUDIT_MERGE_COMMIT = "29f9ec108efbb419fd030573b33ef5d30486d2ab"
CLOSURE_MERGE_COMMIT = "cf9a05b46b9b6f29cd85942f99155f89a49817a7"
AUTHORIZATION_MERGE_COMMIT = "cc1148f4c01cec2e2fca05651d02edc18fdc7312"

IMMUTABLE_TAG = "v1.2.0"
IMMUTABLE_TAG_TARGET = "befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3"
IMMUTABLE_DOI = "10.5281/zenodo.21306969"

CANDIDATE_TAG = "v1.3.0-rc1"
FINAL_TAG = "v1.3.0"
EXPECTED_NAME = "V0 OSAP v1.3.0-rc1 — Release Candidate 1"
EXPECTED_URL = (
    "https://github.com/olegovation-ship-it/"
    "v0-osap-formal-core/releases/tag/v1.3.0-rc1"
)
EXPECTED_PUBLISHED_AT = "2026-07-13T18:15:33Z"

MACHINE_STATE = (
    "RC1_RELEASE_EVIDENCE_CLOSED_TAG_CREATED_"
    "PRERELEASE_CREATED_FINAL_RELEASE_NOT_CREATED"
)
HUMAN_STATE = (
    "RC1_RELEASE_EVIDENCE_CLOSED / TAG_CREATED / "
    "PRERELEASE_CREATED / FINAL_RELEASE_NOT_CREATED"
)


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def run(root: Path, *command: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [*command],
        cwd=root,
        text=True,
        capture_output=True,
        check=check,
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8", newline="\n")


def write_json(path: Path, value: object) -> None:
    write_text(path, json.dumps(value, indent=2, ensure_ascii=False))


def replace_block(path: Path, begin: str, end: str, replacement: str) -> None:
    text = path.read_text(encoding="utf-8")
    if begin not in text or end not in text:
        fail(f"marker block not found in {path}")
    prefix, tail = text.split(begin, 1)
    _, suffix = tail.split(end, 1)
    updated = prefix + begin + "\n" + replacement.rstrip() + "\n" + end + suffix
    path.write_text(updated, encoding="utf-8", newline="\n")


def exact_tag_target(root: Path, tag: str) -> str | None:
    result = run(root, "git", "tag", "--list", tag)
    if result.stdout.strip() != tag:
        return None
    return run(root, "git", "rev-list", "-n", "1", tag).stdout.strip() or None


def copy_templates(root: Path) -> None:
    for src in sorted(TEMPLATES.rglob("*")):
        if src.is_dir():
            continue
        rel = src.relative_to(TEMPLATES)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)


def capture_release(root: Path) -> dict:
    artifact = root / "artifacts/rc1_github_prerelease_evidence.json"
    if artifact.is_file():
        payload = json.loads(artifact.read_text(encoding="utf-8"))
        release = payload.get("release")
    else:
        if shutil.which("gh") is None:
            fail("GitHub CLI is unavailable and no local pre-release evidence artifact exists")
        result = run(
            root,
            "gh",
            "release",
            "view",
            CANDIDATE_TAG,
            "--repo",
            REPOSITORY,
            "--json",
            "url,tagName,name,isPrerelease,isDraft,publishedAt",
            check=False,
        )
        if result.returncode != 0:
            fail(result.stderr.strip() or "unable to read GitHub pre-release")
        release = json.loads(result.stdout)

    expected = {
        "isDraft": False,
        "isPrerelease": True,
        "name": EXPECTED_NAME,
        "publishedAt": EXPECTED_PUBLISHED_AT,
        "tagName": CANDIDATE_TAG,
        "url": EXPECTED_URL,
    }
    normalized = {key: release.get(key) for key in expected}
    if normalized != expected:
        fail(
            "GitHub pre-release evidence mismatch:\n"
            + json.dumps({"expected": expected, "observed": normalized}, indent=2)
        )
    return normalized


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()

    for required in [
        "pyproject.toml",
        "README.md",
        "CHANGELOG.md",
        "docs/status_and_nonclaims.md",
        "release/v1.3.0/RC1_RELEASE_CLOSURE_MANIFEST.json",
        "release/v1.3.0/RC1_TAG_AUTHORIZATION_MANIFEST.json",
    ]:
        if not (root / required).is_file():
            fail(f"repository baseline file missing: {required}")

    origin = run(root, "git", "remote", "get-url", "origin", check=False)
    if origin.returncode != 0 or not origin.stdout.strip().removesuffix(".git").endswith(REPOSITORY):
        fail("origin does not identify the expected repository")

    run(root, "git", "fetch", "origin", "--tags")
    for commit in [AUDIT_MERGE_COMMIT, CLOSURE_MERGE_COMMIT, AUTHORIZATION_MERGE_COMMIT]:
        if run(root, "git", "cat-file", "-e", f"{commit}^{{commit}}", check=False).returncode != 0:
            fail(f"required historical commit is unavailable: {commit}")
        if run(
            root, "git", "merge-base", "--is-ancestor", commit, "HEAD", check=False
        ).returncode != 0:
            fail(f"required historical commit is not an ancestor of HEAD: {commit}")

    if exact_tag_target(root, CANDIDATE_TAG) != CLOSURE_MERGE_COMMIT:
        fail("annotated RC1 tag is absent or points to the wrong commit")
    tag_type = run(root, "git", "cat-file", "-t", f"refs/tags/{CANDIDATE_TAG}").stdout.strip()
    if tag_type != "tag":
        fail("v1.3.0-rc1 is not an annotated tag object")
    if exact_tag_target(root, FINAL_TAG) is not None:
        fail("final v1.3.0 tag already exists")
    if exact_tag_target(root, IMMUTABLE_TAG) != IMMUTABLE_TAG_TARGET:
        fail("immutable v1.2.0 tag target changed")

    release = capture_release(root)

    frozen_manifests = {
        "release/v1.3.0/RC1_RELEASE_CLOSURE_MANIFEST.json": sha256_file(
            root / "release/v1.3.0/RC1_RELEASE_CLOSURE_MANIFEST.json"
        ),
        "release/v1.3.0/RC1_TAG_AUTHORIZATION_MANIFEST.json": sha256_file(
            root / "release/v1.3.0/RC1_TAG_AUTHORIZATION_MANIFEST.json"
        ),
    }

    copy_templates(root)

    release_dir = root / "release/v1.3.0"
    evidence = {
        "artifact_id": "V0_OSAP_V1_3_0_RC1_GITHUB_PRERELEASE_EVIDENCE",
        "authorized_target_commit": CLOSURE_MERGE_COMMIT,
        "release": release,
    }
    write_json(release_dir / "RC1_GITHUB_PRERELEASE_EVIDENCE.json", evidence)

    record = {
        "artifact_id": "V0_OSAP_V1_3_0_RC1_RELEASE_EVIDENCE_CLOSURE_RECORD",
        "version": "0.1",
        "date": "2026-07-13",
        "state": MACHINE_STATE,
        "human_state": HUMAN_STATE,
        "repository": REPOSITORY,
        "gate_audit_pr": 12,
        "release_closure_pr": 13,
        "tag_authorization_pr": 14,
        "audit_merge_commit": AUDIT_MERGE_COMMIT,
        "closure_merge_commit": CLOSURE_MERGE_COMMIT,
        "authorization_merge_commit": AUTHORIZATION_MERGE_COMMIT,
        "tag_evidence": {
            "tag_name": CANDIDATE_TAG,
            "tag_kind": "ANNOTATED",
            "target_commit": CLOSURE_MERGE_COMMIT,
            "target_policy": "EXACT_SEPARATELY_AUTHORIZED_CLOSURE_MERGE_COMMIT",
            "local_target_verified": True,
            "remote_publication_observed": True,
        },
        "github_prerelease_evidence": release,
        "frozen_historical_manifests": frozen_manifests,
        "immutable_history": {
            "tag": IMMUTABLE_TAG,
            "target_commit": IMMUTABLE_TAG_TARGET,
            "doi": IMMUTABLE_DOI,
        },
        "candidate_scope": {
            "theorem_range": "T121-T156",
            "record_count": 36,
            "source_crosswalk_count": 6,
            "conditional_theorems": ["T140", "T150", "T156"],
            "checker_version": "0.7.0.dev1",
        },
        "release_actions": {
            "tag_target_authorized": True,
            "rc1_tag_created": True,
            "github_prerelease_created": True,
            "final_tag_created": False,
            "github_final_release_created": False,
            "zenodo_version_created": False,
            "doi_changed": False,
        },
        "claim_boundary": {
            "checker_completeness_claimed": False,
            "unconditional_global_soundness_claimed": False,
            "proof_term_identity_claimed": False,
            "global_conservativity_claimed": False,
            "empirical_or_physical_validation_claimed": False,
            "cosmological_validation_claimed": False,
        },
    }
    write_json(release_dir / "RC1_RELEASE_EVIDENCE_CLOSURE_RECORD.json", record)

    report = f"""# V0 OSAP v1.3.0 RC1 Release Evidence Closure and Historical Preservation Report

## Closure state

`{HUMAN_STATE}`

The exact-target annotated tag `{CANDIDATE_TAG}` has been created and resolves to
`{CLOSURE_MERGE_COMMIT}`. GitHub reports a published, non-draft pre-release:

- name: `{release['name']}`;
- URL: `{release['url']}`;
- published at: `{release['publishedAt']}`;
- `isPrerelease`: `true`;
- `isDraft`: `false`.

## Provenance

- RC1 gate-audit merge: `{AUDIT_MERGE_COMMIT}`;
- RC1 release-closure and tag-preparation merge: `{CLOSURE_MERGE_COMMIT}`;
- RC1 tag-authorization merge: `{AUTHORIZATION_MERGE_COMMIT}`;
- exact authorized tag target: `{CLOSURE_MERGE_COMMIT}`.

## Historical preservation

The prior release-closure and tag-authorization manifests are retained as frozen
historical snapshots and are referenced by SHA-256 from the new evidence-closure
record. Their former pre-creation action ledgers remain unchanged rather than being
retrospectively rewritten.

Historical tag `{IMMUTABLE_TAG}`, target `{IMMUTABLE_TAG_TARGET}`, and DOI
`{IMMUTABLE_DOI}` remain immutable.

## Gate-audit integrity repair

The executable `scripts/verify_rc1_gate_audit.py` is restored. The repository copy
had become empty during the tag-authorization change set, allowing a no-op process
to return success. This patch reinstates the 36-record inventory audit, the 12/12
negative-mutant kill audit, workflow contract checks, deterministic evidence output,
and an explicit regression test preventing another empty-verifier pass.

## Boundary

T140, T150, and T156 remain conditional. The RC1 tag and GitHub pre-release do not
authorize the final tag `{FINAL_TAG}`, a final GitHub Release, a Zenodo version, or
any DOI mutation.

No checker-completeness, unconditional global checker-soundness, proof-term
identity, global conservativity, empirical, physical, or cosmological claim is made.
"""
    write_text(
        release_dir
        / "RC1_RELEASE_EVIDENCE_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
        report,
    )

    gates = f"""# RC1 Release Evidence Closure Acceptance Gates

## G1 — Exact annotated-tag identity

`{CANDIDATE_TAG}` must exist as an annotated tag and peel exactly to
`{CLOSURE_MERGE_COMMIT}`.

## G2 — GitHub pre-release evidence

The GitHub object must have tag `{CANDIDATE_TAG}`, URL `{EXPECTED_URL}`,
publication time `{EXPECTED_PUBLISHED_AT}`, `isPrerelease=true`, and
`isDraft=false`.

## G3 — Frozen historical snapshots

`RC1_RELEASE_CLOSURE_MANIFEST.json` and
`RC1_TAG_AUTHORIZATION_MANIFEST.json` must remain byte-identical to their recorded
SHA-256 values. Historical pre-creation ledgers are not rewritten.

## G4 — Historical v1.2.0 preservation

Tag `{IMMUTABLE_TAG}` must remain pinned to `{IMMUTABLE_TAG_TARGET}` and DOI
`{IMMUTABLE_DOI}` must remain unchanged.

## G5 — Formal-scope and conditionality preservation

The inventory remains T121-T156 with 36 records and 6 source crosswalks. T140,
T150, and T156 remain conditional.

## G6 — Final-release prohibition

Tag `{FINAL_TAG}`, a final GitHub Release, Zenodo publication, and DOI mutation
remain unauthorized and absent.

## G7 — Executable gate-audit integrity

`verify_rc1_gate_audit.py` must contain and execute the inventory, parity, and
negative-mutant audits. An empty or no-op verifier fails regression tests.

## G8 — Validation-only CI

The RC1 closure workflows may verify tags and evidence but must not run tag creation,
GitHub release creation, Zenodo deposition, or DOI mutation commands.
"""
    write_text(
        release_dir / "RC1_RELEASE_EVIDENCE_CLOSURE_ACCEPTANCE_GATES.md",
        gates,
    )

    readme_block = f"""> **V0 OSAP v1.3.0 RC1 RELEASE EVIDENCE CLOSURE AND HISTORICAL PRESERVATION - {HUMAN_STATE}**

PR #14 merged the exact-target tag authorization as
`{AUTHORIZATION_MERGE_COMMIT}`. The annotated tag `{CANDIDATE_TAG}` now exists and
peels exactly to the separately authorized release-closure commit
`{CLOSURE_MERGE_COMMIT}`.

The GitHub object at `{release['url']}` is published as a non-draft pre-release
(`isPrerelease=true`, `isDraft=false`) with publication time
`{release['publishedAt']}`.

This evidence-closure layer records the external tag and pre-release evidence,
freezes the earlier release-closure and authorization manifests by SHA-256, restores
the executable RC1 gate-audit verifier, and adds validation-only CI replay.

Historical tag `{IMMUTABLE_TAG}`, target `{IMMUTABLE_TAG_TARGET}`, and DOI
`{IMMUTABLE_DOI}` remain immutable. T140, T150, and T156 remain conditional. The
final tag `{FINAL_TAG}`, a final GitHub Release, Zenodo publication, and DOI mutation
remain unauthorized.

See
`release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md`
and `release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_ACCEPTANCE_GATES.md`."""
    replace_block(
        root / "README.md",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_END -->",
        readme_block,
    )

    changelog_block = f"""## [Unreleased] - v1.3.0 RC1 release evidence closure and historical preservation

- Recorded annotated tag `{CANDIDATE_TAG}` at exact target `{CLOSURE_MERGE_COMMIT}`.
- Recorded GitHub pre-release `{release['name']}` at `{release['url']}`.
- Recorded publication time `{release['publishedAt']}`, `isPrerelease=true`, and `isDraft=false`.
- Froze the prior release-closure and tag-authorization manifests by SHA-256 without rewriting their historical pre-creation ledgers.
- Restored the executable RC1 gate-audit verifier after detecting that the repository copy was empty.
- Added a regression guard against an empty/no-op gate-audit verifier.
- Added deterministic evidence-closure record, manifest, verifier, tests, and validation-only CI.
- Preserved T140, T150, and T156 conditionality and all global non-claims.
- Preserved immutable tag `{IMMUTABLE_TAG}`, target `{IMMUTABLE_TAG_TARGET}`, and DOI `{IMMUTABLE_DOI}`.
- Created no final `{FINAL_TAG}` tag, final GitHub Release, Zenodo version, or DOI change.
- State: `{HUMAN_STATE}`."""
    replace_block(
        root / "CHANGELOG.md",
        "<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->",
        "<!-- V0_OSAP_RC1_CHANGELOG_END -->",
        changelog_block,
    )

    status_block = f"""## v1.3.0 RC1 release evidence closure and historical preservation

- Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.
- Status: `{HUMAN_STATE}`.
- Gate-audit PR: #12; merge commit: `{AUDIT_MERGE_COMMIT}`.
- Release-closure PR: #13; merge commit and exact tag target: `{CLOSURE_MERGE_COMMIT}`.
- Tag-authorization PR: #14; merge commit: `{AUTHORIZATION_MERGE_COMMIT}`.
- Annotated tag: `{CANDIDATE_TAG}`; exact peeled target: `{CLOSURE_MERGE_COMMIT}`.
- GitHub pre-release: `{release['url']}`.
- Published at: `{release['publishedAt']}`; `isPrerelease=true`; `isDraft=false`.
- Checker development version remains `0.7.0.dev1`.
- Historical tag `{IMMUTABLE_TAG}` remains pinned to `{IMMUTABLE_TAG_TARGET}`.
- Historical DOI remains `{IMMUTABLE_DOI}`.
- T121-T150 remain the normative v1.1 range; T151-T156 remain explicit post-v1.1 extensions.
- T140, T150, and T156 remain conditional.
- The executable RC1 gate-audit verifier is restored and protected by a non-empty regression check.
- The final tag `{FINAL_TAG}`, final GitHub Release, Zenodo version creation, and DOI mutation remain unauthorized.
- No checker-completeness, unconditional global soundness, proof-term identity, global conservativity, empirical, physical, or cosmological claim is made."""
    replace_block(
        root / "docs/status_and_nonclaims.md",
        "<!-- V0_OSAP_RC1_STATUS_BEGIN -->",
        "<!-- V0_OSAP_RC1_STATUS_END -->",
        status_block,
    )

    # Deterministically rebuild current inventory/parity and the restored audit evidence.
    commands = [
        [sys.executable, "scripts/build_rc1_release_inventory.py"],
        [sys.executable, "scripts/verify_rc1_statement_parity.py"],
        [sys.executable, "scripts/verify_rc1_gate_audit.py"],
        [sys.executable, "scripts/verify_rc1_release_closure.py", "--require-tags"],
        [sys.executable, "scripts/verify_rc1_tag_authorization.py", "--require-tags"],
        [sys.executable, "scripts/build_rc1_release_evidence_closure_manifest.py"],
        [sys.executable, "scripts/verify_rc1_release_evidence_closure.py", "--require-tags"],
        [sys.executable, "-m", "pytest", "-q"],
        ["git", "diff", "--check"],
    ]
    for command in commands:
        result = run(root, *command, check=False)
        if result.stdout.strip():
            print(result.stdout.rstrip())
        if result.returncode != 0:
            if result.stderr.strip():
                print(result.stderr.rstrip(), file=sys.stderr)
            fail(f"validation command failed ({result.returncode}): {' '.join(command)}")

    print("PASS: V0 OSAP v1.3.0 RC1 release evidence closure patch applied.")
    print(f"State: {HUMAN_STATE}")
    print("No final v1.3.0 tag, final GitHub Release, Zenodo version, or DOI action was executed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
