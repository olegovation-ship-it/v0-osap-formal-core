# V0_OSAP_v1.3.0_RC1_Release_Evidence_Closure_and_Historical_Preservation_Patch_v0.1

This patch records and verifies the already-created annotated tag `v1.3.0-rc1`
and GitHub non-draft pre-release. It does **not** create a final `v1.3.0` tag,
a final GitHub Release, a Zenodo version, or a DOI change.

## Important integrity repair

The patch restores `scripts/verify_rc1_gate_audit.py`. The repository copy at the
current baseline is empty, so the prior command could return success without
executing the 36-record and 12-mutant audit. The restored verifier and a new
regression test close that false-pass path.

## Apply

From the repository Codespace:

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git pull --ff-only origin v1.3.0-development
git fetch origin --tags

ZIP="V0_OSAP_v1.3.0_RC1_Release_Evidence_Closure_and_Historical_Preservation_Patch_v0.1.zip"
TMP="/tmp/v0-osap-rc1-release-evidence-closure"
rm -rf "$TMP"
mkdir -p "$TMP"
python -m zipfile -e "$ZIP" "$TMP"

APPLY_SCRIPT="$(find "$TMP" -name apply_rc1_release_evidence_closure_patch.py -print -quit)"
test -n "$APPLY_SCRIPT" || { echo "ERROR: apply script not found"; exit 1; }

python "$APPLY_SCRIPT" /workspaces/v0-osap-formal-core
```

The apply script validates the exact tag target, the GitHub pre-release object,
the immutable `v1.2.0` tag/DOI boundary, restored gate audit, historical snapshot
hashes, the new closure manifest, and the Python test suite.

## Full local matrix after application

```bash
cd /workspaces/v0-osap-formal-core

v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py

python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
python scripts/verify_phase6_expansion.py
python scripts/verify_phase6_ci_closure.py

python scripts/verify_rc1_gate_audit.py
python scripts/verify_rc1_release_closure.py --require-tags
python scripts/verify_rc1_tag_authorization.py --require-tags
python scripts/build_rc1_release_evidence_closure_manifest.py
python scripts/verify_rc1_release_evidence_closure.py --require-tags
python -m pytest -q

(cd lean && lake build)
(cd coq && make)

git diff --check
git status --short
```

## Suggested commit

```bash
git add -A
git diff --cached --check
git commit -m "Close V0 OSAP v1.3.0 RC1 release evidence and preserve history"
git push origin v1.3.0-development
```

## Expected state

```text
RC1_RELEASE_EVIDENCE_CLOSED / TAG_CREATED / PRERELEASE_CREATED / FINAL_RELEASE_NOT_CREATED
```
