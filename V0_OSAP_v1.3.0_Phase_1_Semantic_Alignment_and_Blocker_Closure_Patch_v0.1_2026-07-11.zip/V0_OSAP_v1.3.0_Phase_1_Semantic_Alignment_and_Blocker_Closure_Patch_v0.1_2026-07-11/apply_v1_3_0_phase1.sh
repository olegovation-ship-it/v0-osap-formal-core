#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${1:-$PWD}"

cd "$REPO_DIR"
if [[ ! -d .git || ! -f README.md || ! -d checker/v0_osap_fc1 ]]; then
  echo "ERROR: target is not the v0-osap-formal-core repository root." >&2
  exit 2
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo "ERROR: repository has uncommitted changes. Commit or stash them first." >&2
  exit 3
fi
if git rev-parse -q --verify refs/tags/v1.2.0 >/dev/null; then
  TAG_BEFORE="$(git rev-parse refs/tags/v1.2.0)"
else
  echo "ERROR: immutable baseline tag v1.2.0 is missing." >&2
  exit 4
fi

CURRENT_BRANCH="$(git branch --show-current)"
if [[ "$CURRENT_BRANCH" == "main" ]]; then
  if git show-ref --verify --quiet refs/heads/v1.3.0-development; then
    git switch v1.3.0-development
  else
    git switch -c v1.3.0-development
  fi
elif [[ "$CURRENT_BRANCH" != "v1.3.0-development" ]]; then
  echo "WARNING: applying on branch '$CURRENT_BRANCH'; recommended branch is v1.3.0-development." >&2
fi

cp -a "$PATCH_DIR/payload/." "$REPO_DIR/"
chmod +x scripts/verify_phase1_alignment.py

TAG_AFTER="$(git rev-parse refs/tags/v1.2.0)"
if [[ "$TAG_BEFORE" != "$TAG_AFTER" ]]; then
  echo "ERROR: v1.2.0 tag changed unexpectedly." >&2
  exit 5
fi

echo "Patch files installed. Running Python/schema preflight..."
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py

echo
printf 'NEXT:\n  cd lean && lake build\n  cd ../coq && make\n  cd ..\n  git status --short\n  git add -A\n  git commit -m "Apply V0 OSAP v1.3.0 Phase 1 semantic alignment patch"\n  git push -u origin v1.3.0-development\n'
