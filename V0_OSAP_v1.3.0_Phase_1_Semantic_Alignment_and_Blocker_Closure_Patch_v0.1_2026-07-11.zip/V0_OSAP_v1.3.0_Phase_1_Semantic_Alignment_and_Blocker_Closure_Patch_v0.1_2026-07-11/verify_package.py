from pathlib import Path
import json, hashlib
from jsonschema import Draft202012Validator, RefResolver

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / "payload"

# Metaschema checks.
registry_schema = json.loads((PAYLOAD / "schemas/v1.1/registry_state.schema.json").read_text())
fixture_schema = json.loads((ROOT / "support/fixture.schema.json").read_text())
evidence_schema = json.loads((ROOT / "support/evidence_object.schema.json").read_text())
Draft202012Validator.check_schema(registry_schema)
Draft202012Validator.check_schema(fixture_schema)

# Register evidence schema for registry validation.
from referencing import Registry, Resource
reg = Registry().with_resource(evidence_schema["$id"], Resource.from_contents(evidence_schema))
validator = Draft202012Validator(registry_schema, registry=reg)
fixture_validator = Draft202012Validator(fixture_schema)

phase_fixtures = sorted((PAYLOAD / "fixtures").glob("**/*.fixture.json"))
assert phase_fixtures
for descriptor_path in phase_fixtures:
    descriptor = json.loads(descriptor_path.read_text())
    errs = list(fixture_validator.iter_errors(descriptor))
    assert not errs, (descriptor_path, [e.message for e in errs])
    registry_path = descriptor_path.parent / descriptor["input_file"]
    if registry_path.exists():
        instance = json.loads(registry_path.read_text())
        errs = list(validator.iter_errors(instance))
        assert not errs, (registry_path, [e.message for e in errs])

# T122 conditional schema sanity.
empty_all = json.loads((PAYLOAD / "fixtures/positive/empty_all_prerequisites.registry.json").read_text())
assert not list(validator.iter_errors(empty_all))
one_of = json.loads(json.dumps(empty_all))
one_of["prerequisite_families"][0]["mode"] = "one_of"
assert list(validator.iter_errors(one_of)), "empty one_of must be rejected"

# Crosswalk and static verifier presence.
crosswalk = json.loads((PAYLOAD / "release/v1.3.0/theorem_crosswalk_phase1.json").read_text())
assert [r["theorem_id"] for r in crosswalk["records"]] == ["T121","T122","T123","T124","T125","T126"]
assert (PAYLOAD / "scripts/verify_phase1_alignment.py").exists()
print(f"PASS: package contains {len(list(PAYLOAD.rglob('*')))} payload entries and valid Phase 1 fixtures/schemas.")
