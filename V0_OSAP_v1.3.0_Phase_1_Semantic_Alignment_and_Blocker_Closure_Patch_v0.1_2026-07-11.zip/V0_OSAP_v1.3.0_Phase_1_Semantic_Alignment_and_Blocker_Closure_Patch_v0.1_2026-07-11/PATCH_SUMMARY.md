# V0 OSAP v1.3.0 Phase 1 Patch v0.1

This package implements the first semantic-alignment repair stage for the V0 OSAP formal core.

## Closed by the patch, pending repository CI

- T122: schema-compatible empty `all_of` vacuity and exact theorem-target fixture.
- T124: explicit Python residual-obstruction rule and positive/countermodel coverage.
- T125: exact terminal support-exhaustion semantics across Python, Lean 4, and Coq.
- Observer admissibility: separated from T125 and retained as an unnumbered operational rule.

## Important

This package is not a v1.3.0 release. It must be applied to a development branch. The immutable `v1.2.0` tag and DOI `10.5281/zenodo.21306969` remain unchanged.
