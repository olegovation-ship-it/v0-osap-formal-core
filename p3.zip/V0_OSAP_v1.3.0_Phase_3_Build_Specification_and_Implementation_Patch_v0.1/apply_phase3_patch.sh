#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-/workspaces/v0-osap-formal-core}"
BRANCH="v1.3.0-development"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$PACKAGE_DIR/payload"

cd "$REPO_ROOT"
[[ "$(git branch --show-current)" == "$BRANCH" ]] || {
  echo "ERROR: current branch must be $BRANCH" >&2
  exit 2
}
[[ -z "$(git status --porcelain)" ]] || {
  echo "ERROR: working tree is not clean" >&2
  git status --short
  exit 3
}

git pull --ff-only origin "$BRANCH"
cp -a "$PAYLOAD/." "$REPO_ROOT/"

python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py

if [[ -f "$HOME/.elan/env" ]]; then
  # shellcheck disable=SC1090
  source "$HOME/.elan/env"
fi
export PATH="$HOME/.elan/bin:$PATH"
( cd lean && lake build )
( cd coq && make )
rm -f coq/.Makefile.coq.d

git diff --check
git status --short
git diff --stat

git add \
  .github/workflows/release-readiness.yml \
  CHANGELOG.md README.md pyproject.toml \
  checker/v0_osap_fc1/__init__.py checker/v0_osap_fc1/semantic.py \
  coq/_CoqProject coq/theories/Phase3.v coq/theories/Theorems.v \
  docs/status_and_nonclaims.md docs/theorem_register.md \
  fixtures \
  lean/V0OSAP.lean lean/V0OSAP/Phase3.lean lean/V0OSAP/Theorems.lean \
  release/v1.3.0 \
  schemas/v1.1/ERRATA_PHASE3.md schemas/v1.1/registry_state.schema.json \
  scripts/verify_phase1_alignment.py scripts/verify_phase2_expansion.py \
  scripts/verify_phase3_expansion.py \
  tests/test_phase3_expansion.py

git diff --cached --check
git commit -m "Build V0 OSAP v1.3.0 Phase 3 theorem expansion T133-T138"
git push origin "$BRANCH"

echo "PHASE 3 PATCH APPLIED AND PUSHED."
echo "Next: open a draft PR and wait for the complete GitHub Actions matrix."
