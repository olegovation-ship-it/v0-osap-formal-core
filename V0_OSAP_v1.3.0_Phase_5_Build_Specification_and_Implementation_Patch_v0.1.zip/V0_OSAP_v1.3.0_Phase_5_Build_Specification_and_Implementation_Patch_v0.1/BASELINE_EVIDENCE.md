# Phase 5 baseline evidence

Repository: `olegovation-ship-it/v0-osap-formal-core`
Target branch: `v1.3.0-development`
Baseline merge commit: `2a769d7723470cce59df81262b586abf19b9c750`
Baseline relationship: `main` and `v1.3.0-development` identical at package preparation
Phase 4 state: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`
Phase 5 theorem range: `T145-T150`
Immutable release tag: `v1.2.0`
Immutable DOI: `10.5281/zenodo.21306969`

Phase 5 must be applied only after `2a769d7723470cce59df81262b586abf19b9c750` is an ancestor of the development-branch HEAD.
