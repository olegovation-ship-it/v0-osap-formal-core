#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path

EXPECTED_BRANCH = "v1.3.0-development"
EXPECTED_BASELINE = "2a769d7723470cce59df81262b586abf19b9c750"
EXPECTED_DOI = "10.5281/zenodo.21306969"
CHECKER_VERSION = "0.6.0.dev1"
SEMANTIC_VERSION = "FC-1-v1.1+phase5"

STATIC_FILES = [
  "checker/v0_osap_fc1/canonical.py",
  "checker/v0_osap_fc1/phase5.py",
  "coq/theories/Phase5.v",
  "fixtures/negative/t145_wrong_canonical_hash.fixture.json",
  "fixtures/negative/t145_wrong_canonical_hash.registry.json",
  "fixtures/negative/t146_round_trip_mutation.fixture.json",
  "fixtures/negative/t146_round_trip_mutation.registry.json",
  "fixtures/negative/t147_nondeterministic_replay.fixture.json",
  "fixtures/negative/t147_nondeterministic_replay.registry.json",
  "fixtures/negative/t148_hidden_parser_coercion.fixture.json",
  "fixtures/negative/t148_hidden_parser_coercion.registry.json",
  "fixtures/negative/t149_backend_statement_hash_mismatch.fixture.json",
  "fixtures/negative/t149_backend_statement_hash_mismatch.registry.json",
  "fixtures/negative/t150_checker_pass_unsound.fixture.json",
  "fixtures/negative/t150_checker_pass_unsound.registry.json",
  "fixtures/positive/t145_canonical_serialization_determinism.fixture.json",
  "fixtures/positive/t145_canonical_serialization_determinism.registry.json",
  "fixtures/positive/t146_round_trip_identity.fixture.json",
  "fixtures/positive/t146_round_trip_identity.registry.json",
  "fixtures/positive/t147_replay_determinism.fixture.json",
  "fixtures/positive/t147_replay_determinism.registry.json",
  "fixtures/positive/t148_visible_schema_migration.fixture.json",
  "fixtures/positive/t148_visible_schema_migration.registry.json",
  "fixtures/positive/t149_backend_statement_correspondence.fixture.json",
  "fixtures/positive/t149_backend_statement_correspondence.registry.json",
  "fixtures/positive/t150_accepted_fragment_checker_soundness.fixture.json",
  "fixtures/positive/t150_accepted_fragment_checker_soundness.registry.json",
  "lean/V0OSAP/Phase5.lean",
  "release/v1.3.0/PHASE5_ACCEPTANCE_GATES.md",
  "release/v1.3.0/PHASE5_BUILD_SPECIFICATION.md",
  "release/v1.3.0/PHASE5_IMPLEMENTATION_REPORT.md",
  "release/v1.3.0/theorem_crosswalk_phase5.json",
  "schemas/v1.1/ERRATA_PHASE5.md",
  "scripts/verify_phase5_expansion.py",
  "tests/test_phase5_expansion.py"
]


def git(repo: Path, *args: str, check: bool = True) -> str:
    proc = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if check and proc.returncode != 0:
        raise SystemExit(proc.stdout.strip())
    return proc.stdout.strip()


def replace_once(path: Path, old: str, new: str) -> None:
    body = path.read_text(encoding="utf-8")
    if new in body:
        return
    if old not in body:
        raise SystemExit(f"Expected text not found in {path}: {old[:140]!r}")
    path.write_text(body.replace(old, new, 1), encoding="utf-8")


def insert_after(path: Path, anchor: str, insertion: str) -> None:
    body = path.read_text(encoding="utf-8")
    if insertion.strip() in body:
        return
    if anchor not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {anchor[:140]!r}")
    path.write_text(body.replace(anchor, anchor + insertion, 1), encoding="utf-8")


def insert_before(path: Path, anchor: str, insertion: str) -> None:
    body = path.read_text(encoding="utf-8")
    if insertion.strip() in body:
        return
    if anchor not in body:
        raise SystemExit(f"Expected anchor not found in {path}: {anchor[:140]!r}")
    path.write_text(body.replace(anchor, insertion + anchor, 1), encoding="utf-8")


def validate_repository(repo: Path, force: bool) -> None:
    required = [
        "README.md",
        "CHANGELOG.md",
        "docs/status_and_nonclaims.md",
        "docs/theorem_register.md",
        "checker/v0_osap_fc1/semantic.py",
        "checker/v0_osap_fc1/canonical.py",
        "schemas/v1.1/registry_state.schema.json",
        "fixtures/manifest.json",
        "lean/V0OSAP.lean",
        "lean/V0OSAP/Theorems.lean",
        "coq/_CoqProject",
        "coq/theories/Theorems.v",
        "scripts/verify_phase4_expansion.py",
        "scripts/verify_phase4_ci_closure.py",
        ".github/workflows/release-readiness.yml",
        "pyproject.toml",
    ]
    missing = [rel for rel in required if not (repo / rel).exists()]
    if missing:
        raise SystemExit("Incompatible repository; missing: " + ", ".join(missing))

    branch = git(repo, "branch", "--show-current", check=False)
    if branch and branch != EXPECTED_BRANCH and not force:
        raise SystemExit(
            f"Expected branch {EXPECTED_BRANCH!r}, found {branch!r}. "
            "Checkout the development branch or use --force after manual review."
        )

    ancestor = subprocess.run(
        ["git", "merge-base", "--is-ancestor", EXPECTED_BASELINE, "HEAD"],
        cwd=repo,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0
    if not ancestor and not force:
        head = git(repo, "rev-parse", "HEAD", check=False)
        raise SystemExit(
            f"Expected baseline {EXPECTED_BASELINE} to be an ancestor of HEAD {head}. "
            "Synchronize origin/main into the development branch first."
        )

    status = git(repo, "status", "--porcelain", check=False)
    if status and not force:
        raise SystemExit(
            "Working tree is not clean. Commit the staged package and synchronize "
            "the branch before applying, or use --force after manual review."
        )


def copy_static_payload(repo: Path, package: Path) -> None:
    payload = package / "payload"
    for rel in STATIC_FILES:
        src = payload / rel
        if not src.exists():
            raise SystemExit(f"Package payload missing: {rel}")
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def update_semantic(repo: Path) -> None:
    path = repo / "checker/v0_osap_fc1/semantic.py"
    body = path.read_text(encoding="utf-8")

    import_line = "from .phase5 import phase5_diagnostics\n"
    if import_line not in body:
        anchor = (
            "from .diagnostics import STATUS_RANK, Diagnostic, "
            "aggregate_status, sort_diagnostics\n"
        )
        if anchor not in body:
            raise SystemExit("Could not locate semantic import anchor.")
        body = body.replace(anchor, anchor + import_line, 1)

    phase5_block = (
        "    # Phase 5: T145-T150 canonicalization, replay, migration, "
        "correspondence, and soundness audits.\n"
        "    for claim in claims:\n"
        "        if isinstance(claim, dict):\n"
        "            diagnostics.extend(phase5_diagnostics(claim))\n\n"
    )
    if phase5_block.strip() not in body:
        anchor = (
            '    claims_by_id = {c.get("claim_id"): c for c in claims '
            'if isinstance(c, dict) and c.get("claim_id")}\n'
        )
        if anchor not in body:
            raise SystemExit("Could not locate semantic Phase 5 insertion anchor.")
        body = body.replace(anchor, phase5_block + anchor, 1)

    body = body.replace(
        '"implementation_version": "v0-osap-fc1/0.5.0.dev1"',
        '"implementation_version": "v0-osap-fc1/0.6.0.dev1"',
    )
    if '"implementation_version": "v0-osap-fc1/0.6.0.dev1"' not in body:
        raise SystemExit("Could not update semantic implementation version.")

    path.write_text(body, encoding="utf-8")


def update_schema(repo: Path) -> None:
    path = repo / "schemas/v1.1/registry_state.schema.json"
    schema = json.loads(path.read_text(encoding="utf-8"))
    claims = schema["properties"]["claims"]["items"]
    properties = claims["properties"]

    properties.update({
        "canonicalization": {"type": "string"},
        "canonical_payload": {},
        "expected_canonical_sha256": {
            "type": "string",
            "pattern": "^[a-f0-9]{64}$",
        },
        "declared_round_trip_payload": {},
        "proof_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "registry_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "ruleset_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "first_replay_result": {},
        "second_replay_result": {},
        "from_schema_version": {"type": "string"},
        "to_schema_version": {"type": "string"},
        "from_semantic_version": {"type": "string"},
        "to_semantic_version": {"type": "string"},
        "parser_coercion": {"type": "boolean"},
        "migration_record_id": {
            "type": "string",
            "pattern": "^[A-Za-z][A-Za-z0-9_.:-]{0,127}$",
        },
        "theorem_id": {"type": "string", "pattern": "^T[0-9]+$"},
        "canonical_statement_hash": {
            "type": "string",
            "pattern": "^[a-f0-9]{64}$",
        },
        "lean_statement_hash": {
            "type": "string",
            "pattern": "^[a-f0-9]{64}$",
        },
        "coq_statement_hash": {
            "type": "string",
            "pattern": "^[a-f0-9]{64}$",
        },
        "lean_symbol": {"type": "string", "minLength": 1},
        "coq_symbol": {"type": "string", "minLength": 1},
        "accepted_fragment_id": {"type": "string", "minLength": 1},
        "checker_status": {
            "enum": [
                "PASS",
                "OUT-OF-SCOPE",
                "INDETERMINATE",
                "DEFERRED",
                "REJECT",
            ]
        },
        "rule_lemmas_proved": {"type": "boolean"},
        "implementation_invariants_hold": {"type": "boolean"},
        "semantic_obligations_hold": {"type": "boolean"},
    })

    requirements = {
        "canonical_serialization_audit": [
            "claim_id",
            "kind",
            "canonicalization",
            "canonical_payload",
            "expected_canonical_sha256",
        ],
        "round_trip_audit": [
            "claim_id",
            "kind",
            "canonical_payload",
            "declared_round_trip_payload",
        ],
        "replay_determinism_audit": [
            "claim_id",
            "kind",
            "proof_hash",
            "registry_hash",
            "ruleset_hash",
            "first_replay_result",
            "second_replay_result",
        ],
        "schema_migration_audit": [
            "claim_id",
            "kind",
            "from_schema_version",
            "to_schema_version",
            "from_semantic_version",
            "to_semantic_version",
            "parser_coercion",
        ],
        "backend_statement_mapping": [
            "claim_id",
            "kind",
            "theorem_id",
            "canonical_statement_hash",
            "lean_statement_hash",
            "coq_statement_hash",
            "lean_symbol",
            "coq_symbol",
        ],
        "accepted_fragment_soundness_audit": [
            "claim_id",
            "kind",
            "accepted_fragment_id",
            "checker_status",
            "rule_lemmas_proved",
            "implementation_invariants_hold",
            "semantic_obligations_hold",
        ],
    }

    existing_kinds = {
        item.get("if", {})
        .get("properties", {})
        .get("kind", {})
        .get("const")
        for item in claims["allOf"]
    }
    for kind, required in requirements.items():
        if kind not in existing_kinds:
            claims["allOf"].append(
                {
                    "if": {
                        "properties": {"kind": {"const": kind}},
                        "required": ["kind"],
                    },
                    "then": {"required": required},
                }
            )

    path.write_text(json.dumps(schema, indent=2) + "\n", encoding="utf-8")


def update_manifest(repo: Path) -> None:
    path = repo / "fixtures/manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8"))
    manifest["bundle_id"] = "V0_OSAP_v1_3_0_phase5_fixture_corpus"
    manifest["semantic_version"] = SEMANTIC_VERSION

    additions = [
        "positive/t145_canonical_serialization_determinism.fixture.json",
        "negative/t145_wrong_canonical_hash.fixture.json",
        "positive/t146_round_trip_identity.fixture.json",
        "negative/t146_round_trip_mutation.fixture.json",
        "positive/t147_replay_determinism.fixture.json",
        "negative/t147_nondeterministic_replay.fixture.json",
        "positive/t148_visible_schema_migration.fixture.json",
        "negative/t148_hidden_parser_coercion.fixture.json",
        "positive/t149_backend_statement_correspondence.fixture.json",
        "negative/t149_backend_statement_hash_mismatch.fixture.json",
        "positive/t150_accepted_fragment_checker_soundness.fixture.json",
        "negative/t150_checker_pass_unsound.fixture.json",
    ]
    for rel in additions:
        if rel not in manifest["fixtures"]:
            manifest["fixtures"].append(rel)

    manifest["status"] = "PHASE5_T145_T150_PATCH_ORACLE_SET"
    manifest["notes"] = [
        "Phase 1 through Phase 4 accepted mappings are preserved.",
        "T145-T150 each have a positive and decisive countermodel fixture.",
        "Phase 5 remains BUILD_READY / CI_PENDING until local and GitHub Actions closure.",
    ]
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def update_readme(repo: Path) -> None:
    path = repo / "README.md"
    block = f"""> **PHASE 5 T145-T150 CANONICALIZATION, REPLAY, MIGRATION, CORRESPONDENCE, AND SOUNDNESS EXPANSION - BUILD READY / CI PENDING**

Phase 5 adds V0-OSAP-CJ-1 canonical serialization and round-trip audits, pinned replay determinism, explicit schema-migration visibility, backend statement-hash correspondence, and conditional accepted-fragment checker soundness. Checker version: `0.6.0.dev1`.

The patch includes twelve paired fixtures, Lean 4 and Coq Phase 5 modules, and a canonical statement-hash crosswalk. Baseline merge commit:
`{EXPECTED_BASELINE}`.

This is a build-ready v1.3.0 development patch, not an accepted Phase 5 state and not a v1.3.0 release. See `release/v1.3.0/PHASE5_BUILD_SPECIFICATION.md` and `release/v1.3.0/PHASE5_ACCEPTANCE_GATES.md`.

### Phase 4 closed baseline

"""
    insert_after(path, "## v1.3.0 development status\n\n", block)
    insert_after(
        path,
        "python scripts/verify_phase4_ci_closure.py\n",
        "python scripts/verify_phase5_expansion.py\n",
    )


def update_changelog(repo: Path) -> None:
    path = repo / "CHANGELOG.md"
    block = f"""### Phase 5 theorem expansion T145-T150
- Added strict V0-OSAP-CJ-1 canonical serialization, parsing, round-trip, SHA-256, and hash-envelope utilities.
- Added executable replay-determinism, migration-visibility, backend-correspondence, and conditional checker-soundness audits.
- Added twelve paired fixtures and Lean 4 / Coq Phase 5 modules.
- Added a canonical statement-hash theorem crosswalk and Phase 5 verifier.
- Advanced the development checker to `0.6.0.dev1`.
- Baseline merge commit is `{EXPECTED_BASELINE}`.
- Status is `BUILD_READY / CI_PENDING`; no Phase 5 acceptance or v1.3.0 release is claimed.

"""
    insert_after(path, "## [Unreleased]\n\n", block)


def update_status(repo: Path) -> None:
    path = repo / "docs/status_and_nonclaims.md"
    phase_block = f"""## v1.3.0 Phase 5

- Scope: T145-T150.
- Status: `BUILD_READY / CI PENDING`.
- Baseline merge commit: `{EXPECTED_BASELINE}`.
- Checker development version: `0.6.0.dev1`.
- Twelve paired fixtures and Lean 4 / Coq modules are staged.
- Phase 1 through Phase 4 accepted states remain preserved.
- No Phase 5 acceptance, v1.3.0 release, theorem-completeness, proof-identity, checker-completeness, or empirical claim.

"""
    insert_after(path, "# Status and non-claims\n\n", phase_block)

    assertions = """## v1.3.0 Phase 5 assertions

- T145 checks one canonical V0-OSAP-CJ-1 byte/hash representation.
- T146 checks canonical serialize/parse round-trip identity.
- T147 checks canonical replay-result identity under pinned proof, registry, and ruleset hashes.
- T148 rejects hidden parser coercion for schema or semantic-version changes.
- T149 checks canonical statement-hash correspondence between mapped Lean and Coq entries.
- T150 enforces only conditional accepted-fragment soundness under proved rule lemmas and implementation invariants.

"""
    insert_before(path, "## Acceptance state\n", assertions)
    insert_after(
        path,
        "## Acceptance state\n\n",
        "- Phase 5 status: `BUILD_READY / CI PENDING`.\n",
    )
    replace_once(
        path,
        "- No accepted theorem IDs beyond T144 in the current v1.3.0 development state.",
        "- No accepted theorem IDs beyond T144 in the current v1.3.0 development state; T145-T150 are build-ready and CI-pending.",
    )


def update_register(repo: Path) -> None:
    path = repo / "docs/theorem_register.md"
    old = (
        "Phase 4 adds the accepted development cluster T139-T144 under the same "
        "historical-preservation boundary from implementation baseline "
        "`24fc12fa0fce3d2b67ebe684e00ef7bb8537cf30`."
    )
    new = (
        old
        + f" Phase 5 stages the final reserved cluster T145-T150 from baseline "
        f"`{EXPECTED_BASELINE}`."
    )
    replace_once(path, old, new)

    block = f"""

## Phase 5 theorem expansion

Phase 5 baseline merge commit: `{EXPECTED_BASELINE}`.
Phase 5 patch status: `BUILD_READY / CI PENDING`.

| ID | Canonical name | Python | Lean 4 | Coq | Status |
|---|---|---|---|---|---|
| T145 | Canonical serialization determinism | canonical byte/hash audit | T145_canonical_serialization_determinism | T145_canonical_serialization_determinism | build-ready; CI pending |
| T146 | Round-trip identity | canonical round-trip audit | T146_round_trip_identity | T146_round_trip_identity | build-ready; CI pending |
| T147 | Replay determinism | pinned replay-result audit | T147_replay_determinism | T147_replay_determinism | build-ready; CI pending |
| T148 | Schema migration visibility | migration/coercion audit | T148_schema_migration_visibility | T148_schema_migration_visibility | build-ready; CI pending |
| T149 | Backend statement correspondence | canonical statement-hash audit | T149_backend_statement_correspondence | T149_backend_statement_correspondence | build-ready; CI pending |
| T150 | Accepted-fragment checker soundness | conditional soundness audit | T150_accepted_fragment_checker_soundness | T150_accepted_fragment_checker_soundness | build-ready; CI pending |

Phase 5 is not accepted or released until the complete local and GitHub Actions matrix passes. T150 is conditional on proved rule lemmas and implementation invariants. The immutable v1.2.0 tag and DOI `{EXPECTED_DOI}` remain unchanged.
"""
    body = path.read_text(encoding="utf-8")
    if "## Phase 5 theorem expansion" not in body:
        path.write_text((body.rstrip() + block).rstrip() + "\n", encoding="utf-8")


def update_project_files(repo: Path) -> None:
    replace_once(
        repo / "pyproject.toml",
        'version = "0.5.0.dev1"',
        'version = "0.6.0.dev1"',
    )
    insert_after(
        repo / "lean/V0OSAP.lean",
        "import V0OSAP.Phase4\n",
        "import V0OSAP.Phase5\n",
    )
    insert_after(
        repo / "lean/V0OSAP/Theorems.lean",
        "import V0OSAP.Phase4\n",
        "import V0OSAP.Phase5\n",
    )
    insert_after(
        repo / "coq/_CoqProject",
        "theories/Phase4.v\n",
        "theories/Phase5.v\n",
    )

    coq_theorems = repo / "coq/theories/Theorems.v"
    body = coq_theorems.read_text(encoding="utf-8")
    body = body.replace("Phase3 Phase4.", "Phase3 Phase4 Phase5.")
    body = body.replace("T121-T144", "T121-T150")
    if "Phase5." not in body:
        raise SystemExit("Could not update Coq aggregation import.")
    coq_theorems.write_text(body, encoding="utf-8")

    insert_after(
        repo / ".github/workflows/release-readiness.yml",
        "      - run: python scripts/verify_phase4_ci_closure.py\n",
        "      - run: python scripts/verify_phase5_expansion.py\n",
    )


def update_phase4_forward_compatibility(repo: Path) -> None:
    expansion = repo / "scripts/verify_phase4_expansion.py"
    body = expansion.read_text(encoding="utf-8")
    body = body.replace(
        'assert manifest["semantic_version"] == "FC-1-v1.1+phase4"',
        'assert manifest["semantic_version"] in {"FC-1-v1.1+phase4", "FC-1-v1.1+phase5"}',
    )
    body = body.replace(
        'assert manifest["status"] == "PHASE4_T139_T144_PATCH_ORACLE_SET"',
        'assert manifest["status"] in {"PHASE4_T139_T144_PATCH_ORACLE_SET", "PHASE5_T145_T150_PATCH_ORACLE_SET"}',
    )
    body = body.replace(
        'assert \'version = "0.5.0.dev1"\' in project',
        'assert any(version in project for version in (\'version = "0.5.0.dev1"\', \'version = "0.6.0.dev1"\'))',
    )
    body = body.replace(
        'assert \'"implementation_version": "v0-osap-fc1/0.5.0.dev1"\' in semantic',
        'assert any(version in semantic for version in (\'"implementation_version": "v0-osap-fc1/0.5.0.dev1"\', \'"implementation_version": "v0-osap-fc1/0.6.0.dev1"\'))',
    )
    command = '    "python scripts/verify_phase5_expansion.py",\n'
    if command not in body:
        anchor = '    "python scripts/verify_phase4_ci_closure.py",\n'
        if anchor not in body:
            raise SystemExit("Could not update Phase 4 expansion workflow command list.")
        body = body.replace(anchor, anchor + command, 1)
    expansion.write_text(body, encoding="utf-8")

    closure = repo / "scripts/verify_phase4_ci_closure.py"
    body = closure.read_text(encoding="utf-8")
    if "import re\n" not in body:
        body = body.replace("import json\n", "import json\nimport re\n", 1)

    exact = 'assert "No accepted theorem IDs beyond T144" in status\n'
    regex_block = (
        "accepted_boundary = re.search(\n"
        '    r"No accepted theorem IDs beyond T(\\d+)",\n'
        "    status,\n"
        ")\n"
        "assert accepted_boundary is not None\n"
        "assert int(accepted_boundary.group(1)) >= 144\n"
    )
    if exact in body:
        body = body.replace(exact, regex_block, 1)
    elif "accepted_boundary = re.search(" not in body:
        raise SystemExit("Could not make Phase 4 closure boundary forward-compatible.")

    command = '    "python scripts/verify_phase5_expansion.py",\n'
    if command not in body:
        anchor = '    "python scripts/verify_phase4_ci_closure.py",\n'
        if anchor not in body:
            raise SystemExit("Could not update Phase 4 closure workflow command list.")
        body = body.replace(anchor, anchor + command, 1)
    closure.write_text(body, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".", help="Repository root")
    parser.add_argument(
        "--force",
        action="store_true",
        help="Apply despite branch/baseline/worktree mismatch after manual review",
    )
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    package = Path(__file__).resolve().parent

    validate_repository(repo, args.force)
    copy_static_payload(repo, package)
    update_semantic(repo)
    update_schema(repo)
    update_manifest(repo)
    update_readme(repo)
    update_changelog(repo)
    update_status(repo)
    update_register(repo)
    update_project_files(repo)
    update_phase4_forward_compatibility(repo)

    print("Applied V0 OSAP v1.3.0 Phase 5 Build Specification and Implementation Patch.")
    print("Baseline merge commit:", EXPECTED_BASELINE)
    print("Theorem range: T145-T150")
    print("Checker version:", CHECKER_VERSION)
    print("Recorded state: BUILD_READY / CI_PENDING")
    print("Expected pytest total: 114 passed.")
    print("Run the full local validation matrix before committing.")


if __name__ == "__main__":
    main()
