# Apply V0 OSAP v1.3.0 Phase 5 Build Specification and Implementation Patch

## Recorded baseline

- Repository: `olegovation-ship-it/v0-osap-formal-core`
- Branch: `v1.3.0-development`
- Baseline merge commit: `2a769d7723470cce59df81262b586abf19b9c750`
- Phase 4 state: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`
- Phase 5 range: `T145-T150`
- Checker version after application: `0.6.0.dev1`
- Immutable DOI: `10.5281/zenodo.21306969`

## 1. Stage the ZIP

Upload the ZIP directly to `v1.3.0-development` using commit message:

```text
Stage V0 OSAP v1.3.0 Phase 5 build patch
```

## 2. Synchronize the baseline

```bash
cd /workspaces/v0-osap-formal-core
git checkout v1.3.0-development
git fetch origin
git pull --ff-only origin v1.3.0-development
git merge --ff-only origin/main
git push origin v1.3.0-development
git status --short
git log --oneline --decorate -5
```

## 3. Extract and apply

```bash
cd /workspaces/v0-osap-formal-core

rm -rf /tmp/phase5-build
mkdir -p /tmp/phase5-build

python -m zipfile -e       V0_OSAP_v1.3.0_Phase_5_Build_Specification_and_Implementation_Patch_v0.1.zip       /tmp/phase5-build

python       /tmp/phase5-build/V0_OSAP_v1.3.0_Phase_5_Build_Specification_and_Implementation_Patch_v0.1/apply_phase5_patch.py       .
```

Expected result:

```text
Applied V0 OSAP v1.3.0 Phase 5 Build Specification and Implementation Patch.
Baseline merge commit: 2a769d7723470cce59df81262b586abf19b9c750
Theorem range: T145-T150
Checker version: 0.6.0.dev1
Recorded state: BUILD_READY / CI_PENDING
Expected pytest total: 114 passed.
```

## 4. Validate

```bash
python -m pip install -e '.[dev]'

pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures

python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py

export PATH="$HOME/.elan/bin:$PATH"
(cd lean && lake build)
(cd coq && make)

rm -f coq/.Makefile.coq.d coq/Makefile.coq.d

git diff --check
git status --short
```

Expected Python total:

```text
114 passed
```

## 5. Commit and push

```bash
git add -A
git diff --cached --check
git commit -m "Build V0 OSAP v1.3.0 Phase 5 theorem expansion T145-T150"
git push origin v1.3.0-development
```

Do not squash, rebase, force-push, move `v1.2.0`, or alter DOI `10.5281/zenodo.21306969`.

## 6. Draft PR

- base: `main`
- compare: `v1.3.0-development`
- title: use `PR_TITLE.txt`
- description: use `PR_BODY.md`

Keep the PR in Draft until the complete GitHub Actions matrix passes.
