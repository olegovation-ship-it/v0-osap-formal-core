# V0 OSAP v1.3.0 RC1 Release Closure and Tag Preparation Patch v0.1

This package prepares, but does not create, the candidate tag `v1.3.0-rc1`.
It is designed for `olegovation-ship-it/v0-osap-formal-core` on branch
`v1.3.0-development`, after the RC1 gate-audit merge commit
`29f9ec108efbb419fd030573b33ef5d30486d2ab`.

## Patch state

`RC1_CLOSURE_READY / CI_PENDING / TAG_NOT_CREATED`

The patch:

- records PR #12 and the accepted RC1 audit merge baseline;
- installs a release-closure specification and acceptance gates;
- reserves the tag name `v1.3.0-rc1` without creating it;
- pins the immutable `v1.2.0` target and DOI;
- adds a deterministic closure manifest and verifier;
- adds a clean-room replay workflow with Python, Lean 4, and Coq jobs;
- creates a draft annotated-tag message and machine-readable tag-preparation record;
- preserves T140, T150, and T156 conditionality;
- creates no GitHub Release, Zenodo version, DOI change, or final release.

## Apply in the repository

From the repository root:

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git fetch origin
git pull --ff-only origin v1.3.0-development

ZIP="V0_OSAP_v1.3.0_RC1_Release_Closure_and_Tag_Preparation_Patch_v0.1.zip"
TMP="/tmp/v0-osap-rc1-release-closure"
rm -rf "$TMP"
mkdir -p "$TMP"
python -m zipfile -e "$ZIP" "$TMP"

APPLY_SCRIPT="$(find "$TMP" -name apply_rc1_release_closure_tag_preparation_patch.py -print -quit)"
test -n "$APPLY_SCRIPT" || { echo "ERROR: apply script not found"; exit 1; }
python "$APPLY_SCRIPT" /workspaces/v0-osap-formal-core
```

## Local validation

```bash
cd /workspaces/v0-osap-formal-core
python -m pip install -e '.[dev]'
python scripts/build_rc1_release_inventory.py
python scripts/verify_rc1_statement_parity.py
python scripts/verify_rc1_gate_audit.py
python scripts/build_rc1_release_closure_manifest.py
python scripts/verify_rc1_release_closure.py
python -m pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
python scripts/verify_phase6_expansion.py
python scripts/verify_phase6_ci_closure.py
(cd lean && lake build)
(cd coq && make)
git diff --check
git status --short
```

## Commit suggestion

```bash
git add -A
git diff --cached --check
git commit -m "Prepare V0 OSAP v1.3.0 RC1 release closure and tag gate"
git push origin v1.3.0-development
```

Open a draft PR against `main`. Do not create `v1.3.0-rc1` until the closure PR
is green, merged, the post-merge target commit is recorded, and the closure
verifier passes on that exact target.
