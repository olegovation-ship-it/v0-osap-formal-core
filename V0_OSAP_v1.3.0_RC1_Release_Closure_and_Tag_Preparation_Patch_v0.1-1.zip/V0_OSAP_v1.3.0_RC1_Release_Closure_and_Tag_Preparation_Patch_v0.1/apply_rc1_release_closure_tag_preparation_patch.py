from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

AUDIT_MERGE = "29f9ec108efbb419fd030573b33ef5d30486d2ab"
BRANCH = "v1.3.0-development"
CANDIDATE_TAGS = ("v1.3.0-rc1", "v1.3.0")

README_BLOCK = """<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->
> **V0 OSAP v1.3.0 RC1 RELEASE CLOSURE AND TAG PREPARATION - RC1_CLOSURE_READY / CI_PENDING / TAG_NOT_CREATED**

PR #12 completed the gate-audit freeze with ten successful GitHub Actions checks
and merged the T121-T156 RC1 audit corpus as
`29f9ec108efbb419fd030573b33ef5d30486d2ab`.

This patch installs the release-closure gate: deterministic closure-manifest
replay, a full-history clean-room workflow, immutable-tag verification, a
machine-readable tag-preparation record, and a draft annotated-tag message.
The candidate tag name is `v1.3.0-rc1`, but no tag or release is created.

Historical tag `v1.2.0`, target
`befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`, and DOI
`10.5281/zenodo.21306969` remain immutable. T140, T150, and T156 remain
conditional. The exact RC1 tag target remains unresolved until the closure PR
is green, merged, synchronized, and separately authorized.

See `release/v1.3.0/RC1_RELEASE_CLOSURE_AND_TAG_PREPARATION_SPECIFICATION.md` and
`release/v1.3.0/RC1_RELEASE_CLOSURE_ACCEPTANCE_GATES.md`.
<!-- V0_OSAP_RC1_GATE_AUDIT_END -->"""

CHANGELOG_BLOCK = """<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->
## [Unreleased] - v1.3.0 RC1 release closure and tag preparation

- Recorded PR #12 gate-audit merge commit `29f9ec108efbb419fd030573b33ef5d30486d2ab`.
- Preserved the exact T121-T156 / 36-record candidate inventory and six source crosswalks.
- Added deterministic release-closure manifest generation and verification.
- Added a full-history clean-room replay workflow with Python, Lean 4, and Coq jobs.
- Added a machine-readable tag-preparation record and draft annotation for `v1.3.0-rc1`.
- Preserved T140, T150, and T156 conditionality and all global non-claims.
- Preserved immutable tag `v1.2.0`, its target commit, and DOI `10.5281/zenodo.21306969`.
- Created no RC1 tag, final tag, GitHub Release, Zenodo version, or DOI change.
- State: `RC1_CLOSURE_READY / CI_PENDING / TAG_NOT_CREATED`.
<!-- V0_OSAP_RC1_CHANGELOG_END -->"""

STATUS_BLOCK = """<!-- V0_OSAP_RC1_STATUS_BEGIN -->
## v1.3.0 RC1 release closure and tag preparation

- Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.
- Status: `RC1_CLOSURE_READY / CI_PENDING / TAG_NOT_CREATED`.
- Gate-audit PR: #12; merge commit: `29f9ec108efbb419fd030573b33ef5d30486d2ab`.
- Checker development version remains `0.7.0.dev1`.
- Candidate tag name is reserved as `v1.3.0-rc1`; exact target is unresolved.
- Historical tag `v1.2.0` remains pinned to `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`.
- Historical DOI remains `10.5281/zenodo.21306969`.
- T121-T150 remain the normative v1.1 range; T151-T156 remain explicit post-v1.1 extensions.
- T140, T150, and T156 remain conditional.
- No theorem, executable rule, Lean theorem, Coq theorem, checker version, tag, release, Zenodo version, or DOI is added by this patch.
- No checker-completeness, unconditional global soundness, proof-term identity, global conservativity, empirical, physical, or cosmological claim is made.
<!-- V0_OSAP_RC1_STATUS_END -->"""


def run(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run([*args], cwd=root, text=True, capture_output=True, check=check)


def replace_marker_block(path: Path, start: str, end: str, replacement: str) -> None:
    text = path.read_text(encoding="utf-8")
    if text.count(start) != 1 or text.count(end) != 1:
        raise SystemExit(f"ERROR: marker cardinality mismatch in {path}")
    begin = text.index(start)
    finish = text.index(end, begin) + len(end)
    updated = text[:begin] + replacement + text[finish:]
    path.write_text(updated, encoding="utf-8", newline="\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.repository).resolve()
    package_root = Path(__file__).resolve().parent
    payload = package_root / "payload"

    required = [
        root / ".git",
        root / "pyproject.toml",
        root / "release/v1.3.0/RC1_RELEASE_MANIFEST.json",
    ]
    if not all(path.exists() for path in required):
        raise SystemExit("ERROR: target is not the V0 OSAP formal-core repository root")

    branch = run(root, "git", "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    if branch != BRANCH:
        raise SystemExit(f"ERROR: expected branch {BRANCH}, found {branch}")

    ancestor = run(root, "git", "merge-base", "--is-ancestor", AUDIT_MERGE, "HEAD", check=False)
    if ancestor.returncode != 0:
        raise SystemExit(f"ERROR: required audit merge {AUDIT_MERGE} is not an ancestor of HEAD")

    for tag in CANDIDATE_TAGS:
        if run(root, "git", "tag", "--list", tag).stdout.strip():
            raise SystemExit(f"ERROR: release tag already exists: {tag}")

    for source in sorted(payload.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(payload)
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)

    replace_marker_block(
        root / "README.md",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_END -->",
        README_BLOCK,
    )
    replace_marker_block(
        root / "CHANGELOG.md",
        "<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->",
        "<!-- V0_OSAP_RC1_CHANGELOG_END -->",
        CHANGELOG_BLOCK,
    )
    replace_marker_block(
        root / "docs/status_and_nonclaims.md",
        "<!-- V0_OSAP_RC1_STATUS_BEGIN -->",
        "<!-- V0_OSAP_RC1_STATUS_END -->",
        STATUS_BLOCK,
    )

    run(root, sys.executable, "scripts/build_rc1_release_closure_manifest.py")
    verification = run(root, sys.executable, "scripts/verify_rc1_release_closure.py")
    print(verification.stdout.strip())
    print("Applied V0 OSAP v1.3.0 RC1 release-closure and tag-preparation patch v0.1.")
    print(f"Audit merge baseline: {AUDIT_MERGE}")
    print("Recorded state: RC1_CLOSURE_READY / CI_PENDING / TAG_NOT_CREATED")
    print("No tag, GitHub Release, Zenodo version, or DOI action was executed.")
    print("Run the full local validation matrix before committing.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
