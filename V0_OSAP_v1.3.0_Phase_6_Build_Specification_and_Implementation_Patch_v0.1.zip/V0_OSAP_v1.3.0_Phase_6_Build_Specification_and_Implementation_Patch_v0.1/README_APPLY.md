# Apply V0 OSAP v1.3.0 Phase 6 Patch

Package: `V0_OSAP_v1.3.0_Phase_6_Build_Specification_and_Implementation_Patch_v0.1`

## Baseline

- target branch: `v1.3.0-development`
- expected preserved Phase 5 closure merge commit: `8053709c73045f59358244ec58afc84cfd0deeb6`
- build state after application: `BUILD_READY / CI_PENDING`
- checker version: `0.7.0.dev1`
- immutable baseline: tag `v1.2.0`, DOI `10.5281/zenodo.21306969`

## Apply

```bash
python apply_phase6_patch.py /workspaces/v0-osap-formal-core
```

## Validate

```bash
cd /workspaces/v0-osap-formal-core
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
python scripts/verify_phase4_expansion.py
python scripts/verify_phase4_ci_closure.py
python scripts/verify_phase5_expansion.py
python scripts/verify_phase5_ci_closure.py
python scripts/verify_phase6_expansion.py
export PATH="$HOME/.elan/bin:$PATH"
(cd lean && lake build)
(cd coq && make)
rm -f coq/.Makefile.coq.d coq/Makefile.coq.d
git diff --check
git status --short
```

The package intentionally does not create a v1.3.0 release or mark Phase 6 accepted.
