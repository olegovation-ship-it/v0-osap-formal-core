#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
PAYLOAD = PACKAGE_ROOT / "payload"
BASELINE = "8053709c73045f59358244ec58afc84cfd0deeb6"
CHECKER_VERSION = "0.7.0.dev1"

def fail(message: str) -> None:
    raise SystemExit(message)

def read(path: Path) -> str:
    if not path.exists():
        fail(f"Required repository file not found: {path}")
    return path.read_text(encoding="utf-8")

def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")

def replace_once(path: Path, old: str, new: str) -> None:
    text = read(path)
    if new in text:
        return
    if old not in text:
        fail(f"Expected patch anchor not found in {path}: {old[:120]!r}")
    write_text(path, text.replace(old, new, 1))

def insert_after_line(path: Path, needle: str, new_line: str) -> None:
    lines = read(path).splitlines()
    if new_line in lines:
        return
    for i, line in enumerate(lines):
        if needle in line:
            indent = line[:len(line)-len(line.lstrip())]
            lines.insert(i+1, indent + new_line.lstrip())
            write_text(path, "\n".join(lines))
            return
    fail(f"Expected line anchor not found in {path}: {needle}")

def copy_payload(root: Path) -> None:
    for source in PAYLOAD.rglob("*"):
        if source.is_file():
            rel = source.relative_to(PAYLOAD)
            target = root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)

def patch_semantic(root: Path) -> None:
    path = root / "checker/v0_osap_fc1/semantic.py"
    replace_once(
        path,
        "from .phase5 import phase5_diagnostics\n",
        "from .phase5 import phase5_diagnostics\nfrom .phase6 import phase6_diagnostics\n",
    )
    old = """    # Phase 5: T145-T150 canonicalization, replay, migration, correspondence, and soundness audits.
    for claim in claims:
        if isinstance(claim, dict):
            diagnostics.extend(phase5_diagnostics(claim))

"""
    new = old + """    # Phase 6: T151-T156 explicit extension-governance audits.
    for claim in claims:
        if isinstance(claim, dict):
            diagnostics.extend(phase6_diagnostics(claim))

"""
    replace_once(path, old, new)
    text = read(path).replace(
        '"implementation_version": "v0-osap-fc1/0.6.0.dev1"',
        '"implementation_version": "v0-osap-fc1/0.7.0.dev1"',
    )
    write_text(path, text)

def patch_schema(root: Path) -> None:
    path = root / "schemas/v1.1/registry_state.schema.json"
    schema = json.loads(read(path))
    claim_items = schema["properties"]["claims"]["items"]
    props = claim_items["properties"]
    props.update({
        "extension_record_id": {"type": "string"},
        "extension_namespace": {"type": "string"},
        "base_theorem_ceiling": {"type": "integer", "minimum": 0},
        "extension_theorem_ids": {
            "type": "array", "items": {"type": "string", "pattern": "^T[0-9]+$"}, "uniqueItems": True
        },
        "observed_claim_kinds": {
            "type": "array", "items": {"type": "string", "minLength": 1}, "uniqueItems": True
        },
        "declared_claim_kinds": {
            "type": "array", "items": {"type": "string", "minLength": 1}, "uniqueItems": True
        },
        "diagnostic_input_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "diagnostic_ruleset_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "first_diagnostic_envelope": {},
        "second_diagnostic_envelope": {},
        "provenance_path_ids": {
            "type": "array", "items": {"type": "string", "minLength": 1}
        },
        "version_lock_id": {"type": "string"},
        "expected_schema_version": {"type": "string"},
        "expected_language_version": {"type": "string"},
        "expected_checker_version": {"type": "string"},
        "expected_semantic_version": {"type": "string"},
        "current_schema_version": {"type": "string"},
        "current_language_version": {"type": "string"},
        "current_checker_version": {"type": "string"},
        "current_semantic_version": {"type": "string"},
        "baseline_only_input": {"type": "boolean"},
        "extension_handlers_isolated": {"type": "boolean"},
        "baseline_rules_overridden": {"type": "boolean"},
        "baseline_result_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "extended_result_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"}
    })
    existing = {
        item.get("if", {}).get("properties", {}).get("kind", {}).get("const")
        for item in claim_items.get("allOf", [])
    }
    required = {
        "theorem_extension_provenance_audit": [
            "claim_id","kind","extension_record_id","extension_namespace",
            "base_theorem_ceiling","extension_theorem_ids"
        ],
        "claim_vocabulary_closure_audit": [
            "claim_id","kind","observed_claim_kinds","declared_claim_kinds"
        ],
        "diagnostic_envelope_determinism_audit": [
            "claim_id","kind","diagnostic_input_hash","diagnostic_ruleset_hash",
            "first_diagnostic_envelope","second_diagnostic_envelope"
        ],
        "evidence_provenance_acyclicity_audit": [
            "claim_id","kind","provenance_path_ids"
        ],
        "version_lock_coherence_audit": [
            "claim_id","kind","version_lock_id",
            "expected_schema_version","expected_language_version",
            "expected_checker_version","expected_semantic_version",
            "current_schema_version","current_language_version",
            "current_checker_version","current_semantic_version"
        ],
        "conservative_extension_audit": [
            "claim_id","kind","baseline_only_input","extension_handlers_isolated",
            "baseline_rules_overridden","baseline_result_hash","extended_result_hash"
        ]
    }
    for kind, fields in required.items():
        if kind not in existing:
            claim_items.setdefault("allOf", []).append({
                "if": {"properties": {"kind": {"const": kind}}, "required": ["kind"]},
                "then": {"required": fields}
            })
    path.write_text(json.dumps(schema, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def patch_manifest(root: Path) -> None:
    path = root / "fixtures/manifest.json"
    manifest = json.loads(read(path))
    additions = [
        "positive/t151_explicit_extension_provenance.fixture.json",
        "negative/t151_unrecorded_extension.fixture.json",
        "positive/t152_declared_claim_vocabulary_closure.fixture.json",
        "negative/t152_undeclared_claim_kind.fixture.json",
        "positive/t153_diagnostic_envelope_determinism.fixture.json",
        "negative/t153_diagnostic_envelope_mutation.fixture.json",
        "positive/t154_evidence_provenance_acyclicity.fixture.json",
        "negative/t154_evidence_provenance_cycle.fixture.json",
        "positive/t155_version_lock_coherence.fixture.json",
        "negative/t155_version_lock_mismatch.fixture.json",
        "positive/t156_conservative_extension_noninterference.fixture.json",
        "negative/t156_baseline_result_changed.fixture.json",
    ]
    for item in additions:
        if item not in manifest["fixtures"]:
            manifest["fixtures"].append(item)
    manifest["bundle_id"] = "V0_OSAP_v1_3_0_phase6_extension_fixture_corpus"
    manifest["semantic_version"] = "FC-1-v1.1+phase6"
    manifest["status"] = "PHASE6_T151_T156_EXTENSION_PATCH_ORACLE_SET"
    manifest["notes"] = [
        "Phase 1 through Phase 5 accepted mappings are preserved.",
        "T151-T156 are an explicit post-v1.1 v1.3.0 development extension.",
        "T151-T156 each have a positive and decisive countermodel fixture.",
        "Phase 6 remains BUILD_READY / CI_PENDING until local and GitHub Actions closure.",
    ]
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def patch_imports_and_workflow(root: Path) -> None:
    replace_once(
        root / "lean/V0OSAP.lean",
        "import V0OSAP.Phase5\nimport V0OSAP.Theorems",
        "import V0OSAP.Phase5\nimport V0OSAP.Phase6\nimport V0OSAP.Theorems",
    )
    replace_once(
        root / "lean/V0OSAP/Theorems.lean",
        "import V0OSAP.Phase5\n",
        "import V0OSAP.Phase5\nimport V0OSAP.Phase6\n",
    )
    coq_project = root / "coq/_CoqProject"
    lines = read(coq_project).splitlines()
    if "theories/Phase6.v" not in lines:
        lines.append("theories/Phase6.v")
        write_text(coq_project, "\n".join(lines))
    replace_once(
        root / "coq/theories/Theorems.v",
        "From V0OSAP Require Import BasicTypes Registry Guards Prerequisites DLE Residuals Observer Branches Expansion Phase3 Phase4 Phase5.",
        "From V0OSAP Require Import BasicTypes Registry Guards Prerequisites DLE Residuals Observer Branches Expansion Phase3 Phase4 Phase5 Phase6.",
    )
    text = read(root / "coq/theories/Theorems.v").replace(
        "T121-T150 are proved", "T121-T156 are proved"
    )
    write_text(root / "coq/theories/Theorems.v", text)
    insert_after_line(
        root / ".github/workflows/release-readiness.yml",
        "python scripts/verify_phase5_expansion.py",
        "- run: python scripts/verify_phase6_expansion.py",
    )

def patch_versions_and_previous_verifiers(root: Path) -> None:
    pyproject = root / "pyproject.toml"
    text = read(pyproject).replace('version = "0.6.0.dev1"', 'version = "0.7.0.dev1"')
    write_text(pyproject, text)
    for path in sorted((root / "scripts").glob("verify_phase*.py")):
        if path.name == "verify_phase6_expansion.py":
            continue
        text = read(path)

        # Extend version tuples without weakening prior-phase assertions.
        if "v0-osap-fc1/0.7.0.dev1" not in text:
            lines = []
            inserted = False
            for line in text.splitlines():
                lines.append(line)
                if (
                    not inserted
                    and "implementation_version" in line
                    and "v0-osap-fc1/0.6.0.dev1" in line
                    and line.rstrip().endswith(",")
                ):
                    lines.append(line.replace("0.6.0.dev1", "0.7.0.dev1"))
                    inserted = True
            text = "\n".join(lines) + ("\n" if text.endswith("\n") else "")

        old_project = "assert 'version = \"0.6.0.dev1\"' in project"
        new_project = "assert any(version in project for version in ('version = \"0.6.0.dev1\"', 'version = \"0.7.0.dev1\"'))"
        text = text.replace(old_project, new_project)

        single = "'"
        old_semantic = f'assert {single}"implementation_version": "v0-osap-fc1/0.6.0.dev1"{single} in semantic'
        new_semantic = f'assert any(version in semantic for version in ({single}"implementation_version": "v0-osap-fc1/0.6.0.dev1"{single}, {single}"implementation_version": "v0-osap-fc1/0.7.0.dev1"{single}))'
        text = text.replace(old_semantic, new_semantic)

        text = text.replace(
            'assert manifest["semantic_version"] == "FC-1-v1.1+phase5"',
            'assert manifest["semantic_version"] in {"FC-1-v1.1+phase5", "FC-1-v1.1+phase6"}',
        )
        text = text.replace(
            'assert manifest["status"] == "PHASE5_T145_T150_PATCH_ORACLE_SET"',
            'assert manifest["status"] in {"PHASE5_T145_T150_PATCH_ORACLE_SET", "PHASE6_T151_T156_EXTENSION_PATCH_ORACLE_SET"}',
        )
        write_text(path, text)

def patch_docs(root: Path) -> None:
    readme = root / "README.md"
    phase6_section = """## v1.3.0 development status

> **PHASE 6 T151-T156 EXTENSION PROVENANCE, VOCABULARY, DIAGNOSTIC, EVIDENCE, VERSION-LOCK, AND CONSERVATIVITY EXPANSION - BUILD READY / CI PENDING**

Phase 6 introduces an explicit post-v1.1 development extension for T151-T156. It adds extension provenance, declared claim-vocabulary closure, diagnostic-envelope determinism, finite evidence-provenance acyclicity, version-lock coherence, and conditional conservative non-interference. Checker version: `0.7.0.dev1`.

The implementation baseline is Phase 5 closure merge commit `8053709c73045f59358244ec58afc84cfd0deeb6`. The patch includes twelve paired fixtures, Lean 4 and Coq Phase 6 modules, and a canonical statement-hash crosswalk.

This is a build-ready v1.3.0 development patch, not an accepted Phase 6 state and not a v1.3.0 release. T151-T156 are explicit extension IDs beyond the normative v1.1 ceiling T150. See `release/v1.3.0/PHASE6_BUILD_SPECIFICATION.md` and `release/v1.3.0/PHASE6_ACCEPTANCE_GATES.md`.

### Phase 5 closed baseline
""".format(baseline=BASELINE)
    text = read(readme)
    marker = "## v1.3.0 development status\n\n> **PHASE 5"
    if "PHASE 6 T151-T156" not in text:
        if marker not in text:
            fail("README Phase 5 status anchor not found.")
        text = text.replace("## v1.3.0 development status\n\n", phase6_section + "\n", 1)
        text = text.replace("> **PHASE 5", "> **PHASE 5", 1)
        write_text(readme, text)

    status = root / "docs/status_and_nonclaims.md"
    phase6_status = """# Status and non-claims

## v1.3.0 Phase 6

- Scope: T151-T156 explicit post-v1.1 development extension.
- Status: `BUILD_READY / CI_PENDING`.
- Baseline merge commit: `8053709c73045f59358244ec58afc84cfd0deeb6`.
- Checker development version: `0.7.0.dev1`.
- Twelve paired fixtures and Lean 4 / Coq modules are staged in the development tree.
- Phase 1 through Phase 5 accepted states remain preserved.
- T156 remains conditional on extension-handler isolation and no baseline-rule override.
- No v1.3.0 release, normative-v1.1 amendment, global conservativity, checker-completeness, proof-identity, or empirical claim.

""".format(baseline=BASELINE)
    text = read(status)
    if "## v1.3.0 Phase 6" not in text:
        text = text.replace("# Status and non-claims\n\n", phase6_status, 1)
        text = text.replace(
            "- The Phase 2, Phase 3, Phase 4, and Phase 5 closure packages",
            "- The Phase 2, Phase 3, Phase 4, and Phase 5 closure packages",
        )
        assertions = """\n## v1.3.0 Phase 6 assertions\n\n- T151 requires explicit provenance for theorem IDs beyond the normative v1.1 ceiling T150.\n- T152 rejects observed extension claim kinds absent from the declared vocabulary.\n- T153 requires deterministic canonical diagnostic envelopes under pinned inputs.\n- T154 rejects repeated identifiers in explicit finite evidence-provenance paths.\n- T155 requires schema, language, checker, and semantic versions to match a declared lock tuple.\n- T156 preserves baseline-only result hashes only under explicit isolation and no-override premises.\n"""
        text = text.replace("\n## Acceptance state\n", assertions + "\n## Acceptance state\n", 1)
        text = text.replace(
            "- Phase 5 status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.\n",
            "- Phase 6 status: `BUILD_READY / CI PENDING`.\n- Phase 5 status: `ACCEPTED / CI PASS / MERGED / HISTORICALLY PRESERVED`.\n",
            1,
        )
        write_text(status, text)

    register = root / "docs/theorem_register.md"
    text = read(register)
    if "## Phase 6 explicit extension" not in text:
        intro = (
            "Phase 6 introduces T151-T156 as an explicit post-v1.1 v1.3.0 development extension "
            f"from baseline merge commit `{BASELINE}`. These IDs are not part of the normative v1.1 reservation. "
            "They remain build-ready and CI-pending until dedicated closure.\n"
        )
        text = text.replace(
            "Phase 5 adds the accepted final reserved cluster T145-T150",
            "Phase 5 adds the accepted final reserved cluster T145-T150",
            1,
        )
        text = text.replace("\nBaseline evidence commit:", "\n" + intro + "\nBaseline evidence commit:", 1)
        section = """\n## Phase 6 explicit extension\n\nPhase 6 baseline merge commit: `8053709c73045f59358244ec58afc84cfd0deeb6`.\nPhase 6 patch status: `BUILD_READY / CI PENDING`.\n\n| ID | Canonical name | Python | Lean 4 | Coq | Status |\n|---|---|---|---|---|---|\n| T151 | Explicit extension provenance | extension provenance audit | T151_explicit_extension_provenance | T151_explicit_extension_provenance | build ready; CI pending |\n| T152 | Declared claim-vocabulary closure | vocabulary closure audit | T152_declared_claim_vocabulary_closure | T152_declared_claim_vocabulary_closure | build ready; CI pending |\n| T153 | Diagnostic envelope determinism | pinned diagnostic-envelope audit | T153_diagnostic_envelope_determinism | T153_diagnostic_envelope_determinism | build ready; CI pending |\n| T154 | Evidence provenance acyclicity | finite path duplicate audit | T154_evidence_provenance_acyclicity | T154_evidence_provenance_acyclicity | build ready; CI pending |\n| T155 | Version-lock coherence | compatibility tuple audit | T155_version_lock_coherence | T155_version_lock_coherence | build ready; CI pending |\n| T156 | Conservative extension non-interference | conditional baseline-result audit | T156_conservative_extension_noninterference | T156_conservative_extension_noninterference | build ready; CI pending |\n\nT151-T156 are explicit extension identifiers and do not amend the normative v1.1 T121-T150 reservation. The immutable v1.2.0 tag and DOI remain unchanged.\n""".format(baseline=BASELINE)
        text += section
        write_text(register, text)

    changelog = root / "CHANGELOG.md"
    text = read(changelog)
    entry = """## [Unreleased] — Phase 6 build patch

- Added explicit post-v1.1 extension cluster T151-T156.
- Added extension provenance, declared claim-vocabulary closure, deterministic diagnostic envelopes, evidence-provenance acyclicity, version-lock coherence, and conditional conservative non-interference.
- Added twelve paired fixtures, Lean 4 and Coq Phase 6 modules, schema extension note, crosswalk, verifier, and CI integration.
- Baseline merge commit: `8053709c73045f59358244ec58afc84cfd0deeb6`.
- State: `BUILD_READY / CI_PENDING`.
- Preserved immutable tag `v1.2.0` and DOI `10.5281/zenodo.21306969`.

""".format(baseline=BASELINE)
    if "Phase 6 build patch" not in text:
        if text.startswith("#"):
            first_break = text.find("\n\n")
            text = text[:first_break+2] + entry + text[first_break+2:]
        else:
            text = entry + text
        write_text(changelog, text)

def main() -> None:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    for required in [
        "README.md",
        "pyproject.toml",
        "checker/v0_osap_fc1/semantic.py",
        "schemas/v1.1/registry_state.schema.json",
        "fixtures/manifest.json",
    ]:
        if not (root / required).exists():
            fail(f"Not a V0 OSAP formal-core repository root: missing {required}")
    copy_payload(root)
    patch_semantic(root)
    patch_schema(root)
    patch_manifest(root)
    patch_imports_and_workflow(root)
    patch_versions_and_previous_verifiers(root)
    patch_docs(root)
    print("Applied V0 OSAP v1.3.0 Phase 6 Build Specification and Implementation Patch.")
    print(f"Baseline merge commit: {BASELINE}")
    print("Theorem range: T151-T156 (explicit post-v1.1 development extension)")
    print(f"Checker version: {CHECKER_VERSION}")
    print("Recorded state: BUILD_READY / CI_PENDING")
    print("Run the full local validation matrix before committing.")

if __name__ == "__main__":
    main()
