#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

PATCH_ID = "V0_OSAP_v1.3.0_Post_Zenodo_RC1_Inventory_Replay_Compatibility_Repair_v0.1"

FILES = {
    "scripts/build_rc1_release_inventory.py": 'from __future__ import annotations\n\nimport json\nimport subprocess\nfrom pathlib import Path\n\nfrom rc1_audit_lib import audit_inventory\n\nROOT = Path(__file__).resolve().parents[1]\nRELEASE = ROOT / "release/v1.3.0"\nHISTORICAL_SNAPSHOT = "7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8"\n\nFROZEN_OUTPUTS = (\n    "release/v1.3.0/RC1_THEOREM_INVENTORY.json",\n    "release/v1.3.0/RC1_RELEASE_MANIFEST.json",\n)\n\n\ndef run(*args: str, check: bool = True) -> subprocess.CompletedProcess[bytes]:\n    return subprocess.run(\n        list(args),\n        cwd=ROOT,\n        check=check,\n        capture_output=True,\n    )\n\n\ndef historical_blob(rel_path: str) -> bytes:\n    return run("git", "show", f"{HISTORICAL_SNAPSHOT}:{rel_path}").stdout\n\n\ndef main() -> int:\n    if run(\n        "git",\n        "merge-base",\n        "--is-ancestor",\n        HISTORICAL_SNAPSHOT,\n        "HEAD",\n        check=False,\n    ).returncode != 0:\n        raise SystemExit(\n            "ERROR: frozen RC1 replay snapshot is not an ancestor of HEAD: "\n            + HISTORICAL_SNAPSHOT\n        )\n\n    blobs = {rel: historical_blob(rel) for rel in FROZEN_OUTPUTS}\n\n    inventory = json.loads(\n        blobs["release/v1.3.0/RC1_THEOREM_INVENTORY.json"].decode("utf-8")\n    )\n    manifest = json.loads(\n        blobs["release/v1.3.0/RC1_RELEASE_MANIFEST.json"].decode("utf-8")\n    )\n\n    diagnostics = audit_inventory(inventory)\n    if diagnostics:\n        raise SystemExit(\n            "ERROR: frozen RC1 inventory failed structural audit: "\n            + repr(diagnostics)\n        )\n\n    if inventory.get("record_count") != 36:\n        raise SystemExit("ERROR: frozen RC1 inventory record count is not 36")\n    if inventory.get("theorem_range") != "T121-T156":\n        raise SystemExit("ERROR: frozen RC1 theorem range mismatch")\n    if manifest.get("artifact_id") != "V0_OSAP_V1_3_0_RC1_RELEASE_MANIFEST":\n        raise SystemExit("ERROR: frozen RC1 manifest artifact id mismatch")\n    if manifest.get("theorem_inventory_sha256") != inventory.get(\n        "inventory_sha256"\n    ):\n        raise SystemExit("ERROR: frozen RC1 inventory/manifest hash mismatch")\n\n    for rel, blob in blobs.items():\n        path = ROOT / rel\n        path.parent.mkdir(parents=True, exist_ok=True)\n        path.write_bytes(blob)\n\n    print(\n        "PASS: historical RC1 theorem inventory and release manifest replayed "\n        f"byte-for-byte from {HISTORICAL_SNAPSHOT}."\n    )\n    return 0\n\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n',
    ".github/workflows/rc1-gate-audit.yml": 'name: RC1 gate audit\n\non:\n  push:\n    branches: [main, v1.3.0-development]\n  pull_request:\n  workflow_dispatch:\n\npermissions:\n  contents: read\n\njobs:\n  rc1-gate-audit:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n        with:\n          fetch-depth: 0\n      - uses: actions/setup-python@v5\n        with:\n          python-version: "3.12"\n          cache: pip\n      - run: python -m pip install --upgrade pip\n      - run: python -m pip install -e \'.[dev]\'\n      - run: python scripts/build_rc1_release_inventory.py\n      - run: python scripts/verify_rc1_statement_parity.py\n      - run: python scripts/verify_rc1_gate_audit.py\n      - run: python -m pytest -q\n      - name: Verify generated inventory is committed and deterministic\n        run: git diff --exit-code -- release/v1.3.0/RC1_THEOREM_INVENTORY.json release/v1.3.0/RC1_RELEASE_MANIFEST.json release/v1.3.0/RC1_STATEMENT_PARITY_EVIDENCE.json release/v1.3.0/RC1_GATE_AUDIT_EVIDENCE.json\n',
    "tests/test_rc1_historical_inventory_replay_compatibility.py": 'from __future__ import annotations\n\nfrom pathlib import Path\n\nROOT = Path(__file__).resolve().parents[1]\nSNAPSHOT = "7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8"\n\n\ndef test_rc1_inventory_builder_is_historical_replay() -> None:\n    text = (ROOT / "scripts/build_rc1_release_inventory.py").read_text(\n        encoding="utf-8"\n    )\n    assert SNAPSHOT in text\n    assert "historical_blob" in text\n    assert "FROZEN_OUTPUTS" in text\n    assert "write_bytes" in text\n\n\ndef test_rc1_gate_audit_checkout_has_full_history() -> None:\n    text = (ROOT / ".github/workflows/rc1-gate-audit.yml").read_text(\n        encoding="utf-8"\n    )\n    assert "fetch-depth: 0" in text\n',
    "release/v1.3.0/V1_3_0_POST_ZENODO_RC1_INVENTORY_REPLAY_COMPATIBILITY_REPAIR_REPORT.md": '# V0 OSAP v1.3.0 Post-Zenodo RC1 Inventory Replay Compatibility Repair v0.1\n\n## Purpose\n\nRepair the two remaining legacy CI failures after DOI finalization:\n\n- `RC1 gate audit / rc1-gate-audit`;\n- `RC1 release closure replay / clean-room-python-replay`.\n\n## Root cause\n\nThe historical RC1 builder still regenerated `RC1_RELEASE_MANIFEST.json` from the current working tree. Post-release compatibility changes therefore altered hashes of current verifier/workflow files, while the committed RC1 manifest correctly remained frozen.\n\n## Repair\n\n- `scripts/build_rc1_release_inventory.py` becomes a byte-for-byte historical replay of:\n  - `RC1_THEOREM_INVENTORY.json`;\n  - `RC1_RELEASE_MANIFEST.json`.\n- Frozen source snapshot: `7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8`.\n- `.github/workflows/rc1-gate-audit.yml` now checks out full history (`fetch-depth: 0`).\n- A regression test verifies both invariants.\n\n## Preservation boundary\n\nNo theorem record, stable tag, RC1 tag, GitHub Release, Zenodo record, archive, DOI, embedded checker version, or conditional theorem status is changed.\n',
    "release/v1.3.0/V1_3_0_POST_ZENODO_RC1_INVENTORY_REPLAY_COMPATIBILITY_REPAIR_ACCEPTANCE_GATES.md": '# Acceptance gates\n\n- [ ] historical RC1 inventory/manifest replay prints PASS;\n- [ ] `git diff --exit-code` for RC1 inventory and manifest passes;\n- [ ] RC1 statement parity passes;\n- [ ] RC1 gate audit passes;\n- [ ] RC1 release closure replay passes;\n- [ ] post-Zenodo historical lifecycle replay passes;\n- [ ] Zenodo publication-evidence closure verifier passes;\n- [ ] full Python test suite passes;\n- [ ] `git diff --check` passes;\n- [ ] stable tag and both DOIs remain unchanged.\n',
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    required = [
        root / "scripts/build_rc1_release_inventory.py",
        root / ".github/workflows/rc1-gate-audit.yml",
        root / "release/v1.3.0/RC1_THEOREM_INVENTORY.json",
        root / "release/v1.3.0/RC1_RELEASE_MANIFEST.json",
    ]
    missing = [str(path.relative_to(root)) for path in required if not path.is_file()]
    if missing:
        raise SystemExit("ERROR: repository preflight failed: " + ", ".join(missing))

    backup = root / ".patch_backups" / PATCH_ID
    backup.mkdir(parents=True, exist_ok=True)

    for rel, content in FILES.items():
        path = root / rel
        if path.exists():
            target = backup / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")

    print(f"PASS: {PATCH_ID} applied.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
