## Summary

Adds post-Zenodo historical lifecycle replay compatibility and repairs the two remaining legacy RC1 replay workflows.

## Compatibility repairs

- pre-Zenodo final-release evidence is replayed from frozen commit `7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8`;
- RC1 theorem inventory and release manifest are replayed byte-for-byte from the same frozen snapshot;
- RC1 gate-audit checkout now provides full Git history;
- current DOI-finalized state remains authoritative;
- regression tests and validation-only replay workflows are included.

## Preservation boundary

No tag, GitHub Release, Zenodo record, archive, DOI, checker version, theorem record, or theorem claim is mutated. T140, T150, and T156 remain conditional.
