# Apply V0 OSAP v1.3.0 Zenodo Publication Evidence Closure Patch

This patch is anchored to the merged PR #17 final-release evidence baseline
`7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8`.

It records the already published Zenodo v1.3.0 software version and finalizes
the repository citation surface around DOI `10.5281/zenodo.21346728`.

## Codespaces commands

Run from the repository root after uploading this ZIP to
`v1.3.0-development`:

```bash
git switch v1.3.0-development
git pull --ff-only origin v1.3.0-development
git fetch --force origin --tags

ZIP="V0_OSAP_v1.3.0_Zenodo_Publication_Evidence_Closure_and_DOI_Finalization_Patch_v0.1.zip"
TMP="/tmp/v0-osap-v1.3.0-zenodo-evidence-closure"

rm -rf "$TMP"
mkdir -p "$TMP"
python -m zipfile -e "$ZIP" "$TMP"

APPLY_SCRIPT="$(find "$TMP" -name apply_v1_3_0_zenodo_publication_evidence_closure_patch.py -print -quit)"
test -n "$APPLY_SCRIPT" || { echo "ERROR: apply script not found"; exit 1; }

python "$APPLY_SCRIPT" /workspaces/v0-osap-formal-core

python scripts/build_v1_3_0_zenodo_publication_evidence_closure_manifest.py
python scripts/verify_v1_3_0_zenodo_publication_evidence_closure.py --require-tags
python -m pytest -q
git diff --check
git status --short
```

Then stage and commit:

```bash
git add \
  .github/workflows/v1-3-0-zenodo-publication-evidence-closure.yml \
  artifacts/v1_3_0_zenodo_publication_evidence.json \
  release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE.json \
  release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_ACCEPTANCE_GATES.md \
  release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_AND_DOI_FINALIZATION_REPORT.md \
  release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_MANIFEST.json \
  release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_RECORD.json \
  scripts/v1_3_0_zenodo_publication_evidence_closure_lib.py \
  scripts/build_v1_3_0_zenodo_publication_evidence_closure_manifest.py \
  scripts/verify_v1_3_0_zenodo_publication_evidence_closure.py \
  tests/test_v1_3_0_zenodo_publication_evidence_closure.py \
  README.md CHANGELOG.md CITATION.cff docs/status_and_nonclaims.md

git diff --cached --check
git commit -m "Close V0 OSAP v1.3.0 Zenodo publication evidence and finalize DOI"
git push origin v1.3.0-development
```

## Pull request title

```text
V0 OSAP v1.3.0: Zenodo publication evidence closure and DOI finalization
```

## Pull request state

Create it as a **Draft pull request**, wait for all checks, then mark it ready
for review and merge only after the full matrix is green.

## Preservation boundary

The patch performs no Zenodo upload or edit. It creates no tag or GitHub
Release. It does not change the archived software ZIP or historical v1.2.0 DOI.
