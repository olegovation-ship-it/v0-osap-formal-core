from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

PATCH_ROOT = Path(__file__).resolve().parent
PAYLOAD = PATCH_ROOT / "payload"
BASE_MERGE = "7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8"
FINAL_TAG = "v1.3.0"
FINAL_TARGET = "13bf095688bcabd5b090f188e9bd28a16237edeb"
OLD_TAG = "v1.2.0"
OLD_TARGET = "befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3"

README_BLOCK = '<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->\n> **V0 OSAP v1.3.0 ZENODO PUBLICATION EVIDENCE CLOSURE AND DOI FINALIZATION - ZENODO_PUBLICATION_EVIDENCE_CLOSED / DOI_FINALIZED / STABLE_TAG_CREATED / FINAL_GITHUB_RELEASE_CREATED / ZENODO_PUBLISHED**\n\nCandidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.\n\nPR #17 merged the final GitHub release-evidence closure at `7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8`. The stable annotated tag `v1.3.0` remains pinned exactly to `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n\nThe published Zenodo record is [V0 OSAP Formal Core v1.3.0 — T121–T156 Stable Release](https://zenodo.org/records/21346728), version `v1.3.0`, resource type `Software`, access `Open`, with version DOI [`10.5281/zenodo.21346728`](https://doi.org/10.5281/zenodo.21346728).\n\nThe archived software file is `olegovation-ship-it/v0-osap-formal-core-v1.3.0.zip`, linked to GitHub release `v1.3.0`. The record title has been normalized to the v1.3.0 T121-T156 stable-release title.\n\nThis patch closes publication evidence, freezes predecessor release artifacts by SHA-256, and finalizes repository citation surfaces. It does not move either release tag, rebuild the archived object, republish Zenodo, or mutate the historical v1.2.0 DOI.\n\nThe embedded checker component remains `0.7.0.dev1` exactly as audited. Historical tag `v1.2.0`, target `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`, and DOI `10.5281/zenodo.21306969` remain immutable. T140, T150, and T156 remain conditional.\n\nSee `release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_AND_DOI_FINALIZATION_REPORT.md` and `release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_ACCEPTANCE_GATES.md`.\n<!-- V0_OSAP_RC1_GATE_AUDIT_END -->'
STATUS_BLOCK = '<!-- V0_OSAP_RC1_STATUS_BEGIN -->\n## v1.3.0 Zenodo publication evidence closure and DOI finalization\n\n- Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.\n- Status: `ZENODO_PUBLICATION_EVIDENCE_CLOSED / DOI_FINALIZED / STABLE_TAG_CREATED / FINAL_GITHUB_RELEASE_CREATED / ZENODO_PUBLISHED`.\n- Final GitHub release-evidence closure PR: #17; merge commit: `7b38ddd6cb9bcfdc7c5713ba73a2c45d6513fbb8`.\n- Stable annotated tag `v1.3.0` remains pinned to `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n- Zenodo record: `https://zenodo.org/records/21346728`.\n- Zenodo title: `V0 OSAP Formal Core v1.3.0 — T121–T156 Stable Release`.\n- Zenodo version DOI: `10.5281/zenodo.21346728`.\n- Publication date shown by Zenodo: `2026-07-13`.\n- Resource type/access: `Software` / `Open`.\n- Archived file: `olegovation-ship-it/v0-osap-formal-core-v1.3.0.zip`.\n- Linked GitHub release: `v1.3.0`.\n- Embedded checker component remains `0.7.0.dev1` exactly as audited.\n- T140, T150, and T156 remain conditional.\n- Historical tag `v1.2.0` remains pinned to `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`.\n- Historical DOI `10.5281/zenodo.21306969` remains immutable.\n- No tag movement, archive rebuild, Zenodo republication, or historical DOI mutation is performed.\n- No checker-completeness, unconditional global soundness, proof-term identity, global conservativity, empirical, physical, or cosmological claim is made.\n<!-- V0_OSAP_RC1_STATUS_END -->'
CHANGELOG_BLOCK = '<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->\n## [v1.3.0] - 2026-07-14 — Zenodo publication evidence closure and DOI finalization\n\n- Recorded the published Zenodo record `https://zenodo.org/records/21346728`.\n- Finalized v1.3.0 version DOI `10.5281/zenodo.21346728`.\n- Recorded corrected title `V0 OSAP Formal Core v1.3.0 — T121–T156 Stable Release`.\n- Recorded version `v1.3.0`, resource type `Software`, access `Open`, and publication date `2026-07-13`.\n- Recorded archive `olegovation-ship-it/v0-osap-formal-core-v1.3.0.zip` and linked GitHub release `v1.3.0`.\n- Advanced the README DOI badge and `CITATION.cff` to the v1.3.0 version DOI.\n- Frozen the final-release evidence, final-release authorization, and RC1 evidence artifacts by SHA-256.\n- Preserved stable target `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n- Preserved historical tag `v1.2.0`, target `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`, and DOI `10.5281/zenodo.21306969`.\n- Retained checker component `0.7.0.dev1`; T140, T150, and T156 remain conditional.\n- State: `ZENODO_PUBLICATION_EVIDENCE_CLOSED / DOI_FINALIZED / STABLE_TAG_CREATED / FINAL_GITHUB_RELEASE_CREATED / ZENODO_PUBLISHED`.\n<!-- V0_OSAP_RC1_CHANGELOG_END -->'
CITATION = 'cff-version: 1.2.0\nmessage: "Please cite the archived v1.3.0 software release using its Zenodo DOI."\ntitle: "V0 OSAP Formal Core v1.3.0 — T121–T156 Stable Release"\ntype: software\nauthors:\n  - family-names: Panasenko\n    given-names: Dmytro\n    orcid: "https://orcid.org/0009-0008-2249-4562"\ndoi: "10.5281/zenodo.21346728"\nrepository-code: "https://github.com/olegovation-ship-it/v0-osap-formal-core"\nrepository-artifact: "https://github.com/olegovation-ship-it/v0-osap-formal-core/releases/tag/v1.3.0"\nurl: "https://doi.org/10.5281/zenodo.21346728"\nversion: "1.3.0"\ndate-released: "2026-07-13"\nlicense: MIT\nkeywords:\n  - V0 OSAP\n  - formal verification\n  - formal semantics\n  - Lean 4\n  - Coq\n  - proof assistant\n  - ontology\n  - structural activation\n  - domain-license exhaustion\n  - observer-reflexive certification\n'

FROZEN_PREDECESSORS = [
    "release/v1.3.0/V1_3_0_FINAL_RELEASE_EVIDENCE_CLOSURE_MANIFEST.json",
    "release/v1.3.0/V1_3_0_FINAL_RELEASE_EVIDENCE_CLOSURE_RECORD.json",
    "release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_MANIFEST.json",
    "release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_RECORD.json",
    "release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_MANIFEST.json",
    "release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_RECORD.json",
]

def run(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run([*args], cwd=root, text=True, capture_output=True, check=check)

def git(root: Path, *args: str, check: bool = True) -> str:
    return run(root, "git", *args, check=check).stdout.strip()

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def replace_block(path: Path, begin: str, end: str, replacement: str) -> None:
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(re.escape(begin) + r".*?" + re.escape(end), re.DOTALL)
    if not pattern.search(text):
        raise SystemExit(f"ERROR: marker block not found in {path}")
    path.write_text(pattern.sub(replacement, text, count=1), encoding="utf-8", newline="\n")

def copy_payload(root: Path) -> None:
    for src in PAYLOAD.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(PAYLOAD)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def verify_anchor(root: Path, allow_unanchored: bool) -> None:
    if allow_unanchored:
        return
    result = run(root, "git", "merge-base", "--is-ancestor", BASE_MERGE, "HEAD", check=False)
    if result.returncode != 0:
        raise SystemExit(
            "ERROR: PR #17 final-release evidence merge commit is not an ancestor of HEAD"
        )
    run(root, "git", "fetch", "--force", "origin", "--tags", check=False)
    if git(root, "rev-list", "-n", "1", FINAL_TAG, check=False) != FINAL_TARGET:
        raise SystemExit("ERROR: stable tag v1.3.0 does not peel to the authorized target")
    if git(root, "cat-file", "-t", f"refs/tags/{FINAL_TAG}", check=False) != "tag":
        raise SystemExit("ERROR: v1.3.0 is not an annotated tag")
    if git(root, "rev-list", "-n", "1", OLD_TAG, check=False) != OLD_TARGET:
        raise SystemExit("ERROR: historical v1.2.0 tag target changed")

def build_record(root: Path) -> None:
    missing = [rel for rel in FROZEN_PREDECESSORS if not (root / rel).is_file()]
    if missing:
        raise SystemExit("ERROR: missing predecessor artifacts: " + ", ".join(missing))

    evidence = json.loads(
        (root / "release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE.json")
        .read_text(encoding="utf-8")
    )
    record = {
        "artifact_id": "V0_OSAP_V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_RECORD",
        "version": "0.1",
        "date": "2026-07-14",
        "state": (
            "ZENODO_PUBLICATION_EVIDENCE_CLOSED_DOI_FINALIZED_"
            "STABLE_TAG_CREATED_FINAL_GITHUB_RELEASE_CREATED_ZENODO_PUBLISHED"
        ),
        "human_state": (
            "ZENODO_PUBLICATION_EVIDENCE_CLOSED / DOI_FINALIZED / "
            "STABLE_TAG_CREATED / FINAL_GITHUB_RELEASE_CREATED / ZENODO_PUBLISHED"
        ),
        "repository": "olegovation-ship-it/v0-osap-formal-core",
        "authorization_basis": {
            "final_release_evidence_pr": 17,
            "final_release_evidence_merge_commit": BASE_MERGE,
            "exact_stable_target_commit": FINAL_TARGET,
        },
        "stable_release": evidence["stable_release"],
        "zenodo_publication": evidence["zenodo_record"],
        "frozen_predecessor_artifacts_sha256": {
            rel: sha256_file(root / rel) for rel in FROZEN_PREDECESSORS
        },
        "immutable_history": {
            "tag": evidence["historical_release"]["tag"],
            "target_commit": evidence["historical_release"]["target_commit"],
            "doi": evidence["historical_release"]["version_doi"],
            "remains_immutable": evidence["historical_release"]["remains_immutable"],
        },
        "release_actions": {
            "stable_tag_created": True,
            "stable_tag_moved": False,
            "github_final_release_created": True,
            "github_final_release_republished": False,
            "zenodo_version_published": True,
            "version_doi_finalized": True,
            "citation_surface_finalized": True,
            "historical_doi_mutated": False,
            "archive_rebuilt": False,
            "new_duplicate_upload_created": False,
        },
        "candidate_scope": {
            "theorem_range": "T121-T156",
            "record_count": 36,
            "source_crosswalk_count": 6,
            "conditional_theorems": ["T140", "T150", "T156"],
            "checker_component_version": "0.7.0.dev1",
        },
        "claim_boundary": {
            "checker_completeness_claimed": False,
            "unconditional_global_soundness_claimed": False,
            "proof_term_identity_claimed": False,
            "global_conservativity_claimed": False,
            "empirical_or_physical_validation_claimed": False,
            "cosmological_validation_claimed": False,
        },
    }
    path = root / "release/v1.3.0/V1_3_0_ZENODO_PUBLICATION_EVIDENCE_CLOSURE_RECORD.json"
    path.write_text(
        json.dumps(record, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", nargs="?", default=".")
    parser.add_argument("--allow-unanchored", action="store_true")
    args = parser.parse_args()

    root = Path(args.repository).resolve()
    if not (root / ".git").exists() or not (root / "README.md").is_file():
        raise SystemExit(f"ERROR: not a repository root: {root}")

    verify_anchor(root, args.allow_unanchored)
    copy_payload(root)

    replace_block(
        root / "README.md",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_END -->",
        README_BLOCK,
    )
    replace_block(
        root / "docs/status_and_nonclaims.md",
        "<!-- V0_OSAP_RC1_STATUS_BEGIN -->",
        "<!-- V0_OSAP_RC1_STATUS_END -->",
        STATUS_BLOCK,
    )
    replace_block(
        root / "CHANGELOG.md",
        "<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->",
        "<!-- V0_OSAP_RC1_CHANGELOG_END -->",
        CHANGELOG_BLOCK,
    )

    readme = (root / "README.md").read_text(encoding="utf-8")
    readme = re.sub(
        r"\[!\[DOI\]\(https://zenodo\.org/badge/DOI/10\.5281/zenodo\.\d+\.svg\)\]"
        r"\(https://doi\.org/10\.5281/zenodo\.\d+\)",
        "[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.21346728.svg)]"
        "(https://doi.org/10.5281/zenodo.21346728)",
        readme,
        count=1,
    )
    (root / "README.md").write_text(readme, encoding="utf-8", newline="\n")
    (root / "CITATION.cff").write_text(CITATION, encoding="utf-8", newline="\n")

    build_record(root)
    run(root, sys.executable, "scripts/build_v1_3_0_zenodo_publication_evidence_closure_manifest.py")
    verifier = [sys.executable, "scripts/verify_v1_3_0_zenodo_publication_evidence_closure.py"]
    if not args.allow_unanchored:
        verifier.append("--require-tags")
    result = run(root, *verifier)
    print(result.stdout.strip())
    print("PASS: Zenodo publication evidence closure and DOI finalization patch applied.")
    print("No tag, GitHub Release, Zenodo record, archive, or historical DOI was modified.")

if __name__ == "__main__":
    main()
