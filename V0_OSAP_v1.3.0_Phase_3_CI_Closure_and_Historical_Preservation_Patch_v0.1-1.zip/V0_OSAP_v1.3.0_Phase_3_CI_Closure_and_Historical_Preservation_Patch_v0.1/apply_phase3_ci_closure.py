#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

EXPECTED_BASE = "c02b05f667b82aa31ac8865c31219b94b1fc74d2"
EXPECTED_BRANCH = "v1.3.0-development"

REPLACEMENTS = [
    "README.md",
    "CHANGELOG.md",
    "docs/status_and_nonclaims.md",
    "docs/theorem_register.md",
    "release/v1.3.0/PHASE3_ACCEPTANCE_GATES.md",
    "release/v1.3.0/PHASE3_BUILD_SPECIFICATION.md",
    "release/v1.3.0/PHASE3_IMPLEMENTATION_REPORT.md",
    ".github/workflows/release-readiness.yml",
    "scripts/verify_phase3_expansion.py",
]

NEW_FILES = [
    "release/v1.3.0/PHASE3_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
    "release/v1.3.0/PHASE3_CI_CLOSURE_EVIDENCE.json",
    "scripts/verify_phase3_ci_closure.py",
]


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=repo, text=True, stderr=subprocess.STDOUT
    ).strip()


def validate_base(repo: Path, force: bool) -> None:
    required = [
        repo / "README.md",
        repo / "release/v1.3.0/theorem_crosswalk_phase3.json",
        repo / "scripts/verify_phase3_expansion.py",
    ]
    missing = [str(p.relative_to(repo)) for p in required if not p.exists()]
    if missing:
        raise SystemExit(f"Not a compatible repository; missing: {', '.join(missing)}")

    crosswalk = json.loads(
        (repo / "release/v1.3.0/theorem_crosswalk_phase3.json").read_text(
            encoding="utf-8"
        )
    )
    if crosswalk.get("phase3_status") != "BUILD_READY_CI_PENDING" and not force:
        raise SystemExit(
            "Phase 3 crosswalk is not in BUILD_READY_CI_PENDING state. "
            "Use --force only after reviewing the repository state."
        )

    try:
        branch = git(repo, "branch", "--show-current")
        head = git(repo, "rev-parse", "HEAD")
    except Exception:
        return

    if branch != EXPECTED_BRANCH and not force:
        raise SystemExit(
            f"Expected branch {EXPECTED_BRANCH!r}, found {branch!r}. "
            "Checkout the development branch or use --force."
        )
    if head != EXPECTED_BASE and not force:
        raise SystemExit(
            f"Expected Phase 3 merge base {EXPECTED_BASE}, found {head}. "
            "Pull/synchronize the branch first or use --force after review."
        )


def update_crosswalk(repo: Path) -> None:
    path = repo / "release/v1.3.0/theorem_crosswalk_phase3.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    records = data["records"]
    for row in records:
        row["claim_limitations"] = ["finite accepted fragment only"]
        row["parity_status"] = "ACCEPTED_CI_PASS"

    updated = {
        "artifact_id": data["artifact_id"],
        "artifact_version": data["artifact_version"],
        "baseline_tag": data["baseline_tag"],
        "baseline_doi": data["baseline_doi"],
        "phase1_status": data["phase1_status"],
        "phase2_status": data["phase2_status"],
        "phase3_status": "ACCEPTED_CI_PASS_MERGED",
        "theorem_range": data["theorem_range"],
        "pull_request": 4,
        "head_commit": "2172591ed8a5ab3c1fa31f2a3a6575536f161fe4",
        "merge_commit": "c02b05f667b82aa31ac8865c31219b94b1fc74d2",
        "merged_at_utc": "2026-07-11T21:56:58Z",
        "github_pr_checks": 8,
        "python_tests": 112,
        "historical_preservation": "PASS",
        "closure_evidence": "release/v1.3.0/PHASE3_CI_CLOSURE_EVIDENCE.json",
        "records": records,
    }
    path.write_text(
        json.dumps(updated, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def apply(repo: Path, package: Path, force: bool) -> None:
    validate_base(repo, force)
    payload = package / "payload"

    for rel in REPLACEMENTS + NEW_FILES:
        src = payload / rel
        dst = repo / rel
        if not src.exists():
            raise SystemExit(f"Package payload missing: {rel}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    update_crosswalk(repo)
    print("Applied Phase 3 CI closure and historical-preservation patch.")
    print("Run: python scripts/verify_phase3_expansion.py")
    print("Run: python scripts/verify_phase3_ci_closure.py")
    print("Then run the full local validation matrix before committing.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".", help="Repository root")
    parser.add_argument(
        "--force",
        action="store_true",
        help="Apply despite branch/base/status mismatch after manual review",
    )
    args = parser.parse_args()
    repo = Path(args.repo).resolve()
    package = Path(__file__).resolve().parent
    apply(repo, package, args.force)


if __name__ == "__main__":
    main()
