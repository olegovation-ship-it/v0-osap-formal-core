# Apply and open the Phase 3 closure PR

## Verified starting state

- Repository: `olegovation-ship-it/v0-osap-formal-core`
- Branch: `v1.3.0-development`
- Phase 3 implementation PR: `#4`
- Implementation head: `2172591ed8a5ab3c1fa31f2a3a6575536f161fe4`
- Merge commit: `c02b05f667b82aa31ac8865c31219b94b1fc74d2`
- PR #4: merged, 8/8 checks passed
- `main` and `v1.3.0-development`: synchronized at the merge commit

## Apply

From a clean local clone:

```bash
git checkout v1.3.0-development
git pull --ff-only origin v1.3.0-development
python /path/to/this/package/apply_phase3_ci_closure.py .
```

## Validate

```bash
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
python scripts/verify_phase2_ci_closure.py
python scripts/verify_phase3_expansion.py
python scripts/verify_phase3_ci_closure.py
(cd lean && lake build)
(cd coq && make)
git diff --check
```

Expected Python total: `112 passed`.

## Commit and push

```bash
git add   .github/workflows/release-readiness.yml   CHANGELOG.md README.md   docs/status_and_nonclaims.md docs/theorem_register.md   release/v1.3.0/PHASE3_ACCEPTANCE_GATES.md   release/v1.3.0/PHASE3_BUILD_SPECIFICATION.md   release/v1.3.0/PHASE3_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md   release/v1.3.0/PHASE3_CI_CLOSURE_EVIDENCE.json   release/v1.3.0/PHASE3_IMPLEMENTATION_REPORT.md   release/v1.3.0/theorem_crosswalk_phase3.json   scripts/verify_phase3_expansion.py   scripts/verify_phase3_ci_closure.py

git commit -m "Close V0 OSAP v1.3.0 Phase 3 CI and preserve history"
git push origin v1.3.0-development
```

Create a **Draft PR** from `v1.3.0-development` to `main` using `PR_TITLE.txt` and `PR_BODY.md`.

## Important boundary

This patch closes Phase 3 development evidence only. It does not release v1.3.0, move or retag v1.2.0, or create or alter a DOI.
