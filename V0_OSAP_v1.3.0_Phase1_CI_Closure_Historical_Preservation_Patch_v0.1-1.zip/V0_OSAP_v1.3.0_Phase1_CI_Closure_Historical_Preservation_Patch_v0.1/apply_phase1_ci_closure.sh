#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-/workspaces/v0-osap-formal-core}"
BRANCH="v1.3.0-development"
COMMIT_MESSAGE="Close Phase 1 CI and preserve v1.2.0 history"

cd "$REPO_ROOT"

current_branch="$(git branch --show-current)"
if [[ "$current_branch" != "$BRANCH" ]]; then
  echo "ERROR: expected branch '$BRANCH', found '$current_branch'." >&2
  echo "Run: git switch $BRANCH" >&2
  exit 2
fi

git pull --ff-only origin "$BRANCH"

cat > .github/workflows/release-readiness.yml <<'EOF'
name: Release readiness

on:
  push:
    branches: [main, v1.3.0-development]
  pull_request:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  immutable-v1-2-baseline:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          ref: v1.2.0
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
          cache: pip
      - run: python -m pip install --upgrade pip
      - run: python -m pip install -e '.[dev]'
      - run: python scripts/check_no_proof_holes.py
      - run: v0-osap-fc1 schema-bundle
      - run: v0-osap-fc1 fixtures
      - run: python scripts/verify_manifest.py
      - run: python scripts/verify_closure.py

  phase1-development-readiness:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
          cache: pip
      - run: python -m pip install --upgrade pip
      - run: python -m pip install -e '.[dev]'
      - run: pytest -q
      - run: v0-osap-fc1 schema-bundle
      - run: v0-osap-fc1 fixtures
      - run: python scripts/check_no_proof_holes.py
      - run: python scripts/verify_phase1_alignment.py
EOF

cat > CHANGELOG.md <<'EOF'
# Changelog

## [Unreleased]

### Phase 1 semantic alignment
- Added exact executable coverage for T122 empty-`all_of` vacuity.
- Added explicit T124 robust-relative-V0 residual-obstruction diagnostics and fixtures.
- Aligned Python T125 semantics with the Lean 4 and Coq terminal-support-exhaustion predicate.
- Split observer admissibility into a separate unnumbered predicate and diagnostic.
- Added the Phase 1 theorem crosswalk, schema erratum, acceptance gates, static verifier, and development CI job.
- Bumped the development checker version to `0.2.0.dev1`.

### Phase 1 CI closure
- Advanced Phase 1 from `PATCH_READY / CI_PENDING` to `ACCEPTED / CI_PASS`.
- Recorded the all-green PR #1 matrix for Schema validation, Python checker, Lean 4, Coq, and Release readiness.
- Restored `python scripts/verify_closure.py` to the immutable-v1.2.0 baseline job.
- Added explicit CI-closure and historical-preservation verification.

### Post-release metadata preservation
- Added the Zenodo version DOI `10.5281/zenodo.21306969`.
- Added repository and tagged-release backlinks to the citation metadata.
- Finalized `CITATION.cff` for the archived v1.2.0 software release.
- Updated the closure verifier to require finalized DOI metadata.
- Preserved the immutable `v1.2.0` tag; this is a post-release metadata patch, not a retag.

### Release discipline
- Preserved the immutable `v1.2.0` tag and DOI `10.5281/zenodo.21306969`.
- Phase 1 acceptance is not a v1.3.0 release or a full-v1.3.0 compiler-passed claim.

## [1.2.0] - 2026-07-11

### Added
- Compiler-version evidence in `release/compiler_versions.json`.
- Closure verification script and final release-readiness gate.
- GitHub Release notes for the bounded FC-1 baseline.

### Changed
- README status advanced from bootstrap/pending to dual-backend compiler-passed.
- Lean 4 and Coq workflows now print compiler versions.
- The theorem register now records compiled status for T121-T126.
- Release manifest status advanced to `DUAL_BACKEND_ACCEPTED`.

### Fixed
- Replaced Lean 4 reserved identifiers in the branch-firewall definitions and T126 wrapper.
- Refreshed manifest integrity after the Lean repair.

### Verified
- Schema validation: PASS.
- Python checker and fixtures: PASS.
- Lean 4 build and proof-hole scan: PASS.
- Coq build and proof-hole scan: PASS.
- Release readiness: PASS.
- Evidence commit: `48db564c085aec411552e78eef6c1740bd27a5ac`.

### Limits
- No theorem-completeness claim beyond the initial T121-T126 subset.
- No proof-equivalence claim between Lean 4 and Coq.
- No empirical or physical validation claim.
- Version 1.2.0 is archived under DOI `10.5281/zenodo.21306969`; the tagged source baseline remains immutable.
EOF

cat > README.md <<'EOF'
# V0 OSAP Formal Core

[![Schema validation](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/schema-check.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/schema-check.yml)
[![Python checker](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/python-checker.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/python-checker.yml)
[![Lean 4](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/lean4.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/lean4.yml)
[![Coq](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/coq.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/coq.yml)
[![Release readiness](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/release-readiness.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/release-readiness.yml)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.21306969.svg)](https://doi.org/10.5281/zenodo.21306969)

Executable and proof-assistant-facing formal core for the **V0 Ontological and Structural-Activation Program (V0 OSAP)**.

## v1.3.0 development status

> **PHASE 1 SEMANTIC ALIGNMENT — ACCEPTED / CI PASS**

The development branch aligns executable coverage for T122, T124, and T125:

- T122: exact empty-`all_of` vacuity fixture and schema erratum;
- T124: explicit robust-relative-V0 residual-obstruction rule and paired fixtures;
- T125: exact terminal-support-exhaustion rule, separated from observer admissibility;
- checker development version: `0.2.0.dev1`.

The Phase 1 acceptance matrix passed for Schema validation, Python checker, Lean 4, Coq, and Release readiness. The immutable-v1.2.0 readiness job retains both manifest and closure verification.

This is not a v1.3.0 release and does not extend the archived v1.2.0 compiler-passed claim. See `release/v1.3.0/PHASE1_ACCEPTANCE_GATES.md` and `release/v1.3.0/PHASE1_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md`.

## v1.2.0 release status

> **V0 OSAP v1.2.0 — DUAL-BACKEND COMPILER-PASSED FC-1 BASELINE**

- Imported specification: **V0 OSAP v1.1 / FC-1-v1.1**.
- Canonical JSON Schemas: JSON Schema Draft 2020-12.
- Python checker release version: `0.1.0` in the immutable tag.
- Lean 4 and Coq passed on the archived baseline.
- GitHub Release: [v1.2.0](https://github.com/olegovation-ship-it/v0-osap-formal-core/releases/tag/v1.2.0).
- Zenodo version DOI: [10.5281/zenodo.21306969](https://doi.org/10.5281/zenodo.21306969).

The compiler-passed claim remains bounded to the archived FC-1 implementation and T121-T126. The tag `v1.2.0` must not be moved or retagged.

## Scope

FC-1 checks a finite, typed registry fragment covering live-state guards, prerequisite support, domain-license exhaustion, residual obstruction, observer-certificate limits, branch locality, canonical serialization, and deterministic fixture replay.

This repository is a formal-semantics and verification artifact. It is **not** empirical confirmation of a physical vacuum, cosmology, disappearance mechanism, quantum-gravity model, or multiverse.

## Local development checks

```bash
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
cd lean && lake build
cd ../coq && make
```

The archived baseline closure check is executed by the Release readiness workflow after checking out the immutable `v1.2.0` tag.

## License

MIT. See [LICENSE](LICENSE).
EOF

cat > docs/status_and_nonclaims.md <<'EOF'
# Status and non-claims

## Immutable v1.2.0 baseline

- Tag `v1.2.0` and DOI `10.5281/zenodo.21306969` remain immutable.
- The archived baseline remains the bounded dual-backend compiler-passed T121-T126 release.
- The immutable baseline CI job executes proof-hole, schema, fixture, manifest, and closure verification.
- This Phase 1 package is a development patch and does not rewrite the archived release.

## v1.3.0 Phase 1 assertions

- T122 receives an exact executable positive fixture for empty `all_of` vacuity.
- T124 receives an explicit Python rule and paired positive/countermodel fixtures.
- T125 is aligned with the Lean/Coq exhaustion predicate.
- Observer admissibility is separated into an unnumbered operational predicate.
- The old missing-prerequisite countermodel is no longer presented as T122 evidence.
- The old observer-support countermodel is no longer presented as T125 evidence.

## Acceptance state

- Phase 1 status: `ACCEPTED / CI PASS`.
- Package-level static verification: PASS.
- Python test suite and schema/fixture replay: PASS.
- Proof-hole scan: PASS.
- Lean 4 build: PASS.
- Coq build: PASS.
- GitHub Actions all-green matrix: PASS.
- Historical v1.2.0 manifest and closure preservation: PASS.

## Explicit non-claims

- No release claim for v1.3.0.
- No new theorem IDs beyond T121-T126.
- No complete mechanization claim for T1-T150 or T121-T150.
- No formal equivalence claim among Python, Lean 4, and Coq.
- No empirical, physical, cosmological, disappearance-mechanism, quantum-gravity, or multiverse validation claim.
EOF

cat > docs/theorem_register.md <<'EOF'
# Theorem-target register

The normative v1.1 document reserves T121-T150. The immutable v1.2.0 release compiled the initial subset T121-T126. The v1.3.0 Phase 1 development patch corrects executable crosswalk coverage for T122, T124, and T125 without moving or retagging v1.2.0.

Baseline evidence commit: `48db564c085aec411552e78eef6c1740bd27a5ac`.
Phase 1 patch status: `ACCEPTED / CI PASS`.

| ID | Canonical name | Python after Phase 1 | Lean 4 | Coq | Phase 1 status |
|---|---|---:|---:|---:|---|
| T121 | live guard has a live token | existing fixture | baseline compiled | baseline compiled | unchanged |
| T122 | empty all-of prerequisite set is vacuously satisfied | exact positive fixture | baseline compiled | baseline compiled | blocker closed by schema erratum and exact fixture; CI passed |
| T123 | DLE implies current no-live status | existing fixture | baseline compiled | baseline compiled | unchanged |
| T124 | live residual obstructs robust relative V0 | explicit `robust_relative_v0` rule plus positive/countermodel fixtures | baseline compiled | baseline compiled | blocker closed; CI passed |
| T125 | terminal self-certification exposes support exhaustion | exact exhaustion rule plus positive/countermodel fixtures | definition retained | definition retained | semantic collision removed; CI passed |
| T126 | branch-local support does not license absolute promotion | existing fixture | baseline compiled | baseline compiled | unchanged |

## Observer-certificate split

`TerminalSelfCertificate` remains the T125 predicate: internal support and external evidence are both empty. `AdmissibleObserverCertificate` is a separate unnumbered operational predicate requiring external evidence and an independence group. The two predicates must not share a diagnostic code or theorem-target mapping.

`compiled` remains bounded evidence that the corresponding module passed its backend build and proof-hole scan. It does not establish cross-assistant proof-term identity or semantic equivalence.
EOF

cat > release/v1.3.0/PHASE1_ACCEPTANCE_GATES.md <<'EOF'
# Phase 1 acceptance gates

Phase 1 is marked `ACCEPTED / CI PASS` because all gates passed on the installed repository state:

1. `python -m pip install -e '.[dev]'`
2. `pytest -q`
3. `v0-osap-fc1 schema-bundle`
4. `v0-osap-fc1 fixtures`
5. `python scripts/check_no_proof_holes.py`
6. `python scripts/verify_phase1_alignment.py`
7. `cd lean && lake build`
8. `cd coq && make`
9. GitHub Actions: Schema validation, Python checker, Lean 4, Coq, and Release readiness all green.
10. No T122 attribution remains on the missing-prerequisite countermodel.
11. No T125 attribution remains on observer admissibility fixtures.
12. The immutable `v1.2.0` tag remains unchanged.
13. The immutable-v1.2.0 readiness job runs both `verify_manifest.py` and `verify_closure.py`.
14. The detailed v1.2.0 changelog history is preserved.

This acceptance closes Phase 1 only. It does not create a v1.3.0 release, move the v1.2.0 tag, or enlarge the archived compiler-passed claim.
EOF

cat > release/v1.3.0/PHASE1_SEMANTIC_ALIGNMENT_REPORT.md <<'EOF'
# V0 OSAP v1.3.0 Phase 1 Semantic Alignment and Blocker Closure Patch v0.1

Status: `ACCEPTED / CI_PASS`
Date: 2026-07-11
Baseline: immutable `v1.2.0`, DOI `10.5281/zenodo.21306969`

## Objective

Close the three crosswalk blockers identified after the v1.3.0 build-plan audit while preserving the archived v1.2.0 tag:

1. T122 lacked an exact executable fixture because the schema prohibited an empty prerequisite list.
2. T124 lacked a direct Python rule and paired theorem-target fixtures.
3. T125 conflated terminal support exhaustion with operational observer admissibility.

## Repairs

### T122

- Correct the schema so empty `all_of` families are permitted and vacuously satisfied.
- Preserve the nonempty requirement for `one_of` families.
- Add `fixture:positive:t122_empty_all_prerequisites`.
- Remove T122 attribution from the legacy missing-prerequisite countermodel.

### T124

- Add claim kind `robust_relative_v0`.
- Add diagnostic `LIVE_RESIDUAL_OBSTRUCTS_ROBUST_RELATIVE_V0`.
- Add positive and countermodel fixtures with exact T124 attribution.

### T125

- Keep T125 equal to terminal support exhaustion in Python, Lean 4, and Coq.
- Add diagnostic `TERMINAL_SELF_CERTIFICATE_NOT_EXHAUSTED`.
- Add exact positive and countermodel fixtures.
- Introduce `AdmissibleObserverCertificate` as a separate unnumbered predicate.
- Replace the old conflated diagnostic with `OBSERVER_CERTIFICATION_SUPPORT_REQUIRED` and remove T125 attribution.

## CI closure

- Schema validation: PASS.
- Python checker and regression suite: PASS.
- Lean 4 build and proof-hole scan: PASS.
- Coq build and proof-hole scan: PASS.
- Release readiness: PASS.
- Phase 1 semantic-alignment verifier: PASS.

## Historical preservation

- The immutable `v1.2.0` tag and DOI are unchanged.
- The immutable-baseline workflow retains both `verify_manifest.py` and `verify_closure.py`.
- The detailed v1.2.0 changelog record is preserved rather than collapsed into a summary line.

## Release discipline

This package is not a v1.3.0 release. It applies on `v1.3.0-development` or an equivalent development branch. Phase 1 acceptance does not move the v1.2.0 tag, create a new DOI, or extend the archived compiler-passed claim.
EOF

cat > release/v1.3.0/theorem_crosswalk_phase1.json <<'EOF'
{
  "artifact_id": "V0_OSAP_v1_3_0_phase1_theorem_crosswalk",
  "artifact_version": "0.1",
  "baseline_tag": "v1.2.0",
  "baseline_doi": "10.5281/zenodo.21306969",
  "status": "PHASE1_ACCEPTED_CI_PASS",
  "records": [
    {
      "theorem_id": "T121",
      "canonical_title": "Live guard has a live token",
      "python_mapping": "existing live_guard fixture",
      "lean_mapping": "V0OSAP.T121",
      "coq_mapping": "T121_live_guard_has_live_token",
      "phase1_blocker_status": "NOT_A_PHASE1_BLOCKER"
    },
    {
      "theorem_id": "T122",
      "canonical_title": "Empty all-of prerequisite family is vacuously satisfied",
      "python_mapping": "empty_all_prerequisites positive fixture and all([]) semantics",
      "lean_mapping": "V0OSAP.T122",
      "coq_mapping": "T122_empty_all_prerequisites_live",
      "phase1_blocker_status": "CLOSED_ACCEPTED_CI_PASS"
    },
    {
      "theorem_id": "T123",
      "canonical_title": "DLE implies current no-live status",
      "python_mapping": "existing DLE rule and fixture",
      "lean_mapping": "V0OSAP.T123",
      "coq_mapping": "T123_dle_implies_no_live",
      "phase1_blocker_status": "NOT_A_PHASE1_BLOCKER"
    },
    {
      "theorem_id": "T124",
      "canonical_title": "Live residual obstructs robust relative V0",
      "python_mapping": "robust_relative_v0 claim and LIVE_RESIDUAL_OBSTRUCTS_ROBUST_RELATIVE_V0",
      "lean_mapping": "V0OSAP.T124",
      "coq_mapping": "T124_live_residual_obstructs_robust_relative_v0",
      "phase1_blocker_status": "CLOSED_ACCEPTED_CI_PASS"
    },
    {
      "theorem_id": "T125",
      "canonical_title": "Terminal self-certificate exposes empty internal and external support",
      "python_mapping": "observer_terminal_self_certificate and TERMINAL_SELF_CERTIFICATE_NOT_EXHAUSTED",
      "lean_mapping": "V0OSAP.T125 / TerminalSelfCertificate",
      "coq_mapping": "T125_terminal_self_certificate_exposes_empty_support",
      "phase1_blocker_status": "CLOSED_ACCEPTED_CI_PASS",
      "non_theorem_operational_mapping": "observer_admissible_certificate / AdmissibleObserverCertificate"
    },
    {
      "theorem_id": "T126",
      "canonical_title": "Direct branch-local to absolute promotion violates the firewall",
      "python_mapping": "existing absolute-relative firewall fixture",
      "lean_mapping": "V0OSAP.T126",
      "coq_mapping": "T126_direct_promotion_violates_firewall",
      "phase1_blocker_status": "NOT_A_PHASE1_BLOCKER"
    }
  ]
}
EOF

cat > release/v1.3.0/schema_erratum_manifest.json <<'EOF'
{
  "artifact_id": "V0_OSAP_v1_3_0_phase1_schema_addendum",
  "baseline_schema_version": "v1.1",
  "status": "ERRATUM_ACCEPTED_CI_PASS",
  "files": [
    {
      "path": "schemas/v1.1/registry_state.schema.json",
      "sha256": "35e9b2e321046200e9a7e63ae765fec68823ee0117ab07d0ac96bc1a1a67da5b",
      "bytes": 6005
    },
    {
      "path": "schemas/v1.1/ERRATA_PHASE1.md",
      "sha256": "48b1b02d2d958ad55bb3e62e772ef47aa437a7abb069ee927287407eaf276bdf",
      "bytes": 479
    }
  ]
}
EOF

cat > release/v1.3.0/PHASE1_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md <<'EOF'
# Phase 1 CI Closure and Historical-Preservation Report

Status: `ACCEPTED / CI_PASS`
Date: 2026-07-11
Pull request: `#1`
Development branch: `v1.3.0-development`
Immutable baseline: `v1.2.0`
Baseline DOI: `10.5281/zenodo.21306969`

## Closure result

The Phase 1 semantic-alignment patch passed the complete GitHub Actions matrix:

- Schema validation: PASS.
- Python checker: PASS.
- Lean 4: PASS.
- Coq: PASS.
- Release readiness: PASS.

The Phase 1-specific static verifier, schema bundle validation, fixture replay, regression suite, and proof-hole scan also pass.

## Historical-preservation repair

The closure review identified and repaired two metadata/integrity defects:

1. Phase 1 documents still carried `CI_PENDING` labels after the all-green matrix.
2. The development rewrite of `release-readiness.yml` had omitted `python scripts/verify_closure.py` from the immutable-v1.2.0 job.

The patch restores the closure verifier, retains manifest verification, preserves the detailed v1.2.0 changelog history, and advances Phase 1 records to accepted status.

## Boundary

This report closes Phase 1 only. It is not a v1.3.0 release record, does not move or retag `v1.2.0`, does not create a new DOI, and does not claim theorem completeness or cross-assistant semantic equivalence.
EOF

cat > scripts/verify_phase1_alignment.py <<'EOF'
from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def load(path: str):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


schema = load("schemas/v1.1/registry_state.schema.json")
Draft202012Validator.check_schema(schema)

# T122 schema contract.
family_schema = schema["properties"]["prerequisite_families"]["items"]
assert "minItems" not in family_schema["properties"]["prerequisite_register_ids"]
assert family_schema["allOf"][0]["then"]["properties"]["prerequisite_register_ids"]["minItems"] == 1

fixture_manifest = load("fixtures/manifest.json")
required_paths = {
    "positive/empty_all_prerequisites.fixture.json",
    "positive/robust_relative_v0_no_live_residual.fixture.json",
    "negative/live_residual_obstruction.fixture.json",
    "positive/terminal_self_certificate_exhausted.fixture.json",
    "negative/terminal_self_certificate_not_exhausted.fixture.json",
}
assert required_paths.issubset(set(fixture_manifest["fixtures"]))

for rel in required_paths:
    descriptor = load("fixtures/" + rel)
    for target in descriptor["theorem_targets"]:
        assert target in {"T122", "T124", "T125"}

legacy = load("fixtures/negative/observer_self_certificate.fixture.json")
assert legacy["theorem_targets"] == []
assert legacy["expected_diagnostics"] == ["OBSERVER_CERTIFICATION_SUPPORT_REQUIRED"]

missing = load("fixtures/negative/missing_prerequisite.fixture.json")
assert missing["theorem_targets"] == []

semantic = (ROOT / "checker/v0_osap_fc1/semantic.py").read_text(encoding="utf-8")
for code in (
    "LIVE_RESIDUAL_OBSTRUCTS_ROBUST_RELATIVE_V0",
    "TERMINAL_SELF_CERTIFICATE_NOT_EXHAUSTED",
    "OBSERVER_CERTIFICATION_SUPPORT_REQUIRED",
):
    assert code in semantic
assert '"implementation_version": "v0-osap-fc1/0.2.0.dev1"' in semantic

lean = (ROOT / "lean/V0OSAP/Observer.lean").read_text(encoding="utf-8")
coq = (ROOT / "coq/theories/Observer.v").read_text(encoding="utf-8")
for text in (lean, coq):
    assert "terminal_self_certificate" in text.lower() or "TerminalSelfCertificate" in text
    assert "admissible" in text.lower()

crosswalk = load("release/v1.3.0/theorem_crosswalk_phase1.json")
records = {item["theorem_id"]: item for item in crosswalk["records"]}
assert set(records) == {"T121", "T122", "T123", "T124", "T125", "T126"}
assert crosswalk["status"] == "PHASE1_ACCEPTED_CI_PASS"
for target in ("T122", "T124", "T125"):
    assert records[target]["phase1_blocker_status"] == "CLOSED_ACCEPTED_CI_PASS"

schema_manifest = load("release/v1.3.0/schema_erratum_manifest.json")
assert schema_manifest["status"] == "ERRATUM_ACCEPTED_CI_PASS"

workflow = (ROOT / ".github/workflows/release-readiness.yml").read_text(encoding="utf-8")
assert "ref: v1.2.0" in workflow
assert "python scripts/verify_manifest.py" in workflow
assert "python scripts/verify_closure.py" in workflow
assert "python scripts/verify_phase1_alignment.py" in workflow

closure_docs = [
    "README.md",
    "docs/status_and_nonclaims.md",
    "docs/theorem_register.md",
    "release/v1.3.0/PHASE1_ACCEPTANCE_GATES.md",
    "release/v1.3.0/PHASE1_SEMANTIC_ALIGNMENT_REPORT.md",
    "release/v1.3.0/PHASE1_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
]
for path in closure_docs:
    text = (ROOT / path).read_text(encoding="utf-8")
    assert "CI_PENDING" not in text
    assert "CLOSED_BY_PATCH_PENDING_CI" not in text

changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
assert "## [1.2.0] - 2026-07-11" in changelog
assert "48db564c085aec411552e78eef6c1740bd27a5ac" in changelog
assert "10.5281/zenodo.21306969" in changelog
assert "Closure verification script and final release-readiness gate." in changelog

print("PASS: V0 OSAP v1.3.0 Phase 1 accepted, CI-closed, and historically preserved.")
EOF

python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py

(
  cd lean
  lake build
)

(
  cd coq
  make
)

git diff --check

git add \
  .github/workflows/release-readiness.yml \
  CHANGELOG.md \
  README.md \
  docs/status_and_nonclaims.md \
  docs/theorem_register.md \
  release/v1.3.0/PHASE1_ACCEPTANCE_GATES.md \
  release/v1.3.0/PHASE1_SEMANTIC_ALIGNMENT_REPORT.md \
  release/v1.3.0/PHASE1_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md \
  release/v1.3.0/theorem_crosswalk_phase1.json \
  release/v1.3.0/schema_erratum_manifest.json \
  scripts/verify_phase1_alignment.py

git commit -m "$COMMIT_MESSAGE"
git push origin "$BRANCH"

echo
echo "PATCH APPLIED AND PUSHED."
echo "Open PR #1 and wait for all checks to return green."
