# V0 OSAP v1.3.0 Phase 1 CI Closure and Historical-Preservation Patch v0.1

This package applies the CI-closure and historical-preservation repair to the
`v1.3.0-development` branch.

## Scope

- restores `scripts/verify_closure.py` in the immutable-v1.2.0 readiness job;
- advances Phase 1 metadata from CI-pending to accepted/CI-pass;
- restores the detailed v1.2.0 changelog history;
- adds a dedicated closure report;
- strengthens `verify_phase1_alignment.py`;
- runs Python, schema, fixtures, proof-hole, Lean 4, Coq, and diff checks;
- commits and pushes the result.

## Run

From the repository Codespace:

```bash
unzip -o V0_OSAP_v1.3.0_Phase1_CI_Closure_Historical_Preservation_Patch_v0.1.zip -d /tmp/v0_phase1_ci_closure
bash /tmp/v0_phase1_ci_closure/V0_OSAP_v1.3.0_Phase1_CI_Closure_Historical_Preservation_Patch_v0.1/apply_phase1_ci_closure.sh
```

The script refuses to run unless the current branch is `v1.3.0-development`.
