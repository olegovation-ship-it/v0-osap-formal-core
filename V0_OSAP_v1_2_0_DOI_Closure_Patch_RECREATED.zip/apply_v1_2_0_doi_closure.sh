#!/usr/bin/env bash
set -euo pipefail

cd /workspaces/v0-osap-formal-core

git pull --ff-only origin main

if [ -n "$(git status --porcelain)" ]; then
  echo "STOP: repository has uncommitted changes:"
  git status --short
  exit 1
fi

python - <<'PY'
from pathlib import Path

ROOT = Path(".")
DOI = "10.5281/zenodo.21306969"
DOI_URL = f"https://doi.org/{DOI}"
REPOSITORY = "https://github.com/olegovation-ship-it/v0-osap-formal-core"
RELEASE = f"{REPOSITORY}/releases/tag/v1.2.0"

def replace_once(path: str, old: str, new: str) -> None:
    p = ROOT / path
    text = p.read_text(encoding="utf-8")
    if old in text:
        p.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"UPDATED: {path}")
    elif new in text:
        print(f"ALREADY UPDATED: {path}")
    else:
        raise RuntimeError(f"Expected text not found in {path}")

replace_once(
    "README.md",
    "[![Release readiness](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/release-readiness.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/release-readiness.yml)\n",
    "[![Release readiness](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/release-readiness.yml/badge.svg)](https://github.com/olegovation-ship-it/v0-osap-formal-core/actions/workflows/release-readiness.yml)\n"
    "[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.21306969.svg)](https://doi.org/10.5281/zenodo.21306969)\n",
)

replace_once(
    "README.md",
    "- GitHub Release / Zenodo DOI: **DOI: pending** until the tagged release is archived.\n",
    "- GitHub Release: [v1.2.0](https://github.com/olegovation-ship-it/v0-osap-formal-core/releases/tag/v1.2.0).\n"
    "- Zenodo version DOI: [10.5281/zenodo.21306969](https://doi.org/10.5281/zenodo.21306969).\n",
)

replace_once(
    "README.md",
    "The annotated tag `v1.2.0` may be created only after the closure commit passes all five workflows. A DOI must be added only after the immutable GitHub Release is archived by Zenodo.\n",
    "The annotated tag `v1.2.0` identifies the immutable compiler-passed FC-1 baseline. "
    "Its archived version DOI is [10.5281/zenodo.21306969](https://doi.org/10.5281/zenodo.21306969). "
    "Future software releases require a new semantic-version tag and a separate archival record; "
    "`v1.2.0` must not be moved or retagged.\n",
)

citation = f'''cff-version: 1.2.0
message: "Please cite the archived v1.2.0 software release using its Zenodo DOI."
title: "V0 OSAP Formal Core v1.2.0 — Compiler-Passed FC-1 Baseline"
type: software
authors:
  - family-names: Panasenko
    given-names: Dmytro
    orcid: "https://orcid.org/0009-0008-2249-4562"
doi: "{DOI}"
repository-code: "{REPOSITORY}"
repository-artifact: "{RELEASE}"
url: "{DOI_URL}"
version: "1.2.0"
date-released: "2026-07-11"
license: MIT
keywords:
  - V0 OSAP
  - formal verification
  - formal semantics
  - Lean 4
  - Coq
  - proof assistant
  - ontology
  - structural activation
  - domain-license exhaustion
  - observer-reflexive certification
'''
(ROOT / "CITATION.cff").write_text(citation, encoding="utf-8")
print("UPDATED: CITATION.cff")

replace_once(
    "CHANGELOG.md",
    "## [Unreleased]\n\n### Pending\n- Zenodo DOI, repository backlink, and final citation update after the tagged GitHub Release is archived.\n",
    "## [Unreleased]\n\n### Changed\n"
    "- Added the Zenodo version DOI `10.5281/zenodo.21306969`.\n"
    "- Added repository and tagged-release backlinks to the citation metadata.\n"
    "- Finalized `CITATION.cff` for the archived v1.2.0 software release.\n"
    "- Updated the closure verifier to require finalized DOI metadata.\n"
    "- Preserved the immutable `v1.2.0` tag; this is a post-release metadata patch, not a retag.\n",
)

replace_once(
    "CHANGELOG.md",
    "- DOI remains pending until tagged-release archival.\n",
    "- Version 1.2.0 is archived under DOI `10.5281/zenodo.21306969`; the tagged source baseline remains immutable.\n",
)

replace_once(
    "release/RELEASE_NOTES_v1.2.0.md",
    "## Archival status\n\nZenodo DOI: pending. The DOI and repository backlink must be added in a later citation-finalization patch after archival.\n",
    f"## Archival status\n\n"
    f"- Zenodo version DOI: [{DOI}]({DOI_URL})\n"
    f"- GitHub Release: [v1.2.0]({RELEASE})\n"
    f"- Source repository: [{REPOSITORY}]({REPOSITORY})\n"
    f"- License: MIT\n"
    f"- Archival date: 2026-07-11\n\n"
    f"The DOI, repository backlink, and citation metadata are finalized. "
    f"The `v1.2.0` tag remains immutable.\n",
)

verify_closure = f'''from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOI = "{DOI}"
DOI_URL = "https://doi.org/" + DOI
REPOSITORY = "{REPOSITORY}"
RELEASE = REPOSITORY + "/releases/tag/v1.2.0"

manifest = json.loads((ROOT / "release" / "bootstrap_manifest.json").read_text(encoding="utf-8"))
versions = json.loads((ROOT / "release" / "compiler_versions.json").read_text(encoding="utf-8"))
readme = (ROOT / "README.md").read_text(encoding="utf-8")
changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
citation = (ROOT / "CITATION.cff").read_text(encoding="utf-8")
release_notes = (ROOT / "release" / "RELEASE_NOTES_v1.2.0.md").read_text(encoding="utf-8")
theorems = (ROOT / "docs" / "theorem_register.md").read_text(encoding="utf-8")

assert manifest["semantic_version"] == "v1.2.0"
assert manifest["status"] == "DUAL_BACKEND_ACCEPTED"
assert re.fullmatch(r"[0-9a-f]{{40}}", manifest["git_commit"])
assert "pending" not in manifest["lean_version"].lower()
assert "pending" not in manifest["coq_version"].lower()

assert versions["ci_status"] == {{
    "coq": "PASS",
    "lean4": "PASS",
    "python_checker": "PASS",
    "release_readiness": "PASS",
    "schema_validation": "PASS",
}}

assert "DUAL-BACKEND COMPILER-PASSED" in readme
assert DOI in readme
assert DOI_URL in readme
assert RELEASE in readme
assert "DOI: pending" not in readme

assert "## [1.2.0]" in changelog
assert DOI in changelog

assert 'version: "1.2.0"' in citation
assert f'doi: "{{DOI}}"' in citation
assert f'repository-code: "{{REPOSITORY}}"' in citation
assert f'repository-artifact: "{{RELEASE}}"' in citation

assert DOI in release_notes
assert RELEASE in release_notes
assert "Zenodo DOI: pending" not in release_notes

for theorem_id in range(121, 127):
    assert f"T{{theorem_id}}" in theorems

assert theorems.count("compiled") >= 12
print("PASS: v1.2.0 compiler-passed closure and DOI citation metadata verified.")
'''
(ROOT / "scripts" / "verify_closure.py").write_text(verify_closure, encoding="utf-8")
print("UPDATED: scripts/verify_closure.py")
PY

python scripts/build_manifest.py
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_manifest.py
python scripts/verify_closure.py

( cd lean && lake build )
( cd coq && make )

git diff --check
git status --short
git diff --stat

git add README.md CITATION.cff CHANGELOG.md \
  release/RELEASE_NOTES_v1.2.0.md \
  release/bootstrap_manifest.json \
  scripts/verify_closure.py

git commit -m "Finalize v1.2.0 DOI and citation metadata"
git push origin main

if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
  gh release edit v1.2.0 \
    --title "V0 OSAP v1.2.0 — Compiler-Passed FC-1 Baseline" \
    --notes-file release/RELEASE_NOTES_v1.2.0.md
else
  echo "NOTICE: GitHub Release notes were not edited because gh authentication was unavailable."
fi

echo
echo "FINAL STATUS"
git status --short
git log -1 --oneline
