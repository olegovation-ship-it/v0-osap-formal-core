#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path.cwd()


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8')


def replace_once(path: str, old: str, new: str) -> None:
    text = read(path)
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f'Patch anchor missing in {path}: {old[:80]!r}')
    write(path, text.replace(old, new, 1))


def load_json(path: str) -> Any:
    return json.loads(read(path))


def dump_json(path: str, value: Any) -> None:
    write(path, json.dumps(value, indent=2, ensure_ascii=True) + '\n')


# Version line.
replace_once('pyproject.toml', 'version = "0.2.0.dev1"', 'version = "0.3.0.dev1"')
replace_once('checker/v0_osap_fc1/__init__.py', '__version__ = "0.2.0.dev1"', '__version__ = "0.3.0.dev1"')

# Schema additions.
schema_path = 'schemas/v1.1/registry_state.schema.json'
schema = load_json(schema_path)
identifier = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,127}$'}
id_array = {'type': 'array', 'items': identifier, 'uniqueItems': True}
schema['properties']['compatibility_constraints']['items'] = {
    'type': 'object', 'additionalProperties': False,
    'required': ['constraint_id', 'left_register_id', 'right_register_id', 'relation', 'enabled'],
    'properties': {
        'constraint_id': identifier, 'left_register_id': identifier, 'right_register_id': identifier,
        'relation': {'const': 'incompatible'}, 'context_policy': {'type': 'string'},
        'enabled': {'type': 'boolean'},
    },
}
schema['properties']['protocols']['items'] = {
    'type': 'object', 'additionalProperties': False,
    'required': ['protocol_id', 'prerequisite_register_ids', 'enabled'],
    'properties': {
        'protocol_id': identifier, 'prerequisite_register_ids': id_array,
        'enabled': {'type': 'boolean'}, 'metadata': {'type': 'object'},
    },
}
claim_props = {
    'claim_id': identifier, 'kind': {'type': 'string'}, 'carrier_id': identifier,
    'register_id': identifier, 'context_id': identifier, 'source_claim_id': identifier,
    'family_id': identifier, 'selected_register_id': identifier,
    'seed_register_ids': id_array, 'computed_closure_register_ids': id_array,
    'active_register_ids': id_array, 'protocol_id': identifier,
    'readiness_status': {'enum': ['READY_VALUE', 'UNDEFINED_DOMAIN', 'NOT_READY']},
    'dimension_status': {'enum': ['READY_VALUE', 'UNDEFINED_DOMAIN']},
    'numeric_value': {'type': 'number'}, 'residual_register_ids': id_array,
    'internal_support_ids': id_array, 'external_evidence_ids': id_array,
    'independence_group_ids': id_array,
}
requirements = {
    'prerequisite_closure': ['claim_id', 'kind', 'seed_register_ids', 'computed_closure_register_ids'],
    'one_of_support_selection': ['claim_id', 'kind', 'family_id', 'selected_register_id', 'carrier_id', 'context_id'],
    'activation_profile': ['claim_id', 'kind', 'carrier_id', 'context_id', 'active_register_ids'],
    'protocol_readiness': ['claim_id', 'kind', 'protocol_id', 'carrier_id', 'context_id', 'readiness_status'],
    'dimension_result': ['claim_id', 'kind', 'protocol_id', 'dimension_status'],
}
claim_schema = {'type': 'object', 'properties': claim_props, 'allOf': []}
for kind, required in requirements.items():
    claim_schema['allOf'].append({
        'if': {'properties': {'kind': {'const': kind}}, 'required': ['kind']},
        'then': {'required': required},
    })
schema['properties']['claims']['items'] = claim_schema
dump_json(schema_path, schema)
write('schemas/v1.1/ERRATA_PHASE2.md', '''# FC-1 v1.1 Phase 2 schema addendum

Status: `PATCH_READY / CI_PENDING`.

This addendum defines explicit records for compatibility constraints, protocols,
prerequisite closures, one-of support selection, activation profiles, readiness,
and typed dimension results. It applies only to the v1.3.0 development line.
''')

# Python semantics.
semantic_path = 'checker/v0_osap_fc1/semantic.py'
semantic = read(semantic_path)
helper_anchor = '\n\ndef check_registry(registry: dict[str, Any]) -> dict[str, Any]:'
helper_code = r'''

# V0_OSAP_PHASE2_T127_T132
def _enabled_family_map(families: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {
        str(family.get("family_id")): family
        for family in families
        if isinstance(family, dict) and family.get("enabled", False) and family.get("family_id")
    }


def _least_prerequisite_closure(
    seed_register_ids: Iterable[str],
    families: list[dict[str, Any]],
    selected_by_family: dict[str, str],
) -> list[str]:
    closure = {str(register) for register in seed_register_ids}
    changed = True
    while changed:
        changed = False
        for family in families:
            if not isinstance(family, dict) or not family.get("enabled", False):
                continue
            target = str(family.get("target_register_id"))
            if target not in closure:
                continue
            if family.get("mode") == "all_of":
                additions = [str(item) for item in family.get("prerequisite_register_ids", [])]
            elif family.get("mode") == "one_of":
                selected = selected_by_family.get(str(family.get("family_id")))
                additions = [selected] if selected else []
            else:
                additions = []
            before = len(closure)
            closure.update(item for item in additions if item)
            changed = changed or len(closure) != before
    return sorted(closure)


def _matching_live_token(
    tokens: list[dict[str, Any]], carrier: str, register: str, context: str
) -> bool:
    return _has_partition(tokens, carrier, register, context, {"live"})
'''
if 'def _least_prerequisite_closure(' not in semantic:
    if helper_anchor not in semantic:
        raise RuntimeError('semantic helper anchor missing')
    semantic = semantic.replace(helper_anchor, helper_code + helper_anchor, 1)
old_locals = '    evidence = registry.get("evidence_objects", [])\n    contexts = set(registry.get("contexts", []))\n'
new_locals = old_locals + '    compatibility_constraints = registry.get("compatibility_constraints", [])\n    protocols = registry.get("protocols", [])\n'
if 'compatibility_constraints = registry.get(' not in semantic:
    if old_locals not in semantic:
        raise RuntimeError('semantic local anchor missing')
    semantic = semantic.replace(old_locals, new_locals, 1)
phase2_logic = r'''
    # Phase 2: T127-T132 theorem expansion.
    family_map = _enabled_family_map(families)
    protocol_map = {
        str(protocol.get("protocol_id")): protocol
        for protocol in protocols
        if isinstance(protocol, dict) and protocol.get("enabled", False) and protocol.get("protocol_id")
    }

    selection_claims = [
        claim for claim in claims
        if isinstance(claim, dict) and claim.get("kind") == "one_of_support_selection"
    ]
    selected_by_family: dict[str, str] = {}
    selection_keys: set[tuple[str, str, str]] = set()
    for claim in selection_claims:
        family_id = str(claim.get("family_id"))
        selected = str(claim.get("selected_register_id"))
        carrier = str(claim.get("carrier_id"))
        context = str(claim.get("context_id"))
        family = family_map.get(family_id)
        valid = (
            family is not None
            and family.get("mode") == "one_of"
            and selected in [str(item) for item in family.get("prerequisite_register_ids", [])]
            and _matching_live_token(tokens, carrier, selected, context)
        )
        if not valid:
            diagnostics.append(Diagnostic(
                "INVALID_ALTERNATIVE_SUPPORT_SELECTION", "REJECT", 90,
                "A one_of selection must name a live member of an enabled one_of family.",
                "/claims", tuple(str(x) for x in [claim.get("claim_id"), family_id, selected, carrier, context]),
            ))
        else:
            selected_by_family[family_id] = selected
            selection_keys.add((family_id, carrier, context))

    for family in family_map.values():
        if family.get("mode") != "one_of":
            continue
        family_id = str(family.get("family_id"))
        target = str(family.get("target_register_id"))
        for token in tokens:
            if not isinstance(token, dict) or token.get("partition") != "live":
                continue
            if str(token.get("register_id")) != target:
                continue
            carrier = str(token.get("carrier_id"))
            context = str(token.get("context_id"))
            if (family_id, carrier, context) not in selection_keys:
                diagnostics.append(Diagnostic(
                    "ALTERNATIVE_SUPPORT_SELECTION_REQUIRED", "REJECT", 89,
                    "A live enabled one_of obligation requires an explicit selected support member.",
                    "/prerequisite_families", (family_id, carrier, target, context),
                ))

    for claim in claims:
        if not isinstance(claim, dict):
            continue
        kind = claim.get("kind")
        path = "/claims"
        if kind == "prerequisite_closure":
            expected = _least_prerequisite_closure(claim.get("seed_register_ids", []), families, selected_by_family)
            declared = sorted({str(item) for item in claim.get("computed_closure_register_ids", [])})
            if declared != expected:
                diagnostics.append(Diagnostic(
                    "PREREQUISITE_CLOSURE_NOT_LEAST", "REJECT", 90,
                    "The declared prerequisite closure differs from the least generated closure.",
                    path, tuple(str(x) for x in [claim.get("claim_id"), *declared, *expected]),
                ))
        elif kind == "activation_profile":
            carrier = str(claim.get("carrier_id"))
            context = str(claim.get("context_id"))
            active = {str(item) for item in claim.get("active_register_ids", [])}
            for register in sorted(active):
                if not _matching_live_token(tokens, carrier, register, context):
                    diagnostics.append(Diagnostic(
                        "ACTIVE_PROFILE_REGISTER_NOT_LIVE", "REJECT", 84,
                        "Every register declared active must have a matching live token.",
                        path, (str(claim.get("claim_id")), carrier, register, context),
                    ))
            for constraint in compatibility_constraints:
                if not isinstance(constraint, dict) or not constraint.get("enabled", False):
                    continue
                if constraint.get("relation") != "incompatible":
                    continue
                left = str(constraint.get("left_register_id"))
                right = str(constraint.get("right_register_id"))
                if left in active and right in active:
                    diagnostics.append(Diagnostic(
                        "COMPATIBILITY_CONSTRAINT_VIOLATION", "REJECT", 90,
                        "An activation profile jointly activates an incompatible register pair.",
                        path, tuple(str(x) for x in [claim.get("claim_id"), constraint.get("constraint_id"), left, right]),
                    ))
        elif kind == "protocol_readiness" and claim.get("readiness_status") == "READY_VALUE":
            protocol_id = str(claim.get("protocol_id"))
            protocol = protocol_map.get(protocol_id)
            carrier = str(claim.get("carrier_id"))
            context = str(claim.get("context_id"))
            missing = [protocol_id] if protocol is None else [
                str(register) for register in protocol.get("prerequisite_register_ids", [])
                if not _matching_live_token(tokens, carrier, str(register), context)
            ]
            if missing:
                diagnostics.append(Diagnostic(
                    "PROTOCOL_READY_WITHOUT_LIVE_PREREQUISITES", "REJECT", 90,
                    "READY_VALUE requires every protocol prerequisite to be live.",
                    path, tuple(str(x) for x in [claim.get("claim_id"), protocol_id, *missing]),
                ))
        elif kind == "dimension_result":
            status = claim.get("dimension_status")
            has_numeric = "numeric_value" in claim
            if status == "UNDEFINED_DOMAIN" and has_numeric:
                diagnostics.append(Diagnostic(
                    "UNDEFINED_DOMAIN_COERCED_TO_NUMERIC", "REJECT", 90,
                    "UNDEFINED_DOMAIN cannot carry a numeric value, including zero.",
                    path, (str(claim.get("claim_id")), str(claim.get("protocol_id"))),
                ))
            elif status == "READY_VALUE" and not has_numeric:
                diagnostics.append(Diagnostic(
                    "READY_VALUE_MISSING_NUMERIC", "REJECT", 85,
                    "READY_VALUE requires an explicit numeric result.",
                    path, (str(claim.get("claim_id")), str(claim.get("protocol_id"))),
                ))
'''
claims_anchor = '    claims_by_id = {c.get("claim_id"): c for c in claims if isinstance(c, dict) and c.get("claim_id")}'
if 'Phase 2: T127-T132 theorem expansion.' not in semantic:
    if claims_anchor not in semantic:
        raise RuntimeError('semantic claims anchor missing')
    semantic = semantic.replace(claims_anchor, phase2_logic + '\n' + claims_anchor, 1)
semantic = semantic.replace('"implementation_version": "v0-osap-fc1/0.2.0.dev1"', '"implementation_version": "v0-osap-fc1/0.3.0.dev1"')
write(semantic_path, semantic)

# Phase 1 verifier must remain Phase-1-scoped while allowing a later dev version.
phase1 = read('scripts/verify_phase1_alignment.py')
phase1 = phase1.replace(
    'assert \'"implementation_version": "v0-osap-fc1/0.2.0.dev1"\' in semantic',
    'assert any(version in semantic for version in (\n    \'"implementation_version": "v0-osap-fc1/0.2.0.dev1"\',\n    \'"implementation_version": "v0-osap-fc1/0.3.0.dev1"\',\n))',
)
old_docs = '''closure_docs = [
    "README.md",
    "docs/status_and_nonclaims.md",
    "docs/theorem_register.md",
    "release/v1.3.0/PHASE1_ACCEPTANCE_GATES.md",
    "release/v1.3.0/PHASE1_SEMANTIC_ALIGNMENT_REPORT.md",
    "release/v1.3.0/PHASE1_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
]
'''
new_docs = '''closure_docs = [
    "release/v1.3.0/PHASE1_ACCEPTANCE_GATES.md",
    "release/v1.3.0/PHASE1_SEMANTIC_ALIGNMENT_REPORT.md",
    "release/v1.3.0/PHASE1_CI_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md",
]
'''
if old_docs in phase1:
    phase1 = phase1.replace(old_docs, new_docs, 1)
write('scripts/verify_phase1_alignment.py', phase1)

# Fixtures.
def evidence() -> dict[str, Any]:
    return {
        'schema_version': 'v1.1', 'evidence_id': 'ev:phase2', 'evidence_type': 'fixture_oracle',
        'evidence_level': 'E0_SPECIFIED', 'produced_by': 'V0_OSAP_v1_3_0_phase2',
        'supports_claim_ids': [], 'limitations': ['Finite Phase 2 theorem-target fixture.'], 'metadata': {},
    }


def base_registry(state_id: str) -> dict[str, Any]:
    return {
        'schema_version': 'v1.1', 'language_version': 'FC-1-v1.1', 'registry_state_id': state_id,
        'declarations': [
            {'id': 'sector:S', 'sort': 'Sector'}, {'id': 'reg:A', 'sort': 'Register'},
            {'id': 'reg:B', 'sort': 'Register'}, {'id': 'reg:C', 'sort': 'Register'},
            {'id': 'ctx:C', 'sort': 'Context'}, {'id': 'ev:phase2', 'sort': 'Evidence'},
        ],
        'contexts': ['ctx:C'], 'tokens': [], 'prerequisite_families': [],
        'compatibility_constraints': [], 'protocols': [], 'residual_links': [],
        'observers': [], 'branches': [], 'evidence_objects': [evidence()], 'claims': [],
        'metadata': {'fixture': True, 'phase': 2},
    }


def live(register: str) -> dict[str, Any]:
    suffix = register.split(':')[-1]
    return {'token_id': f'tok:{suffix}:live', 'carrier_id': 'sector:S', 'register_id': register,
            'context_id': 'ctx:C', 'partition': 'live', 'introduced_in': 'state:phase2',
            'source_evidence_id': 'ev:phase2'}


def historical(register: str) -> dict[str, Any]:
    suffix = register.split(':')[-1]
    return {'token_id': f'tok:{suffix}:historical', 'carrier_id': 'sector:S', 'register_id': register,
            'context_id': 'ctx:C', 'partition': 'historical', 'introduced_in': 'state:prior',
            'moved_in': 'state:phase2', 'source_evidence_id': 'ev:phase2'}


def add_fixture(stem: str, kind: str, theorem: str, registry: dict[str, Any], status: str, diagnostics: list[str], oracle: str) -> None:
    folder = f'fixtures/{kind}'
    dump_json(f'{folder}/{stem}.registry.json', registry)
    dump_json(f'{folder}/{stem}.fixture.json', {
        'schema_version': 'v1.1', 'fixture_id': f'fixture:{kind}:{stem}', 'kind': kind,
        'semantic_version': 'FC-1-v1.1+phase2', 'input_file': f'{stem}.registry.json',
        'expected_status': status, 'expected_diagnostics': diagnostics, 'theorem_targets': [theorem],
        'bound': 1, 'oracle_source': oracle,
    })

# T127 pair.
r = base_registry('state:positive:t127')
r['prerequisite_families'] = [{'family_id': 'family:A', 'target_register_id': 'reg:A', 'mode': 'all_of',
    'prerequisite_register_ids': ['reg:B', 'reg:C'], 'context_policy': 'same_context',
    'evidence_ids': ['ev:phase2'], 'enabled': True}]
r['claims'] = [{'claim_id': 'claim:t127', 'kind': 'prerequisite_closure', 'seed_register_ids': ['reg:A'],
                'computed_closure_register_ids': ['reg:A', 'reg:B', 'reg:C']}]
add_fixture('t127_closure_minimality', 'positive', 'T127', r, 'PASS', [], 'Least closure includes every all_of prerequisite.')
r = json.loads(json.dumps(r)); r['registry_state_id'] = 'state:negative:t127'; r['claims'][0]['computed_closure_register_ids'] = ['reg:A', 'reg:B']
add_fixture('t127_nonminimal_closure', 'negative', 'T127', r, 'REJECT', ['PREREQUISITE_CLOSURE_NOT_LEAST'], 'Closure omits reg:C.')

# T128 pair.
r = base_registry('state:positive:t128'); r['tokens'] = [live('reg:A'), live('reg:B')]
r['prerequisite_families'] = [{'family_id': 'family:A', 'target_register_id': 'reg:A', 'mode': 'one_of',
    'prerequisite_register_ids': ['reg:B', 'reg:C'], 'context_policy': 'same_context',
    'evidence_ids': ['ev:phase2'], 'enabled': True}]
r['claims'] = [{'claim_id': 'claim:t128', 'kind': 'one_of_support_selection', 'family_id': 'family:A',
                'selected_register_id': 'reg:B', 'carrier_id': 'sector:S', 'context_id': 'ctx:C'}]
add_fixture('t128_alternative_support_transparency', 'positive', 'T128', r, 'PASS', [], 'Selected live support reg:B is recorded.')
r = json.loads(json.dumps(r)); r['registry_state_id'] = 'state:negative:t128'; r['claims'] = []
add_fixture('t128_missing_support_selection', 'negative', 'T128', r, 'REJECT', ['ALTERNATIVE_SUPPORT_SELECTION_REQUIRED'], 'Satisfied one_of has no selected member record.')

# T129 pair.
r = base_registry('state:positive:t129'); r['tokens'] = [live('reg:A')]
r['compatibility_constraints'] = [{'constraint_id': 'compat:A:B', 'left_register_id': 'reg:A', 'right_register_id': 'reg:B',
    'relation': 'incompatible', 'context_policy': 'same_context', 'enabled': True}]
r['claims'] = [{'claim_id': 'claim:t129', 'kind': 'activation_profile', 'carrier_id': 'sector:S',
                'context_id': 'ctx:C', 'active_register_ids': ['reg:A']}]
add_fixture('t129_compatibility_preservation', 'positive', 'T129', r, 'PASS', [], 'Profile has no incompatible pair.')
r = json.loads(json.dumps(r)); r['registry_state_id'] = 'state:negative:t129'; r['tokens'] = [live('reg:A'), live('reg:B')]; r['claims'][0]['active_register_ids'] = ['reg:A', 'reg:B']
add_fixture('t129_incompatible_profile', 'negative', 'T129', r, 'REJECT', ['COMPATIBILITY_CONSTRAINT_VIOLATION'], 'Profile activates incompatible A and B.')

# T130 pair.
r = base_registry('state:positive:t130'); r['tokens'] = [live('reg:A'), live('reg:B')]
r['protocols'] = [{'protocol_id': 'protocol:dimension', 'prerequisite_register_ids': ['reg:A', 'reg:B'], 'enabled': True, 'metadata': {}}]
r['claims'] = [{'claim_id': 'claim:t130', 'kind': 'protocol_readiness', 'protocol_id': 'protocol:dimension',
                'carrier_id': 'sector:S', 'context_id': 'ctx:C', 'readiness_status': 'READY_VALUE'}]
add_fixture('t130_dimensional_readiness', 'positive', 'T130', r, 'PASS', [], 'All protocol prerequisites are live.')
r = json.loads(json.dumps(r)); r['registry_state_id'] = 'state:negative:t130'; r['tokens'] = [live('reg:A')]
add_fixture('t130_readiness_missing_prerequisite', 'negative', 'T130', r, 'REJECT', ['PROTOCOL_READY_WITHOUT_LIVE_PREREQUISITES'], 'reg:B is not live.')

# T131 pair.
r = base_registry('state:positive:t131'); r['protocols'] = [{'protocol_id': 'protocol:dimension', 'prerequisite_register_ids': [], 'enabled': True, 'metadata': {}}]
r['claims'] = [{'claim_id': 'claim:t131', 'kind': 'dimension_result', 'protocol_id': 'protocol:dimension', 'dimension_status': 'UNDEFINED_DOMAIN'}]
add_fixture('t131_undefined_is_not_zero', 'positive', 'T131', r, 'PASS', [], 'Undefined domain carries no numeric value.')
r = json.loads(json.dumps(r)); r['registry_state_id'] = 'state:negative:t131'; r['claims'][0]['numeric_value'] = 0
add_fixture('t131_undefined_coerced_to_zero', 'negative', 'T131', r, 'REJECT', ['UNDEFINED_DOMAIN_COERCED_TO_NUMERIC'], 'Undefined domain is incorrectly coerced to zero.')

# T132 pair.
r = base_registry('state:positive:t132'); r['tokens'] = [historical('reg:A')]
r['claims'] = [{'claim_id': 'claim:t132', 'kind': 'dle', 'carrier_id': 'sector:S', 'register_id': 'reg:A', 'context_id': 'ctx:C'}]
add_fixture('t132_dle_history_adequacy', 'positive', 'T132', r, 'PASS', [], 'DLE has historical evidence and no live token.')
r = json.loads(json.dumps(r)); r['registry_state_id'] = 'state:negative:t132'; r['tokens'] = []
add_fixture('t132_dle_without_history', 'negative', 'T132', r, 'REJECT', ['DLE_WITHOUT_HISTORICAL_SOURCE'], 'DLE has no prior evidence.')

manifest = load_json('fixtures/manifest.json')
phase2_paths = [
    'positive/t127_closure_minimality.fixture.json', 'negative/t127_nonminimal_closure.fixture.json',
    'positive/t128_alternative_support_transparency.fixture.json', 'negative/t128_missing_support_selection.fixture.json',
    'positive/t129_compatibility_preservation.fixture.json', 'negative/t129_incompatible_profile.fixture.json',
    'positive/t130_dimensional_readiness.fixture.json', 'negative/t130_readiness_missing_prerequisite.fixture.json',
    'positive/t131_undefined_is_not_zero.fixture.json', 'negative/t131_undefined_coerced_to_zero.fixture.json',
    'positive/t132_dle_history_adequacy.fixture.json', 'negative/t132_dle_without_history.fixture.json',
]
manifest['bundle_id'] = 'V0_OSAP_v1_3_0_phase2_fixture_corpus'
manifest['semantic_version'] = 'FC-1-v1.1+phase2'
for path in phase2_paths:
    if path not in manifest['fixtures']:
        manifest['fixtures'].append(path)
manifest['status'] = 'PHASE2_T127_T132_PATCH_ORACLE_SET'
manifest['notes'] = ['Phase 1 exact mappings are preserved.', 'T127-T132 each have a positive and decisive negative fixture.', 'Phase 2 remains BUILD_READY / CI_PENDING.']
dump_json('fixtures/manifest.json', manifest)

# Lean 4 expansion.
write('lean/V0OSAP/Expansion.lean', r'''import V0OSAP.Prerequisites
import V0OSAP.DLE

namespace V0OSAP

def ListSubset (left right : List Id) : Prop :=
  ∀ item, item ∈ left → item ∈ right

def PrerequisiteClosed (step : Id → Id → Prop) (registers : List Id) : Prop :=
  ∀ target prerequisite, target ∈ registers → step target prerequisite → prerequisite ∈ registers

structure ClosureCertificate (step : Id → Id → Prop) (seed closure : List Id) : Prop where
  seedIncluded : ListSubset seed closure
  closed : PrerequisiteClosed step closure
  least : ∀ candidate, ListSubset seed candidate → PrerequisiteClosed step candidate → ListSubset closure candidate

theorem T127_closure_minimality
    (step : Id → Id → Prop) (seed closure candidate : List Id)
    (certificate : ClosureCertificate step seed closure)
    (hSeed : ListSubset seed candidate)
    (hClosed : PrerequisiteClosed step candidate) :
    ListSubset closure candidate :=
  certificate.least candidate hSeed hClosed

structure AlternativeSupportSelection
    (registry : RegistryState) (carrier context : Id) (family : PrerequisiteFamily) : Prop where
  selectedRegisterId : Id
  selectedMember : selectedRegisterId ∈ family.prerequisiteRegisterIds
  selectedLive : LiveGuard registry carrier selectedRegisterId context

theorem T128_alternative_support_transparency
    (registry : RegistryState) (carrier context : Id) (family : PrerequisiteFamily)
    (selection : AlternativeSupportSelection registry carrier context family) :
    selection.selectedRegisterId ∈ family.prerequisiteRegisterIds ∧
      LiveGuard registry carrier selection.selectedRegisterId context :=
  ⟨selection.selectedMember, selection.selectedLive⟩

structure CompatibilityConstraint where
  leftRegisterId : Id
  rightRegisterId : Id

def CompatibilityPreserved
    (registry : RegistryState) (carrier context : Id)
    (constraints : List CompatibilityConstraint) : Prop :=
  ∀ constraint, constraint ∈ constraints →
    ¬ (LiveGuard registry carrier constraint.leftRegisterId context ∧
       LiveGuard registry carrier constraint.rightRegisterId context)

theorem T129_compatibility_preservation
    (registry : RegistryState) (carrier context : Id)
    (constraints : List CompatibilityConstraint)
    (h : CompatibilityPreserved registry carrier context constraints) :
    ∀ constraint, constraint ∈ constraints →
      ¬ (LiveGuard registry carrier constraint.leftRegisterId context ∧
         LiveGuard registry carrier constraint.rightRegisterId context) := h

structure ProtocolRecord where
  protocolId : Id
  prerequisiteRegisterIds : List Id

def ProtocolReady
    (registry : RegistryState) (carrier context : Id) (protocol : ProtocolRecord) : Prop :=
  AllPrerequisitesLive registry carrier context protocol.prerequisiteRegisterIds

theorem T130_dimensional_readiness_soundness
    (registry : RegistryState) (carrier context : Id) (protocol : ProtocolRecord)
    (h : ProtocolReady registry carrier context protocol) :
    AllPrerequisitesLive registry carrier context protocol.prerequisiteRegisterIds := h

inductive DimensionResult where
  | undefinedDomain
  | readyValue (value : Int)
  deriving DecidableEq, Repr

theorem T131_undefined_is_not_zero :
    DimensionResult.undefinedDomain ≠ DimensionResult.readyValue 0 := by
  intro h
  cases h

theorem T132_dle_history_adequacy
    (registry : RegistryState) (carrier register context : Id)
    (h : DomainLicenseExhausted registry carrier register context) :
    WasLive registry carrier register context ∧ NoLive registry carrier register context := h

end V0OSAP
''')
root_lean = read('lean/V0OSAP.lean')
if 'import V0OSAP.Expansion' not in root_lean:
    root_lean = root_lean.replace('import V0OSAP.Theorems', 'import V0OSAP.Expansion\nimport V0OSAP.Theorems')
write('lean/V0OSAP.lean', root_lean)
lean_theorems = read('lean/V0OSAP/Theorems.lean')
if 'import V0OSAP.Expansion' not in lean_theorems:
    lean_theorems = lean_theorems.replace('import V0OSAP.Branches', 'import V0OSAP.Branches\nimport V0OSAP.Expansion')
write('lean/V0OSAP/Theorems.lean', lean_theorems)

# Coq expansion.
write('coq/theories/Expansion.v', r'''From Coq Require Import String List ZArith.
From V0OSAP Require Import BasicTypes Registry Guards Prerequisites DLE.
Import ListNotations.
Open Scope string_scope.
Open Scope Z_scope.

Definition list_subset (left right : list string) : Prop :=
  forall item, In item left -> In item right.

Definition prerequisite_closed (step : string -> string -> Prop) (registers : list string) : Prop :=
  forall target prerequisite, In target registers -> step target prerequisite -> In prerequisite registers.

Definition closure_certificate (step : string -> string -> Prop) (seed closure : list string) : Prop :=
  list_subset seed closure /\ prerequisite_closed step closure /\
  forall candidate, list_subset seed candidate -> prerequisite_closed step candidate -> list_subset closure candidate.

Theorem T127_closure_minimality :
  forall step seed closure candidate,
    closure_certificate step seed closure -> list_subset seed candidate ->
    prerequisite_closed step candidate -> list_subset closure candidate.
Proof. intros step seed closure candidate Hcert Hseed Hclosed. destruct Hcert as [_ [_ Hleast]]. exact (Hleast candidate Hseed Hclosed). Qed.

Theorem T128_alternative_support_transparency :
  forall registry carrier context prerequisites selected,
    In selected prerequisites -> live_guard registry carrier selected context ->
    In selected prerequisites /\ live_guard registry carrier selected context.
Proof. intros. split; assumption. Qed.

Record compatibility_constraint := { left_register_id : string; right_register_id : string }.
Definition compatibility_preserved (registry : registry_state) (carrier context : string)
    (constraints : list compatibility_constraint) : Prop :=
  forall constraint, In constraint constraints ->
    ~ (live_guard registry carrier (left_register_id constraint) context /\
       live_guard registry carrier (right_register_id constraint) context).

Theorem T129_compatibility_preservation :
  forall registry carrier context constraints,
    compatibility_preserved registry carrier context constraints ->
    forall constraint, In constraint constraints ->
      ~ (live_guard registry carrier (left_register_id constraint) context /\
         live_guard registry carrier (right_register_id constraint) context).
Proof. intros registry carrier context constraints H constraint Hin. exact (H constraint Hin). Qed.

Record protocol_record := { protocol_id : string; protocol_prerequisite_register_ids : list string }.
Definition protocol_ready (registry : registry_state) (carrier context : string) (protocol : protocol_record) : Prop :=
  all_prerequisites_live registry carrier context (protocol_prerequisite_register_ids protocol).

Theorem T130_dimensional_readiness_soundness :
  forall registry carrier context protocol,
    protocol_ready registry carrier context protocol ->
    all_prerequisites_live registry carrier context (protocol_prerequisite_register_ids protocol).
Proof. intros. exact H. Qed.

Inductive dimension_result : Type := UndefinedDomain | ReadyValue (value : Z).
Theorem T131_undefined_is_not_zero : UndefinedDomain <> ReadyValue 0.
Proof. discriminate. Qed.

Theorem T132_dle_history_adequacy :
  forall registry carrier register context,
    domain_license_exhausted registry carrier register context ->
    was_live registry carrier register context /\ no_live registry carrier register context.
Proof. intros. exact H. Qed.
''')
coq_project = read('coq/_CoqProject')
if 'theories/Expansion.v' not in coq_project:
    coq_project = coq_project.replace('theories/Branches.v\n', 'theories/Branches.v\ntheories/Expansion.v\n')
write('coq/_CoqProject', coq_project)
coq_theorems = read('coq/theories/Theorems.v')
coq_theorems = coq_theorems.replace('BasicTypes Registry Guards Prerequisites DLE Residuals Observer Branches.', 'BasicTypes Registry Guards Prerequisites DLE Residuals Observer Branches Expansion.')
coq_theorems = coq_theorems.replace('T121-T126', 'T121-T132')
write('coq/theories/Theorems.v', coq_theorems)

# Crosswalk.
records = [
    ('T127','closure_minimality','Computed closure is the least prerequisite-closed superset.','ClosureCertificate(step,seed,closure) and closed candidate imply closure subset candidate.','least prerequisite fixed-point equality',['PREREQUISITE_CLOSURE_NOT_LEAST']),
    ('T128','alternative_support_transparency','Every accepted one_of obligation records its selected family member.','Selected member and live support imply transparent support selection.','explicit one_of support selection',['ALTERNATIVE_SUPPORT_SELECTION_REQUIRED','INVALID_ALTERNATIVE_SUPPORT_SELECTION']),
    ('T129','compatibility_preservation','Accepted activation profiles satisfy all enabled compatibility constraints.','CompatibilityPreserved implies no incompatible pair is jointly live.','incompatible pair exclusion',['COMPATIBILITY_CONSTRAINT_VIOLATION','ACTIVE_PROFILE_REGISTER_NOT_LIVE']),
    ('T130','dimensional_readiness_soundness','READY_VALUE implies all protocol prerequisites are active.','ProtocolReady implies AllPrerequisitesLive.','READY_VALUE prerequisite audit',['PROTOCOL_READY_WITHOUT_LIVE_PREREQUISITES']),
    ('T131','undefined_is_not_zero','UNDEFINED_DOMAIN cannot be coerced to a numeric dimension.','undefinedDomain differs from readyValue(0).','status/value disjointness',['UNDEFINED_DOMAIN_COERCED_TO_NUMERIC','READY_VALUE_MISSING_NUMERIC']),
    ('T132','dle_history_adequacy','Accepted DLE has prior live evidence and current no-license.','DomainLicenseExhausted implies WasLive and NoLive.','DLE history/current-state audit',['DLE_WITHOUT_HISTORICAL_SOURCE','DLE_CONFLICTS_WITH_LIVE_TOKEN']),
]
rows = []
for theorem_id, name, natural, signature, rule, diagnostics in records:
    number = theorem_id[1:]
    row = {
        'theorem_id': theorem_id, 'canonical_name': name, 'natural_statement': natural,
        'formal_signature': signature,
        'assumptions': ['finite FC-1 records', 'explicit typed hypotheses'],
        'conclusion': natural,
        'lean_symbol': f'V0OSAP.T{number}_{name}', 'coq_symbol': f'T{number}_{name}',
        'validator_rule': rule, 'diagnostics': diagnostics,
        'fixtures': [f'fixture:positive:t{number}_{name}', f'fixture:negative:t{number}_countermodel'],
        'source_section': 'V0 OSAP v1.1 section 20',
        'claim_limitations': ['finite accepted fragment only'],
        'parity_status': 'PATCH_READY_CI_PENDING',
    }
    normalized = {key: row[key] for key in ['theorem_id','canonical_name','formal_signature','assumptions','conclusion']}
    row['canonical_statement_sha256'] = hashlib.sha256(json.dumps(normalized, sort_keys=True, separators=(',',':')).encode()).hexdigest()
    rows.append(row)
dump_json('release/v1.3.0/theorem_crosswalk_phase2.json', {
    'artifact_id': 'V0_OSAP_v1_3_0_phase2_theorem_crosswalk', 'artifact_version': '0.1',
    'baseline_tag': 'v1.2.0', 'baseline_doi': '10.5281/zenodo.21306969',
    'phase1_status': 'ACCEPTED_CI_PASS', 'phase2_status': 'BUILD_READY_CI_PENDING',
    'theorem_range': 'T127-T132', 'records': rows,
})

# Tests and verifier.
write('tests/test_phase2_expansion.py', '''from __future__ import annotations
from pathlib import Path
from v0_osap_fc1.fixtures import replay_fixture

ROOT = Path(__file__).resolve().parents[1]


def test_phase2_fixture_pairs_replay():
    names = [
        "positive/t127_closure_minimality", "negative/t127_nonminimal_closure",
        "positive/t128_alternative_support_transparency", "negative/t128_missing_support_selection",
        "positive/t129_compatibility_preservation", "negative/t129_incompatible_profile",
        "positive/t130_dimensional_readiness", "negative/t130_readiness_missing_prerequisite",
        "positive/t131_undefined_is_not_zero", "negative/t131_undefined_coerced_to_zero",
        "positive/t132_dle_history_adequacy", "negative/t132_dle_without_history",
    ]
    for name in names:
        result = replay_fixture(ROOT / f"fixtures/{name}.fixture.json")
        assert result["passed"], result
''')
write('scripts/verify_phase2_expansion.py', '''from __future__ import annotations
import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
load = lambda p: json.loads((ROOT / p).read_text(encoding="utf-8"))

crosswalk = load("release/v1.3.0/theorem_crosswalk_phase2.json")
assert crosswalk["theorem_range"] == "T127-T132"
assert crosswalk["phase1_status"] == "ACCEPTED_CI_PASS"
assert crosswalk["phase2_status"] == "BUILD_READY_CI_PENDING"
lean = (ROOT / "lean/V0OSAP/Expansion.lean").read_text(encoding="utf-8")
coq = (ROOT / "coq/theories/Expansion.v").read_text(encoding="utf-8")
semantic = (ROOT / "checker/v0_osap_fc1/semantic.py").read_text(encoding="utf-8")
assert [r["theorem_id"] for r in crosswalk["records"]] == [f"T{i}" for i in range(127,133)]
for row in crosswalk["records"]:
    normalized = {k: row[k] for k in ["theorem_id","canonical_name","formal_signature","assumptions","conclusion"]}
    expected = hashlib.sha256(json.dumps(normalized, sort_keys=True, separators=(",",":")).encode()).hexdigest()
    assert row["canonical_statement_sha256"] == expected
    assert row["lean_symbol"].split(".")[-1] in lean
    assert row["coq_symbol"] in coq
    assert row["parity_status"] == "PATCH_READY_CI_PENDING"
for code in ["PREREQUISITE_CLOSURE_NOT_LEAST","ALTERNATIVE_SUPPORT_SELECTION_REQUIRED","INVALID_ALTERNATIVE_SUPPORT_SELECTION","COMPATIBILITY_CONSTRAINT_VIOLATION","PROTOCOL_READY_WITHOUT_LIVE_PREREQUISITES","UNDEFINED_DOMAIN_COERCED_TO_NUMERIC"]:
    assert code in semantic
manifest = load("fixtures/manifest.json")
assert manifest["semantic_version"] == "FC-1-v1.1+phase2"
workflow = (ROOT / ".github/workflows/release-readiness.yml").read_text(encoding="utf-8")
for command in ["python scripts/verify_phase1_alignment.py","python scripts/verify_phase2_expansion.py","python scripts/verify_manifest.py","python scripts/verify_closure.py"]:
    assert command in workflow
assert 'version = "0.3.0.dev1"' in (ROOT / "pyproject.toml").read_text(encoding="utf-8")
assert '"implementation_version": "v0-osap-fc1/0.3.0.dev1"' in semantic
print("PASS: V0 OSAP v1.3.0 Phase 2 T127-T132 patch verified statically.")
''')

# Release documents.
spec_source = Path(__file__).with_name('V0_OSAP_v1.3.0_Phase_2_Build_Specification_and_Implementation_Patch_v0.1.md')
write('release/v1.3.0/PHASE2_BUILD_SPECIFICATION.md', spec_source.read_text(encoding='utf-8'))
write('release/v1.3.0/PHASE2_ACCEPTANCE_GATES.md', '''# Phase 2 acceptance gates

Status: `BUILD_READY / CI_PENDING`.

Phase 2 covers T127-T132. Acceptance requires full Python tests, schema and fixture replay,
Phase 1 preservation, Phase 2 verification, proof-hole scan, Lean 4, Coq, release-readiness
historical checks, an all-green Actions matrix, and a dedicated CI-closure audit.

This patch does not release v1.3.0 or alter v1.2.0 / DOI 10.5281/zenodo.21306969.
''')
write('release/v1.3.0/PHASE2_IMPLEMENTATION_REPORT.md', '''# Phase 2 implementation report

Status: `PATCH_READY / CI_PENDING`
Date: 2026-07-11
Theorem range: T127-T132

The patch adds typed schema records, deterministic Python rules and diagnostics,
twelve paired fixtures, Lean 4 and Coq expansion modules, a statement-hash crosswalk,
Phase 2 tests, and release-readiness integration.

It is not a v1.3.0 release and makes no theorem-completeness, proof-identity, checker-completeness,
empirical, physical, or cosmological claim.
''')

# README / changelog / status / theorem register.
readme = read('README.md')
phase2 = '''## v1.3.0 development status

> **PHASE 2 T127-T132 EXPANSION - PATCH READY / CI PENDING**

Phase 2 adds T127 closure minimality, T128 one_of support transparency,
T129 compatibility preservation, T130 dimensional readiness, T131 undefined-domain
separation from numeric zero, and T132 DLE history adequacy. Checker version: `0.3.0.dev1`.

The patch includes twelve paired fixtures, Lean 4 and Coq expansion modules, and a
canonical statement-hash crosswalk. It is not yet an accepted or released v1.3.0 claim.
See `release/v1.3.0/PHASE2_ACCEPTANCE_GATES.md`.

### Phase 1 closed baseline

> **PHASE 1 SEMANTIC ALIGNMENT - ACCEPTED / CI PASS**'''
if 'PHASE 2 T127-T132 EXPANSION' not in readme:
    readme = readme.replace('## v1.3.0 development status\n\n> **PHASE 1 SEMANTIC ALIGNMENT — ACCEPTED / CI PASS**', phase2, 1)
if 'python scripts/verify_phase2_expansion.py' not in readme:
    readme = readme.replace('python scripts/verify_phase1_alignment.py\n', 'python scripts/verify_phase1_alignment.py\npython scripts/verify_phase2_expansion.py\n', 1)
write('README.md', readme)

changelog = read('CHANGELOG.md')
entry = '''## [Unreleased]

### Phase 2 theorem expansion T127-T132
- Added executable rules for closure, one_of support selection, compatibility, protocol readiness, typed dimensional results, and exact DLE history mapping.
- Added twelve paired fixtures and Lean 4 / Coq expansion modules.
- Added a statement-hash theorem crosswalk and Phase 2 verifier.
- Advanced the development checker to `0.3.0.dev1`.
- Status remains `PATCH_READY / CI_PENDING`; no v1.3.0 release is claimed.

'''
if '### Phase 2 theorem expansion T127-T132' not in changelog:
    changelog = changelog.replace('## [Unreleased]\n', entry, 1)
write('CHANGELOG.md', changelog)

status = read('docs/status_and_nonclaims.md')
if '## v1.3.0 Phase 2' not in status:
    status = status.replace('# Status and non-claims\n\n', '# Status and non-claims\n\n## v1.3.0 Phase 2\n\n- Scope: T127-T132.\n- Status: `PATCH_READY / CI_PENDING`.\n- Phase 1 remains accepted.\n- No release, theorem-completeness, proof-identity, or empirical claim.\n\n', 1)
write('docs/status_and_nonclaims.md', status)

register = read('docs/theorem_register.md')
if '## Phase 2 theorem expansion' not in register:
    register += '''\n## Phase 2 theorem expansion\n\n| ID | Canonical name | Python | Lean 4 | Coq | Status |\n|---|---|---|---|---|---|\n| T127 | Closure minimality | least closure | T127_closure_minimality | T127_closure_minimality | CI pending |\n| T128 | Alternative-support transparency | selected live member | T128_alternative_support_transparency | T128_alternative_support_transparency | CI pending |\n| T129 | Compatibility preservation | pair exclusion | T129_compatibility_preservation | T129_compatibility_preservation | CI pending |\n| T130 | Dimensional readiness soundness | readiness audit | T130_dimensional_readiness_soundness | T130_dimensional_readiness_soundness | CI pending |\n| T131 | Undefined is not zero | typed disjointness | T131_undefined_is_not_zero | T131_undefined_is_not_zero | CI pending |\n| T132 | DLE history adequacy | exact DLE fixtures | T132_dle_history_adequacy | T132_dle_history_adequacy | CI pending |\n'''
write('docs/theorem_register.md', register)

workflow = read('.github/workflows/release-readiness.yml')
if 'python scripts/verify_phase2_expansion.py' not in workflow:
    workflow = workflow.replace('      - run: python scripts/verify_phase1_alignment.py\n', '      - run: python scripts/verify_phase1_alignment.py\n      - run: python scripts/verify_phase2_expansion.py\n', 1)
write('.github/workflows/release-readiness.yml', workflow)

print('PATCH CONTENT GENERATED')
