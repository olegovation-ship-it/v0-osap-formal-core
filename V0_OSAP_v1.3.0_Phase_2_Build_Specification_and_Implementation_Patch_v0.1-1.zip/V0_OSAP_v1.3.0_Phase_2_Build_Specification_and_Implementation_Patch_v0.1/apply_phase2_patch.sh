#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="${1:-/workspaces/v0-osap-formal-core}"
BRANCH="v1.3.0-development"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$REPO_ROOT"
[[ "$(git branch --show-current)" == "$BRANCH" ]] || { echo "ERROR: current branch must be $BRANCH" >&2; exit 2; }
[[ -z "$(git status --porcelain)" ]] || { echo "ERROR: working tree is not clean" >&2; git status --short; exit 3; }
git pull --ff-only origin "$BRANCH"
python "$PACKAGE_DIR/patch_phase2.py"
python -m pip install -e '.[dev]'
pytest -q
v0-osap-fc1 schema-bundle
v0-osap-fc1 fixtures
python scripts/check_no_proof_holes.py
python scripts/verify_phase1_alignment.py
python scripts/verify_phase2_expansion.py
( cd lean && lake build )
( cd coq && make )
git diff --check
git status --short
git diff --stat
git add \
  .github/workflows/release-readiness.yml \
  CHANGELOG.md README.md pyproject.toml \
  checker/v0_osap_fc1/__init__.py checker/v0_osap_fc1/semantic.py \
  coq/_CoqProject coq/theories/Expansion.v coq/theories/Theorems.v \
  docs/status_and_nonclaims.md docs/theorem_register.md \
  fixtures \
  lean/V0OSAP.lean lean/V0OSAP/Expansion.lean lean/V0OSAP/Theorems.lean \
  release/v1.3.0 \
  schemas/v1.1/ERRATA_PHASE2.md schemas/v1.1/registry_state.schema.json \
  scripts/verify_phase1_alignment.py scripts/verify_phase2_expansion.py \
  tests/test_phase2_expansion.py
git commit -m "Build V0 OSAP v1.3.0 Phase 2 theorem expansion T127-T132"
git push origin "$BRANCH"
echo "PHASE 2 PATCH APPLIED AND PUSHED."
echo "Next: open a draft PR and wait for the complete Actions matrix."
