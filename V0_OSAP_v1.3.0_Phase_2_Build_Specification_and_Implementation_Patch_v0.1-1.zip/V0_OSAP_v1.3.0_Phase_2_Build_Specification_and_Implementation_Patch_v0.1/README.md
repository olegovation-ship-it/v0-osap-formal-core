# V0_OSAP_v1.3.0_Phase_2_Build_Specification_and_Implementation_Patch_v0.1

Target: `olegovation-ship-it/v0-osap-formal-core`, branch `v1.3.0-development`.

This package implements theorem targets T127-T132, runs the full local validation
matrix, commits, and pushes. It does not merge, release v1.3.0, move v1.2.0, or create a DOI.

## Codespaces command

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git pull --ff-only origin v1.3.0-development
PATCH_ZIP="$(find . -maxdepth 1 -type f -name 'V0_OSAP_v1.3.0_Phase_2_Build_Specification_and_Implementation_Patch_v0.1*.zip' | head -n 1)"
rm -rf /tmp/v0_phase2 && mkdir -p /tmp/v0_phase2
unzip -o "$PATCH_ZIP" -d /tmp/v0_phase2
bash /tmp/v0_phase2/V0_OSAP_v1.3.0_Phase_2_Build_Specification_and_Implementation_Patch_v0.1/apply_phase2_patch.sh
```
