# V0 OSAP v1.3.0 Final Release Evidence Closure and Historical Preservation Patch v0.1

This package records and validates the already-created stable annotated tag
`v1.3.0` and the already-published GitHub final release. It does not create,
move, replace, edit, retag, or republish either object.

## Apply

From a clean repository worktree after extracting the ZIP:

```bash
python /path/to/apply_v1_3_0_final_release_evidence_closure_patch.py   /workspaces/v0-osap-formal-core
```

The script verifies the live GitHub release and tag, captures machine-readable
evidence, creates the closure record/report/manifest/verifier/tests, updates
the status documents, historicalizes the preceding final-authorization
manifest replay, and runs the full Python regression suite.

## Resulting state

`FINAL_RELEASE_EVIDENCE_CLOSED / STABLE_TAG_CREATED / FINAL_GITHUB_RELEASE_CREATED / ZENODO_NOT_PUBLISHED`

Zenodo publication and DOI mutation remain unauthorized.
