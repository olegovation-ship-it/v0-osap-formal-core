#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

REPOSITORY = "olegovation-ship-it/v0-osap-formal-core"
FINAL_TAG = "v1.3.0"
FINAL_TARGET = "13bf095688bcabd5b090f188e9bd28a16237edeb"
FINAL_AUTHORIZATION_MERGE_COMMIT = "80911df7acdac7ff411b49dcced161b98ac2071"
RC1_TAG = "v1.3.0-rc1"
RC1_TARGET = "cf9a05b46b9b6f29cd85942f99155f89a49817a7"
IMMUTABLE_TAG = "v1.2.0"
IMMUTABLE_TARGET = "befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3"
IMMUTABLE_DOI = "10.5281/zenodo.21306969"
EXPECTED_RELEASE_NAME = "V0 OSAP v1.3.0 — Stable Release"
EXPECTED_RELEASE_URL = (
    "https://github.com/olegovation-ship-it/"
    "v0-osap-formal-core/releases/tag/v1.3.0"
)
EXPECTED_PUBLISHED_AT = "2026-07-13T21:40:22Z"
MACHINE_STATE = (
    "FINAL_RELEASE_EVIDENCE_CLOSED_STABLE_TAG_CREATED_"
    "FINAL_GITHUB_RELEASE_CREATED_ZENODO_NOT_PUBLISHED"
)
HUMAN_STATE = (
    "FINAL_RELEASE_EVIDENCE_CLOSED / STABLE_TAG_CREATED / "
    "FINAL_GITHUB_RELEASE_CREATED / ZENODO_NOT_PUBLISHED"
)

ROOT: Path
PACKAGE_ROOT = Path(__file__).resolve().parent
PAYLOAD = PACKAGE_ROOT / "payload"

def run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [*args], cwd=ROOT, text=True, capture_output=True, check=check
    )

def git(*args: str, check: bool = True) -> str:
    return run("git", *args, check=check).stdout.strip()

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"ERROR: {message}")

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def normalized_body(value: str) -> str:
    return value.replace("\r\n", "\n").strip()

def write_json(rel: str, value: Any) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )

def replace_marked(rel: str, begin: str, end: str, block: str) -> None:
    path = ROOT / rel
    text = path.read_text(encoding="utf-8")
    require(begin in text and end in text, f"status markers missing from {rel}")
    start = text.index(begin)
    finish = text.index(end, start) + len(end)
    path.write_text(
        text[:start] + block.rstrip() + text[finish:],
        encoding="utf-8",
        newline="\n",
    )

def remote_tag_map(tag: str) -> dict[str, str]:
    result: dict[str, str] = {}
    output = git(
        "ls-remote", "origin",
        f"refs/tags/{tag}", f"refs/tags/{tag}^{{}}"
    )
    for line in output.splitlines():
        sha, ref = line.split(maxsplit=1)
        result[ref] = sha
    return result

def copy_payload() -> None:
    for source in PAYLOAD.rglob("*"):
        if source.is_file():
            rel = source.relative_to(PAYLOAD)
            target = ROOT / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)

def capture_evidence() -> dict[str, Any]:
    require(git("cat-file", "-t", f"refs/tags/{FINAL_TAG}") == "tag",
            "v1.3.0 is not an annotated tag")
    local_object_sha = git("rev-parse", f"refs/tags/{FINAL_TAG}")
    peeled = git("rev-list", "-n", "1", FINAL_TAG)
    require(peeled == FINAL_TARGET, "stable tag target mismatch")
    remote = remote_tag_map(FINAL_TAG)
    require(
        remote.get(f"refs/tags/{FINAL_TAG}") == local_object_sha,
        "remote tag object SHA mismatch",
    )
    require(
        remote.get(f"refs/tags/{FINAL_TAG}^{{}}") == FINAL_TARGET,
        "remote peeled target mismatch",
    )

    view = json.loads(run(
        "gh", "release", "view", FINAL_TAG,
        "--repo", REPOSITORY,
        "--json",
        "tagName,name,isDraft,isPrerelease,publishedAt,url,targetCommitish,body",
    ).stdout)
    rows = json.loads(run(
        "gh", "release", "list",
        "--repo", REPOSITORY,
        "--limit", "100",
        "--json",
        "tagName,name,isDraft,isPrerelease,isLatest,publishedAt",
    ).stdout)
    matches = [row for row in rows if row["tagName"] == FINAL_TAG]
    require(len(matches) == 1, "final release is not uniquely listed")
    latest = matches[0]

    require(view["name"] == EXPECTED_RELEASE_NAME, "release name mismatch")
    require(view["url"] == EXPECTED_RELEASE_URL, "release URL mismatch")
    require(view["publishedAt"] == EXPECTED_PUBLISHED_AT, "timestamp mismatch")
    require(view["isDraft"] is False, "release is draft")
    require(view["isPrerelease"] is False, "release is prerelease")
    require(latest["isLatest"] is True, "release is not Latest")
    require(view["targetCommitish"] == "main", "targetCommitish is not main")

    notes = normalized_body(
        (ROOT / "release/v1.3.0/V1_3_0_GITHUB_FINAL_RELEASE_NOTES.md")
        .read_text(encoding="utf-8")
    )
    body = normalized_body(view["body"])
    require(body == notes, "published notes differ from authorized notes")

    return {
        "artifact_id": "V0_OSAP_V1_3_0_GITHUB_FINAL_RELEASE_EVIDENCE",
        "version": "0.1",
        "date": "2026-07-13",
        "repository": REPOSITORY,
        "authorization_merge_commit": FINAL_AUTHORIZATION_MERGE_COMMIT,
        "stable_tag": {
            "tagName": FINAL_TAG,
            "objectType": "tag",
            "localObjectSha": local_object_sha,
            "remoteObjectSha": remote[f"refs/tags/{FINAL_TAG}"],
            "peeledTargetCommit": peeled,
            "remotePeeledTargetCommit": remote[f"refs/tags/{FINAL_TAG}^{{}}"],
            "isAnnotated": True,
        },
        "release": {
            "tagName": view["tagName"],
            "name": view["name"],
            "url": view["url"],
            "publishedAt": view["publishedAt"],
            "targetCommitish": view["targetCommitish"],
            "isDraft": view["isDraft"],
            "isPrerelease": view["isPrerelease"],
            "isLatest": latest["isLatest"],
            "normalizedBodySha256": sha256_text(body),
        },
        "release_actions": {
            "stable_tag_created": True,
            "github_final_release_created": True,
            "zenodo_version_authorized": False,
            "zenodo_version_created": False,
            "doi_changed": False,
        },
    }

def main() -> int:
    global ROOT
    ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    require((ROOT / ".git").exists(), "target is not a Git repository")
    require(
        git("remote", "get-url", "origin").rstrip("/").endswith(REPOSITORY),
        "unexpected origin repository",
    )
    require(not git("status", "--porcelain"), "worktree must be clean")
    run("git", "fetch", "origin", "--tags", "--force")
    require(
        run(
            "git", "merge-base", "--is-ancestor",
            FINAL_AUTHORIZATION_MERGE_COMMIT, "HEAD", check=False
        ).returncode == 0,
        "final authorization merge commit is not an ancestor of HEAD",
    )
    require(git("rev-list", "-n", "1", RC1_TAG) == RC1_TARGET,
            "RC1 tag target changed")
    require(git("rev-list", "-n", "1", IMMUTABLE_TAG) == IMMUTABLE_TARGET,
            "v1.2.0 tag target changed")

    evidence = capture_evidence()
    frozen = {
        rel: sha256_file(ROOT / rel)
        for rel in (
            "release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_MANIFEST.json",
            "release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_RECORD.json",
            "release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_MANIFEST.json",
            "release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_RECORD.json",
        )
    }

    copy_payload()
    write_json(
        "release/v1.3.0/V1_3_0_GITHUB_FINAL_RELEASE_EVIDENCE.json",
        evidence,
    )
    write_json(
        "artifacts/v1_3_0_github_final_release_evidence.json",
        evidence,
    )
    record = {
        "artifact_id": "V0_OSAP_V1_3_0_FINAL_RELEASE_EVIDENCE_CLOSURE_RECORD",
        "version": "0.1",
        "date": "2026-07-13",
        "state": MACHINE_STATE,
        "human_state": HUMAN_STATE,
        "repository": REPOSITORY,
        "authorization_basis": {
            "final_release_authorization_pr": 16,
            "final_release_authorization_merge_commit":
                FINAL_AUTHORIZATION_MERGE_COMMIT,
            "exact_stable_target_commit": FINAL_TARGET,
            "frozen_historical_artifacts_sha256": frozen,
        },
        "stable_tag_evidence": evidence["stable_tag"],
        "github_final_release_evidence": evidence["release"],
        "candidate_scope": {
            "theorem_range": "T121-T156",
            "record_count": 36,
            "source_crosswalk_count": 6,
            "conditional_theorems": ["T140", "T150", "T156"],
            "checker_component_version": "0.7.0.dev1",
        },
        "release_actions": {
            "stable_tag_target_authorized": True,
            "stable_tag_created": True,
            "github_final_release_authorized": True,
            "github_final_release_created": True,
            "rc1_prerelease_modified": False,
            "zenodo_version_authorized": False,
            "zenodo_version_created": False,
            "doi_changed": False,
        },
        "immutable_history": {
            "tag": IMMUTABLE_TAG,
            "target_commit": IMMUTABLE_TARGET,
            "doi": IMMUTABLE_DOI,
        },
        "claim_boundary": {
            "checker_completeness_claimed": False,
            "unconditional_global_soundness_claimed": False,
            "proof_term_identity_claimed": False,
            "global_conservativity_claimed": False,
            "empirical_or_physical_validation_claimed": False,
            "cosmological_validation_claimed": False,
        },
    }
    write_json(
        "release/v1.3.0/V1_3_0_FINAL_RELEASE_EVIDENCE_CLOSURE_RECORD.json",
        record,
    )

    readme = f'''<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->
> **V0 OSAP v1.3.0 FINAL RELEASE EVIDENCE CLOSURE AND HISTORICAL PRESERVATION - {HUMAN_STATE}**

Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.

PR #16 merged final-release authorization at `{FINAL_AUTHORIZATION_MERGE_COMMIT}`. The stable annotated tag `{FINAL_TAG}` now exists and peels exactly to `{FINAL_TARGET}`.

The GitHub final release `{EXPECTED_RELEASE_NAME}` is published at `{EXPECTED_RELEASE_URL}` with publication time `{EXPECTED_PUBLISHED_AT}`, `isDraft=false`, `isPrerelease=false`, and `isLatest=true`.

This patch records external tag and release evidence, freezes the preceding authorization and RC1 evidence manifests by SHA-256, and installs validation-only historical replay. It does not create, move, replace, retag, edit, or republish a release object.

The embedded checker component remains `0.7.0.dev1` exactly as audited. Historical tag `{IMMUTABLE_TAG}`, target `{IMMUTABLE_TARGET}`, and DOI `{IMMUTABLE_DOI}` remain immutable. T140, T150, and T156 remain conditional. Zenodo publication and DOI mutation remain unauthorized.

See `release/v1.3.0/V1_3_0_FINAL_RELEASE_EVIDENCE_CLOSURE_AND_HISTORICAL_PRESERVATION_REPORT.md` and `release/v1.3.0/V1_3_0_FINAL_RELEASE_EVIDENCE_CLOSURE_ACCEPTANCE_GATES.md`.
<!-- V0_OSAP_RC1_GATE_AUDIT_END -->'''
    replace_marked(
        "README.md",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->",
        "<!-- V0_OSAP_RC1_GATE_AUDIT_END -->",
        readme,
    )
    readme_path = ROOT / "README.md"
    readme_text = readme_path.read_text(encoding="utf-8").replace(
        "## v1.3.0 development status",
        "## v1.3.0 release status",
        1,
    )
    readme_path.write_text(readme_text, encoding="utf-8", newline="\n")

    changelog = f'''<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->
## [v1.3.0] - 2026-07-13 — final release evidence closure and historical preservation

- Recorded annotated stable tag `{FINAL_TAG}` at exact peeled target `{FINAL_TARGET}`.
- Recorded final GitHub Release `{EXPECTED_RELEASE_NAME}`.
- Recorded release URL `{EXPECTED_RELEASE_URL}` and publication time `{EXPECTED_PUBLISHED_AT}`.
- Verified `isDraft=false`, `isPrerelease=false`, and `isLatest=true`.
- Frozen the final-release authorization and RC1 evidence artifacts by SHA-256.
- Historicalized the final-authorization manifest builder and verifier at merge commit `{FINAL_AUTHORIZATION_MERGE_COMMIT}`.
- Preserved RC1 tag `{RC1_TAG}`, immutable tag `{IMMUTABLE_TAG}`, target `{IMMUTABLE_TARGET}`, and DOI `{IMMUTABLE_DOI}`.
- Retained checker component `0.7.0.dev1`; T140, T150, and T156 remain conditional.
- Created no Zenodo version and made no DOI mutation.
- State: `{HUMAN_STATE}`.
<!-- V0_OSAP_RC1_CHANGELOG_END -->'''
    replace_marked(
        "CHANGELOG.md",
        "<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->",
        "<!-- V0_OSAP_RC1_CHANGELOG_END -->",
        changelog,
    )

    status = f'''<!-- V0_OSAP_RC1_STATUS_BEGIN -->
## v1.3.0 final release evidence closure and historical preservation

- Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.
- Status: `{HUMAN_STATE}`.
- Final-release authorization PR: #16; merge commit: `{FINAL_AUTHORIZATION_MERGE_COMMIT}`.
- Stable annotated tag `{FINAL_TAG}` peels exactly to `{FINAL_TARGET}`.
- Final GitHub Release: `{EXPECTED_RELEASE_NAME}`.
- Release URL: `{EXPECTED_RELEASE_URL}`.
- Published at: `{EXPECTED_PUBLISHED_AT}`.
- Release flags: `isDraft=false`, `isPrerelease=false`, `isLatest=true`.
- RC1 tag `{RC1_TAG}` remains pinned to `{RC1_TARGET}`.
- Embedded checker component remains `0.7.0.dev1` exactly as audited.
- T140, T150, and T156 remain conditional.
- Historical tag `{IMMUTABLE_TAG}` remains pinned to `{IMMUTABLE_TARGET}`.
- Historical DOI remains `{IMMUTABLE_DOI}`.
- Zenodo publication and DOI mutation remain unauthorized and unexecuted.
- No checker-completeness, unconditional global soundness, proof-term identity, global conservativity, empirical, physical, or cosmological claim is made.
<!-- V0_OSAP_RC1_STATUS_END -->'''
    replace_marked(
        "docs/status_and_nonclaims.md",
        "<!-- V0_OSAP_RC1_STATUS_BEGIN -->",
        "<!-- V0_OSAP_RC1_STATUS_END -->",
        status,
    )

    run("python", "scripts/build_v1_3_0_final_release_authorization_manifest.py")
    run("python", "scripts/build_v1_3_0_final_release_evidence_closure_manifest.py")
    run(
        "python", "scripts/verify_v1_3_0_final_release_authorization.py",
        "--require-tags", "--allow-stable-tag-created",
    )
    run(
        "python", "scripts/verify_v1_3_0_final_release_evidence_closure.py",
        "--require-tags", "--verify-live",
    )
    run("python", "-m", "pytest", "-q")
    run("git", "diff", "--check")

    print("PASS: V0 OSAP v1.3.0 final-release evidence closure applied.")
    print(f"State: {HUMAN_STATE}")
    print("No tag, release, Zenodo version, or DOI was created or changed.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
