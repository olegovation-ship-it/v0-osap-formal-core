from __future__ import annotations
import hashlib,json,re,shutil,subprocess,sys
from pathlib import Path
PACKAGE_ROOT=Path(__file__).resolve().parent; PAYLOAD=PACKAGE_ROOT/'payload'
FINAL_TARGET='13bf095688bcabd5b090f188e9bd28a16237edeb'; FINAL_TAG='v1.3.0'; RC1_TAG='v1.3.0-rc1'; RC1_TARGET='cf9a05b46b9b6f29cd85942f99155f89a49817a7'; IMMUTABLE_TAG='v1.2.0'; IMMUTABLE_TARGET='befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3'; DOI='10.5281/zenodo.21306969'; STATE='FINAL_RELEASE_AUTHORIZED / STABLE_TAG_NOT_CREATED / FINAL_GITHUB_RELEASE_NOT_CREATED / ZENODO_NOT_PUBLISHED'
def run(*args,cwd,check=True): return subprocess.run(args,cwd=cwd,check=check,text=True,capture_output=True)
def git(root,*args,check=True): return run('git',*args,cwd=root,check=check).stdout.strip()
def sha256(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def replace_block(path,begin,end,body):
 text=path.read_text(encoding='utf-8'); pat=re.compile(re.escape(begin)+r'.*?'+re.escape(end),re.S)
 if not pat.search(text): raise SystemExit(f'ERROR: markers not found in {path}')
 path.write_text(pat.sub(begin+'\n'+body.rstrip()+'\n'+end,text,count=1),encoding='utf-8',newline='\n')
def main():
 if len(sys.argv)!=2: raise SystemExit('Usage: python apply_v1_3_0_final_release_authorization_patch.py /path/to/repo')
 root=Path(sys.argv[1]).resolve(); req=['README.md','CHANGELOG.md','docs/status_and_nonclaims.md','pyproject.toml','release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_MANIFEST.json','release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_RECORD.json']
 missing=[x for x in req if not (root/x).is_file()]
 if missing: raise SystemExit('ERROR: repository baseline incomplete: '+', '.join(missing))
 if git(root,'rev-parse','--is-inside-work-tree')!='true': raise SystemExit('ERROR: not a Git worktree')
 if run('git','cat-file','-e',FINAL_TARGET+'^{commit}',cwd=root,check=False).returncode!=0: raise SystemExit('ERROR: authorized target unavailable')
 if run('git','merge-base','--is-ancestor',FINAL_TARGET,'HEAD',cwd=root,check=False).returncode!=0: raise SystemExit('ERROR: authorized target not ancestor of HEAD')
 if git(root,'tag','--list',FINAL_TAG): raise SystemExit(f'ERROR: {FINAL_TAG} already exists')
 if not git(root,'tag','--list',RC1_TAG) or git(root,'rev-list','-n','1',RC1_TAG)!=RC1_TARGET: raise SystemExit('ERROR: RC1 tag missing or mismatched')
 if not git(root,'tag','--list',IMMUTABLE_TAG) or git(root,'rev-list','-n','1',IMMUTABLE_TAG)!=IMMUTABLE_TARGET: raise SystemExit('ERROR: historical tag missing or mismatched')
 if 'version = "0.7.0.dev1"' not in (root/'pyproject.toml').read_text(): raise SystemExit('ERROR: unexpected component version')
 for src in sorted(PAYLOAD.rglob('*')):
  if src.is_file():
   dst=root/src.relative_to(PAYLOAD); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
 recp=root/'release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_RECORD.json'; rec=json.loads(recp.read_text()); rec['authorization_basis']['frozen_rc1_evidence_manifest_sha256']=sha256(root/'release/v1.3.0/RC1_RELEASE_EVIDENCE_CLOSURE_MANIFEST.json'); recp.write_text(json.dumps(rec,indent=2)+'\n')
 readme='''> **V0 OSAP v1.3.0 FINAL RELEASE AUTHORIZATION AND STABLE-TAG PREPARATION - FINAL_RELEASE_AUTHORIZED / STABLE_TAG_NOT_CREATED / FINAL_GITHUB_RELEASE_NOT_CREATED / ZENODO_NOT_PUBLISHED**\n\nCandidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.\n\nPR #15 merged the RC1 release-evidence closure as exact stable target `13bf095688bcabd5b090f188e9bd28a16237edeb`. The annotated tag candidate is `v1.3.0`, but the tag and final GitHub Release are not created by this patch.\n\nThe historical RC1 tag `v1.3.0-rc1` remains at `cf9a05b46b9b6f29cd85942f99155f89a49817a7`. This authorization installs final tag text, GitHub release notes and metadata, deterministic manifest replay, exact-target verification, dry-run-first creation scripts, and validation-only CI.\n\nThe embedded checker component remains `0.7.0.dev1` exactly as audited. Historical tag `v1.2.0`, target `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`, and DOI `10.5281/zenodo.21306969` remain immutable. T140, T150, and T156 remain conditional. Zenodo publication and DOI mutation remain unauthorized.\n\nSee `release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_AND_STABLE_TAG_PREPARATION_SPECIFICATION.md` and `release/v1.3.0/V1_3_0_FINAL_RELEASE_AUTHORIZATION_GATES.md`.'''
 status='''## v1.3.0 final release authorization and stable-tag preparation\n\n- Candidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.\n- Status: `FINAL_RELEASE_AUTHORIZED / STABLE_TAG_NOT_CREATED / FINAL_GITHUB_RELEASE_NOT_CREATED / ZENODO_NOT_PUBLISHED`.\n- RC1 evidence-closure PR: #15; exact stable target: `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n- Stable tag candidate: `v1.3.0`; tag kind required: annotated.\n- RC1 tag `v1.3.0-rc1` remains pinned to `cf9a05b46b9b6f29cd85942f99155f89a49817a7`.\n- GitHub final release is authorized only after this patch passes CI and is merged.\n- GitHub release must be non-draft, non-prerelease, and use `--verify-tag`.\n- Embedded checker component remains `0.7.0.dev1` exactly as audited.\n- T140, T150, and T156 remain conditional.\n- Historical tag `v1.2.0` remains pinned to `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`.\n- Historical DOI remains `10.5281/zenodo.21306969`.\n- Zenodo publication and DOI mutation remain unauthorized.\n- No checker-completeness, unconditional global soundness, proof-term identity, global conservativity, empirical, physical, or cosmological claim is made.'''
 change='''## [Unreleased] - v1.3.0 final release authorization and stable-tag preparation\n\n- Separately authorized exact stable target `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n- Prepared annotated tag `v1.3.0` without creating or pushing it.\n- Prepared non-draft, non-prerelease GitHub final-release notes and metadata.\n- Added deterministic authorization manifest, verifier, dry-run-first creation scripts, tests, and validation-only CI.\n- Preserved RC1 tag `v1.3.0-rc1` at `cf9a05b46b9b6f29cd85942f99155f89a49817a7`.\n- Preserved `v1.2.0`, target `befa094ca3db4d5f28f5dcfbfdc4ed8a745972f3`, DOI `10.5281/zenodo.21306969`, conditional records, and non-claims.\n- Retained embedded checker component version `0.7.0.dev1`.\n- Created no stable tag, final GitHub Release, Zenodo version, or DOI change.\n- State: `FINAL_RELEASE_AUTHORIZED / STABLE_TAG_NOT_CREATED / FINAL_GITHUB_RELEASE_NOT_CREATED / ZENODO_NOT_PUBLISHED`.'''
 replace_block(root/'README.md','<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->','<!-- V0_OSAP_RC1_GATE_AUDIT_END -->',readme)
 replace_block(root/'docs/status_and_nonclaims.md','<!-- V0_OSAP_RC1_STATUS_BEGIN -->','<!-- V0_OSAP_RC1_STATUS_END -->',status)
 replace_block(root/'CHANGELOG.md','<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->','<!-- V0_OSAP_RC1_CHANGELOG_END -->',change)
 run(sys.executable,'scripts/build_v1_3_0_final_release_authorization_manifest.py',cwd=root)
 run(sys.executable,'scripts/verify_v1_3_0_final_release_authorization.py','--require-tags',cwd=root)
 print('PASS: applied V0_OSAP_v1.3.0_Final_Release_Authorization_and_Stable_Tag_Preparation_Patch_v0.1.'); print('Recorded state: '+STATE); print('No tag, GitHub Release, Zenodo version, or DOI mutation was executed.')
if __name__=='__main__': main()
