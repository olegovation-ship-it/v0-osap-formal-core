# V0_OSAP_v1.3.0_Final_Release_Authorization_and_Stable_Tag_Preparation_Patch_v0.1

This patch separately authorizes the exact accepted RC1 evidence-closure merge commit
`13bf095688bcabd5b090f188e9bd28a16237edeb` as the only permitted target for the stable annotated tag `v1.3.0`.

It prepares but does not execute annotated stable-tag creation, GitHub final-release
creation, release metadata and notes, exact-target verification, deterministic manifest
replay, and validation-only GitHub Actions.

## State after application

`FINAL_RELEASE_AUTHORIZED / STABLE_TAG_NOT_CREATED / FINAL_GITHUB_RELEASE_NOT_CREATED / ZENODO_NOT_PUBLISHED`

## Explicit non-actions

The patch does not create `v1.3.0`, create a final GitHub Release, alter the RC1
pre-release, alter historical `v1.2.0`, create a Zenodo version, mutate DOI
`10.5281/zenodo.21306969`, or silently promote the embedded checker component from `0.7.0.dev1`.

## Apply

```bash
python apply_v1_3_0_final_release_authorization_patch.py /workspaces/v0-osap-formal-core
```
