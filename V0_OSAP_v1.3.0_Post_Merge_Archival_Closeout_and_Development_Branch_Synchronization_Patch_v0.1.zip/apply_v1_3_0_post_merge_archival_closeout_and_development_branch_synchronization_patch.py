from __future__ import annotations
import argparse, shutil, subprocess
from pathlib import Path
PACKAGE=Path(__file__).resolve().parent
PAYLOAD=PACKAGE/"payload"
BASE="53dcd231aa7d5208a2360d737f01bc2e95e9450b"
TAG="13bf095688bcabd5b090f188e9bd28a16237edeb"
README_BLOCK='<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->\n> **V0 OSAP v1.3.0 POST-MERGE ARCHIVAL CLOSEOUT AND DEVELOPMENT-BRANCH SYNCHRONIZATION - POST_MERGE_ARCHIVAL_CLOSEOUT_RECORDED / MAIN_DEVELOPMENT_SYNCHRONIZED / ZENODO_LIFECYCLE_REPLAY_COMPATIBLE / RELEASE_IMMUTABLE**\n\nCandidate scope: T121-T156 / 36 theorem records / 6 source crosswalks.\n\nPR #18 merged accepted head `73719a160868ffb6cc631388b09dd285239f46cd` into `main` as `53dcd231aa7d5208a2360d737f01bc2e95e9450b` after 36 successful checks. The `v1.3.0-development` branch was then fast-forwarded and pushed to the same commit `53dcd231aa7d5208a2360d737f01bc2e95e9450b`, the recorded post-merge synchronization point.\n\nStable tag `v1.3.0` remains pinned to `13bf095688bcabd5b090f188e9bd28a16237edeb`. GitHub Release v1.3.0 and Zenodo record [21346728](https://zenodo.org/records/21346728), DOI [`10.5281/zenodo.21346728`](https://doi.org/10.5281/zenodo.21346728), remain immutable.\n\nPost-Zenodo historical lifecycle replay and RC1 inventory replay are compatible with the finalized publication lifecycle. Checker `0.7.0.dev1` is unchanged; T140, T150, and T156 remain conditional.\n\nSee `release/v1.3.0/V1_3_0_POST_MERGE_ARCHIVAL_CLOSEOUT_AND_DEVELOPMENT_BRANCH_SYNCHRONIZATION_REPORT.md` and `release/v1.3.0/V1_3_0_POST_MERGE_ARCHIVAL_CLOSEOUT_AND_DEVELOPMENT_BRANCH_SYNCHRONIZATION_ACCEPTANCE_GATES.md`.\n<!-- V0_OSAP_RC1_GATE_AUDIT_END -->'
STATUS_BLOCK='<!-- V0_OSAP_RC1_STATUS_BEGIN -->\n## v1.3.0 post-merge archival closeout and development-branch synchronization\n\n- Status: `POST_MERGE_ARCHIVAL_CLOSEOUT_RECORDED / MAIN_DEVELOPMENT_SYNCHRONIZED / ZENODO_LIFECYCLE_REPLAY_COMPATIBLE / RELEASE_IMMUTABLE`.\n- PR #18 accepted head: `73719a160868ffb6cc631388b09dd285239f46cd`.\n- Merge commit and synchronization baseline: `53dcd231aa7d5208a2360d737f01bc2e95e9450b`.\n- Stable tag target: `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n- Zenodo version DOI: `10.5281/zenodo.21346728`.\n- Historical DOI: `10.5281/zenodo.21306969`.\n- Scope: T121-T156 / 36 records / 6 source crosswalks.\n- Checker: `0.7.0.dev1`; T140, T150, and T156 remain conditional.\n- No tag movement, republication, archive rebuild, Zenodo edit, DOI mutation, theorem extension, checker promotion, completeness, unconditional global-soundness, proof-identity, empirical, physical, or cosmological claim.\n<!-- V0_OSAP_RC1_STATUS_END -->'
CHANGELOG_BLOCK='<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->\n## [v1.3.0] - 2026-07-15 — post-merge archival closeout and development-branch synchronization\n\n- Recorded PR #18 head `73719a160868ffb6cc631388b09dd285239f46cd`, merge commit `53dcd231aa7d5208a2360d737f01bc2e95e9450b`, and 36 successful checks.\n- Recorded `main` and `v1.3.0-development` synchronized at `53dcd231aa7d5208a2360d737f01bc2e95e9450b` before this patch.\n- Preserved tag `v1.3.0` at `13bf095688bcabd5b090f188e9bd28a16237edeb`.\n- Preserved Zenodo DOI `10.5281/zenodo.21346728` and historical DOI `10.5281/zenodo.21306969`.\n- Confirmed post-Zenodo lifecycle replay and RC1 inventory replay compatibility.\n- Retained checker `0.7.0.dev1`; T140, T150, and T156 remain conditional.\n- State: `POST_MERGE_ARCHIVAL_CLOSEOUT_RECORDED / MAIN_DEVELOPMENT_SYNCHRONIZED / ZENODO_LIFECYCLE_REPLAY_COMPATIBLE / RELEASE_IMMUTABLE`.\n<!-- V0_OSAP_RC1_CHANGELOG_END -->'
def run(root,*a,check=True):
 return subprocess.run(list(a),cwd=root,text=True,capture_output=True,check=check)
def replace(path,begin,end,new):
 t=path.read_text(encoding="utf-8"); a=t.find(begin); b=t.find(end)
 if a<0 or b<0 or b<a: raise SystemExit(f"ERROR: marker block missing in {path}")
 b+=len(end); path.write_text(t[:a]+new+t[b:],encoding="utf-8",newline="\n")
def main():
 p=argparse.ArgumentParser(); p.add_argument("--root",required=True); p.add_argument("--allow-nonexact-baseline",action="store_true"); p.add_argument("--skip-tests",action="store_true"); n=p.parse_args()
 root=Path(n.root).resolve()
 if not (root/".git").exists(): raise SystemExit("ERROR: not a Git repository")
 branch=run(root,"git","branch","--show-current").stdout.strip()
 if branch!="v1.3.0-development": raise SystemExit(f"ERROR: use v1.3.0-development, current={branch}")
 run(root,"git","fetch","--force","origin","--tags")
 refs={x:run(root,"git","rev-parse",x).stdout.strip() for x in ("HEAD","origin/main","origin/v1.3.0-development")}
 if not n.allow_nonexact_baseline and set(refs.values())!={BASE}: raise SystemExit("ERROR: branches are not synchronized at "+BASE+"\n"+str(refs))
 if run(root,"git","rev-parse","v1.3.0^{}").stdout.strip()!=TAG: raise SystemExit("ERROR: stable tag target changed")
 dirty=[x for x in run(root,"git","status","--porcelain").stdout.splitlines() if "V0_OSAP_v1.3.0_Post_Merge_Archival_Closeout_and_Development_Branch_Synchronization_Patch_v0.1.zip" not in x]
 if dirty: raise SystemExit("ERROR: unrelated changes:\n"+"\n".join(dirty))
 for src in PAYLOAD.rglob("*"):
  if src.is_file():
   dst=root/src.relative_to(PAYLOAD); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
 replace(root/"README.md","<!-- V0_OSAP_RC1_GATE_AUDIT_BEGIN -->","<!-- V0_OSAP_RC1_GATE_AUDIT_END -->",README_BLOCK)
 replace(root/"docs/status_and_nonclaims.md","<!-- V0_OSAP_RC1_STATUS_BEGIN -->","<!-- V0_OSAP_RC1_STATUS_END -->",STATUS_BLOCK)
 replace(root/"CHANGELOG.md","<!-- V0_OSAP_RC1_CHANGELOG_BEGIN -->","<!-- V0_OSAP_RC1_CHANGELOG_END -->",CHANGELOG_BLOCK)
 run(root,"python","scripts/build_v1_3_0_post_merge_archival_closeout_manifest.py")
 run(root,"python","scripts/verify_v1_3_0_post_merge_archival_closeout.py","--require-tags","--require-remote-sync")
 if not n.skip_tests: run(root,"python","-m","pytest","-q")
 run(root,"git","diff","--check")
 print("PASS: post-merge archival closeout and development-branch synchronization patch applied.")
 print("No tag, GitHub Release, Zenodo record, archive, or DOI was modified.")
if __name__=="__main__": main()
