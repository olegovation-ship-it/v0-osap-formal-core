# V0_OSAP_v1.3.0_Post_Merge_Archival_Closeout_and_Development_Branch_Synchronization_Patch_v0.1

Records the archival closeout after PR #18 and the synchronization of `main` and
`v1.3.0-development` at `53dcd231aa7d5208a2360d737f01bc2e95e9450b`.

## Apply

```bash
cd /workspaces/v0-osap-formal-core
git switch v1.3.0-development
git pull --ff-only origin v1.3.0-development

ZIP="V0_OSAP_v1.3.0_Post_Merge_Archival_Closeout_and_Development_Branch_Synchronization_Patch_v0.1.zip"
TMP="/tmp/v0-osap-v1.3.0-post-merge-closeout"
rm -rf "$TMP"
mkdir -p "$TMP"
python -m zipfile -e "$ZIP" "$TMP"

python "$TMP/apply_v1_3_0_post_merge_archival_closeout_and_development_branch_synchronization_patch.py"   --root /workspaces/v0-osap-formal-core
```

Expected baseline: `53dcd231aa7d5208a2360d737f01bc2e95e9450b` for `HEAD`, `origin/main`, and `origin/v1.3.0-development`.

## Commit

```bash
git add .github/workflows/v1-3-0-post-merge-archival-closeout.yml   README.md CHANGELOG.md docs/status_and_nonclaims.md   release/v1.3.0/V1_3_0_POST_MERGE_ARCHIVAL_CLOSEOUT_AND_DEVELOPMENT_BRANCH_SYNCHRONIZATION_*   scripts/build_v1_3_0_post_merge_archival_closeout_manifest.py   scripts/verify_v1_3_0_post_merge_archival_closeout.py   tests/test_v1_3_0_post_merge_archival_closeout.py
git diff --cached --check
git commit -m "Close V0 OSAP v1.3.0 post-merge archival lifecycle"
git push origin v1.3.0-development
```

Then open a pull request from `v1.3.0-development` to `main`.

The patch does not move tag `v1.3.0`, change the GitHub Release, edit Zenodo record
21346728, mutate DOI `10.5281/zenodo.21346728`, rebuild the archive, or alter the historical v1.2.0 DOI.
